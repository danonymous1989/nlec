NLEC droplet package v2

This archive is designed for droplet platforms that detect Dockerfiles.
It serves the built NLEC website from nginx with SPA fallback routing.

Contents:
- Dockerfile
- nginx.conf
- public/
