import { lazy, Suspense } from "react";
import { Route, Router as WouterRouter, Switch } from "wouter";

const Home = lazy(() => import("./pages/public/Home").then((m) => ({ default: m.Home })));
const About = lazy(() => import("./pages/public/About").then((m) => ({ default: m.About })));
const OurWork = lazy(() => import("./pages/public/OurWork").then((m) => ({ default: m.OurWork })));
const Intelligence = lazy(() => import("./pages/public/LivedExperienceIntelligence").then((m) => ({ default: m.LivedExperienceIntelligence })));
const Services = lazy(() => import("./pages/public/Services").then((m) => ({ default: m.Services })));
const Publications = lazy(() => import("./pages/public/Publications").then((m) => ({ default: m.Publications })));
const Contact = lazy(() => import("./pages/public/Contact").then((m) => ({ default: m.Contact })));
const NotFound = lazy(() => import("./pages/not-found").then((m) => ({ default: m.NotFound })));

function Loader() {
  return (
    <div className="grid min-h-screen place-items-center bg-[color:var(--nav)] text-white">
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-white/20 text-sm font-bold tracking-[0.24em] text-[color:var(--gold)]">
          NLEC
        </div>
        <p className="text-[11px] uppercase tracking-[0.3em] text-white/60">Loading</p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <WouterRouter>
      <Suspense fallback={<Loader />}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route path="/our-work" component={OurWork} />
          <Route path="/work" component={OurWork} />
          <Route path="/lived-experience-intelligence" component={Intelligence} />
          <Route path="/intelligence" component={Intelligence} />
          <Route path="/services" component={Services} />
          <Route path="/partner-with-us" component={Services} />
          <Route path="/publications" component={Publications} />
          <Route path="/contact" component={Contact} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </WouterRouter>
  );
}

