import { Link, useLocation } from "wouter";
import { Menu, X, ArrowRight, Mail, Phone, MapPin, ChevronRight } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  charitablePurposes,
  nationalWorkAreas,
  organisation,
  publicNav,
  responsiblePeople,
} from "@/lib/site";
import { NLECLogo } from "@/components/layout/NLECLogo";

type ButtonLinkProps = {
  href: string;
  children: ReactNode;
  tone?: "primary" | "secondary" | "ghost";
  external?: boolean;
};

export function ButtonLink({ href, children, tone = "primary", external }: ButtonLinkProps) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent)] focus-visible:ring-offset-2";
  const styles = {
    primary: "bg-[color:var(--nav)] text-white hover:bg-[#132d53]",
    secondary: "bg-[color:var(--gold)] text-[color:var(--nav)] hover:bg-[#d7bd72]",
    ghost: "border border-[color:var(--line)] text-[color:var(--nav)] hover:bg-[color:var(--surface)]",
  }[tone];

  const isExternal = external || /^(https?:|mailto:|tel:)/.test(href);
  const shouldBlank = external && /^https?:/.test(href);

  if (isExternal) {
    return (
      <a
        href={href}
        className={`${base} ${styles}`}
        target={shouldBlank ? "_blank" : undefined}
        rel={shouldBlank ? "noreferrer" : undefined}
      >
        {children}
        {shouldBlank ? <ArrowRight className="h-4 w-4" aria-hidden="true" /> : null}
      </a>
    );
  }

  return (
    <Link href={href} className={`${base} ${styles}`}>
      {children}
      <ArrowRight className="h-4 w-4" aria-hidden="true" />
    </Link>
  );
}

export function Header() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [location]);

  return (
    <header className="sticky top-0 z-40 border-b border-[color:var(--line)] bg-white/94 backdrop-blur">
      <a href="#content" className="skip-link">
        Skip to content
      </a>
      <div className="border-b border-[color:var(--line)] bg-[color:var(--nav)] text-white/75">
        <div className="site-container flex items-center justify-between gap-4 py-2 text-[11px] uppercase tracking-[0.24em]">
          <span>{organisation.charityStatus} - ABN {organisation.abn}</span>
          <span className="hidden md:inline">{organisation.remit}</span>
        </div>
      </div>

      <div className="site-container flex h-[72px] items-center justify-between gap-4 py-3">
        <Link href="/" className="flex items-center gap-3 text-[color:var(--nav)]">
          <NLECLogo height={48} />
          <span className="hidden sm:block">
            <span className="block text-[11px] font-semibold uppercase tracking-[0.28em] text-[color:var(--muted)]">
              National Lived Experience Commission
            </span>
            <span className="block font-serif text-lg tracking-[0.08em]">
              Independent public-interest body
            </span>
          </span>
        </Link>

        <nav className="hidden xl:flex items-center gap-1" aria-label="Primary">
          {publicNav.map((item) => {
            const active = item.href === "/" ? location === "/" : location === item.href || location.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  active
                    ? "bg-[color:var(--nav)] text-white"
                    : "text-[color:var(--nav)] hover:bg-[color:var(--surface)]"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden xl:flex items-center gap-3">
          <ButtonLink href="/services" tone="secondary">
            Partner with NLEC
          </ButtonLink>
        </div>

        <button
          type="button"
          className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[color:var(--line)] text-[color:var(--nav)] xl:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label="Toggle navigation"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
        </button>
      </div>

      {open ? (
        <div id="mobile-nav" className="border-t border-[color:var(--line)] bg-white xl:hidden">
          <nav className="site-container flex flex-col gap-1 py-3" aria-label="Mobile">
            {publicNav.map((item) => {
              const active = item.href === "/" ? location === "/" : location === item.href || location.startsWith(`${item.href}/`);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`rounded-2xl px-4 py-3 text-sm font-medium ${
                    active
                      ? "bg-[color:var(--nav)] text-white"
                      : "text-[color:var(--nav)] hover:bg-[color:var(--surface)]"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
            <ButtonLink href="/services" tone="secondary">
              Partner with NLEC
            </ButtonLink>
          </nav>
        </div>
      ) : null}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-[color:var(--line)] bg-[color:var(--nav)] text-white">
      <div className="site-container grid gap-10 py-14 lg:grid-cols-[1.3fr_1fr_1fr]">
        <div>
          <div className="mb-4 inline-flex rounded-2xl border border-white/10 bg-white/5 p-1.5">
            <NLECLogo height={64} />
          </div>
          <p className="max-w-md text-sm leading-7 text-white/72">
            {organisation.name} is an Australian registered charity and national lived-experience agency translating lived experience into evidence, policy insight and practical reform.
          </p>
        </div>

        <div>
          <h2 className="mb-4 font-serif text-lg tracking-[0.08em]">Navigate</h2>
          <ul className="grid gap-2 text-sm text-white/72">
            {publicNav.map((item) => (
              <li key={item.href}>
                <Link className="inline-flex items-center gap-2 hover:text-white" href={item.href}>
                  <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="mb-4 font-serif text-lg tracking-[0.08em]">Contact</h2>
          <ul className="grid gap-3 text-sm text-white/72">
            <li className="flex gap-3">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold)]" />
              <a className="hover:text-white" href={`mailto:${organisation.email}`}>{organisation.email}</a>
            </li>
            <li className="flex gap-3">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold)]" />
              <a className="hover:text-white" href={`tel:${organisation.phone.replace(/\s+/g, "")}`}>{organisation.phone}</a>
            </li>
            <li className="flex gap-3">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold)]" />
              <span>{organisation.address}</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="site-container flex flex-col gap-3 py-4 text-xs uppercase tracking-[0.2em] text-white/55 md:flex-row md:items-center md:justify-between">
          <span>(c) {new Date().getFullYear()} {organisation.name}</span>
          <span>{organisation.charityStatus} - ABN {organisation.abn}</span>
        </div>
      </div>
    </footer>
  );
}

export function Hero({
  eyebrow,
  title,
  description,
  primaryCta,
  secondaryCta,
  aside,
}: {
  eyebrow: string;
  title: string;
  description: string;
  primaryCta?: { label: string; href: string };
  secondaryCta?: { label: string; href: string };
  aside?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden bg-[linear-gradient(135deg,#071423_0%,#0b1f3a_52%,#102844_100%)] text-white">
      <div className="absolute inset-0 opacity-30">
        <div className="absolute left-[-8rem] top-[-8rem] h-72 w-72 rounded-full bg-[color:var(--gold)]/20 blur-3xl" />
        <div className="absolute bottom-[-6rem] right-[-4rem] h-72 w-72 rounded-full bg-[#4f8fbf]/20 blur-3xl" />
      </div>
      <div className="site-container relative grid gap-12 py-20 lg:grid-cols-[1.2fr_0.8fr] lg:items-end lg:py-28">
        <div>
          <p className="mb-5 text-[11px] font-semibold uppercase tracking-[0.3em] text-[color:var(--gold)]">
            {eyebrow}
          </p>
          <h1 className="max-w-4xl font-serif text-[clamp(2.5rem,6vw,4.75rem)] leading-[0.98] tracking-[0.02em]">
            {title}
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-white/78">
            {description}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            {primaryCta ? (
              <ButtonLink href={primaryCta.href} tone="secondary">
                {primaryCta.label}
              </ButtonLink>
            ) : null}
            {secondaryCta ? (
              <ButtonLink href={secondaryCta.href} tone="ghost">
                {secondaryCta.label}
              </ButtonLink>
            ) : null}
          </div>
        </div>
        <div className="lg:justify-self-end">{aside}</div>
      </div>
    </section>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <section className="border-b border-[color:var(--line)] bg-[color:var(--surface)]">
      <div className="site-container py-16 md:py-20">
        <p className="mb-4 text-[11px] font-semibold uppercase tracking-[0.3em] text-[color:var(--gold)]">
          {eyebrow}
        </p>
        <h1 className="max-w-4xl font-serif text-[clamp(2.1rem,5vw,3.8rem)] leading-[1.02] tracking-[0.02em] text-[color:var(--nav)]">
          {title}
        </h1>
        <p className="mt-5 max-w-3xl text-lg leading-8 text-[color:var(--muted)]">
          {description}
        </p>
      </div>
    </section>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="mb-8 max-w-3xl">
      <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.28em] text-[color:var(--gold)]">
        {eyebrow}
      </p>
      <h2 className="font-serif text-[clamp(1.7rem,3vw,2.6rem)] leading-[1.08] tracking-[0.02em] text-[color:var(--nav)]">
        {title}
      </h2>
      {description ? (
        <p className="mt-4 text-base leading-8 text-[color:var(--muted)]">
          {description}
        </p>
      ) : null}
    </div>
  );
}

export function InfoCard({
  title,
  description,
  kicker,
}: {
  title: string;
  description: string;
  kicker?: string;
}) {
  return (
    <article className="site-card">
      {kicker ? <p className="card-kicker">{kicker}</p> : null}
      <h3 className="card-title">{title}</h3>
      <p className="card-copy">{description}</p>
    </article>
  );
}

export function StatCard({
  value,
  label,
}: {
  value: string;
  label: string;
}) {
  return (
    <article className="site-card">
      <p className="text-3xl font-serif tracking-[0.02em] text-[color:var(--nav)]">{value}</p>
      <p className="mt-3 text-sm leading-6 text-[color:var(--muted)]">{label}</p>
    </article>
  );
}

export function CTASection({
  title,
  description,
  primary,
  secondary,
}: {
  title: string;
  description: string;
  primary: { label: string; href: string };
  secondary?: { label: string; href: string };
}) {
  return (
    <section className="bg-[color:var(--nav)] text-white">
      <div className="site-container grid gap-8 py-12 lg:grid-cols-[1.3fr_0.7fr] lg:items-center">
        <div>
          <h2 className="font-serif text-[clamp(1.8rem,3vw,2.8rem)] leading-[1.05] tracking-[0.02em]">
            {title}
          </h2>
          <p className="mt-4 max-w-2xl text-base leading-8 text-white/75">
            {description}
          </p>
        </div>
        <div className="flex flex-wrap gap-3 lg:justify-end">
          <ButtonLink href={primary.href} tone="secondary">
            {primary.label}
          </ButtonLink>
          {secondary ? (
            <ButtonLink href={secondary.href} tone="ghost">
              {secondary.label}
            </ButtonLink>
          ) : null}
        </div>
      </div>
    </section>
  );
}

export function ServiceCard({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <article className="site-card">
      <h3 className="card-title">{title}</h3>
      <p className="card-copy">{description}</p>
    </article>
  );
}

export function PublicationCard({
  category,
  title,
  summary,
  href,
}: {
  category: string;
  title: string;
  summary: string;
  href?: string;
}) {
  const content = (
    <>
      <p className="card-kicker">{category}</p>
      <h3 className="card-title">{title}</h3>
      <p className="card-copy">{summary}</p>
      <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-[color:var(--nav)]">
        {href ? "Open PDF" : "Coming soon"}
        <ChevronRight className="h-4 w-4" aria-hidden="true" />
      </span>
    </>
  );

  if (href) {
    return (
      <a className="site-card block transition-transform hover:-translate-y-0.5 hover:shadow-md" href={href} target="_blank" rel="noreferrer">
        {content}
      </a>
    );
  }

  return (
    <article className="site-card">{content}</article>
  );
}

export function ContactBlock() {
  return (
    <aside className="site-card space-y-5">
      <div>
        <p className="card-kicker">Direct contact</p>
        <h3 className="card-title">Talk to the Commission</h3>
      </div>
      <ul className="grid gap-4 text-sm leading-7 text-[color:var(--muted)]">
        <li className="flex gap-3">
          <Mail className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold)]" />
          <a className="hover:text-[color:var(--nav)]" href={`mailto:${organisation.email}`}>{organisation.email}</a>
        </li>
        <li className="flex gap-3">
          <Phone className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold)]" />
          <a className="hover:text-[color:var(--nav)]" href={`tel:${organisation.phone.replace(/\s+/g, "")}`}>{organisation.phone}</a>
        </li>
        <li className="flex gap-3">
          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold)]" />
          <span>{organisation.address}</span>
        </li>
      </ul>
      <div className="grid gap-3">
        <ButtonLink href="/services" tone="primary">
          Partnership enquiry
        </ButtonLink>
        <ButtonLink href="mailto:commissioner@nlec.au?subject=Media%20enquiry" tone="ghost">
          Media enquiry
        </ButtonLink>
      </div>
    </aside>
  );
}

export function OrganisationSchema() {
  const payload = useMemo(
    () => ({
      "@context": "https://schema.org",
      "@type": "NonprofitOrganization",
      name: organisation.name,
      url: `https://${organisation.website}`,
      email: organisation.email,
      telephone: organisation.phone,
      address: {
        "@type": "PostalAddress",
        streetAddress: organisation.address,
        addressCountry: "AU",
      },
      identifier: organisation.abn,
      foundingDate: organisation.established,
      nonprofitStatus: "Registered charity with the ACNC",
    }),
    [],
  );

  return <script type="application/ld+json">{JSON.stringify(payload)}</script>;
}
