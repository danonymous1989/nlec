import { useState } from "react";

interface CheckoutModalProps {
  tierKey: string;
  tierName: string;
  tierPrice: string;
  mode: "subscription" | "payment";
  onClose: () => void;
}

export function CheckoutModal({ tierKey, tierName, tierPrice, mode, onClose }: CheckoutModalProps) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !name) { setError("Name and email are required."); return; }
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch("/api/stripe/checkout-by-tier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tierKey, email, name }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        setError(data.error || "Payment could not be initiated. Please contact commissioner@nlec.au");
        setSubmitting(false);
      }
    } catch {
      setError("A connection error occurred. Please contact commissioner@nlec.au");
      setSubmitting(false);
    }
  };

  const NAV = "#0B1F3A";
  const GOLD = "#C6A85A";
  const BORDER = "#E5E5E5";

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(11,31,58,0.7)", zIndex: 9999,
      display: "flex", alignItems: "center", justifyContent: "center", padding: "24px",
    }} onClick={onClose}>
      <div style={{
        background: "#fff", maxWidth: "480px", width: "100%",
        boxShadow: "0 24px 64px rgba(0,0,0,0.25)", position: "relative",
      }} onClick={e => e.stopPropagation()}>

        <div style={{ background: NAV, padding: "24px 28px" }}>
          <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", color: GOLD, marginBottom: "6px" }}>
            {mode === "subscription" ? "Annual Subscription" : "One-Time Payment"}
          </div>
          <h3 style={{ fontFamily: "'Cinzel', serif", fontSize: "18px", fontWeight: 600, color: "#fff", letterSpacing: "0.04em", lineHeight: 1.3, margin: 0 }}>
            {tierName}
          </h3>
          <div style={{ fontFamily: "'Inter', monospace", fontSize: "22px", fontWeight: 700, color: GOLD, marginTop: "8px" }}>{tierPrice}</div>
        </div>

        <form onSubmit={handleSubmit} style={{ padding: "28px" }}>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: "#555", lineHeight: 1.6, marginBottom: "20px" }}>
            You will be redirected to a secure Stripe payment page. All transactions are in Australian Dollars (AUD).
          </p>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, color: NAV, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "6px" }}>
              Full Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              required
              style={{ width: "100%", border: `1px solid ${BORDER}`, padding: "10px 12px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", outline: "none", boxSizing: "border-box" }}
            />
          </div>

          <div style={{ marginBottom: "20px" }}>
            <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, color: NAV, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "6px" }}>
              Email Address *
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              style={{ width: "100%", border: `1px solid ${BORDER}`, padding: "10px 12px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", outline: "none", boxSizing: "border-box" }}
            />
          </div>

          {error && (
            <div style={{ background: "#FFF5F5", border: "1px solid #FCA5A5", padding: "10px 12px", marginBottom: "16px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: "#B91C1C" }}>
              {error}
            </div>
          )}

          <div style={{ display: "flex", gap: "12px" }}>
            <button
              type="submit"
              disabled={submitting}
              style={{ flex: 1, background: submitting ? "#666" : NAV, color: "#fff", border: "none", padding: "12px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", fontWeight: 600, cursor: submitting ? "not-allowed" : "pointer", letterSpacing: "0.02em" }}
            >
              {submitting ? "Redirecting to Stripe…" : "Proceed to Payment"}
            </button>
            <button
              type="button"
              onClick={onClose}
              style={{ padding: "12px 20px", background: "transparent", border: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: "#555", cursor: "pointer" }}
            >
              Cancel
            </button>
          </div>

          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", color: "#999", marginTop: "14px", lineHeight: 1.5 }}>
            Payments processed securely by Stripe. Your card details are never stored by the Commission.
          </p>
        </form>
      </div>
    </div>
  );
}
