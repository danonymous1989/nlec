interface NLECLogoProps {
  height?: number;
}

export function NLECLogo({ height = 72 }: NLECLogoProps) {
  return (
    <img
      src="/images/nlec-logo-placeholder.png"
      alt="National Lived Experience Commission"
      height={height}
      width={height}
      style={{ display: "block", flexShrink: 0, objectFit: "contain" }}
    />
  );
}
