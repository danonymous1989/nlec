import { useEffect } from "react";
import { useLocation } from "wouter";
import { Footer, Header, OrganisationSchema } from "@/components/site";
import type { ReactNode } from "react";

export function PublicLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <div className="min-h-screen bg-[color:var(--bg)] text-[color:var(--text)]">
      <Header />
      <OrganisationSchema />
      <main id="content">{children}</main>
      <Footer />
    </div>
  );
}
