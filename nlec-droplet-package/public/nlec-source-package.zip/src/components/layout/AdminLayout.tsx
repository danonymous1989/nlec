import { Link, useLocation } from "wouter";
import { useAdminMe, useAdminLogout } from "@workspace/api-client-react";
import {
  LayoutDashboard, FileText, BookOpen, FlaskConical,
  Newspaper, Inbox, Mail, LogOut, Menu, ChevronRight, Briefcase, Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { data: user, isLoading, isError } = useAdminMe({
    query: { retry: false, refetchOnWindowFocus: false }
  });
  const logout = useAdminLogout();
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    if (!isLoading && isError) setLocation("/admin/login");
  }, [isLoading, isError, setLocation]);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  }

  if (!user) return null;

  const handleLogout = async () => {
    try {
      await logout.mutateAsync();
      setLocation("/admin/login");
      toast({ title: "Logged out successfully" });
    } catch {
      setLocation("/admin/login");
    }
  };

  const navItems = [
    { name: "Dashboard", path: "/admin", icon: LayoutDashboard },
    { name: "Standards", path: "/admin/standards", icon: FileText },
    { name: "Publications", path: "/admin/publications", icon: BookOpen },
    { name: "News & Updates", path: "/admin/news", icon: Newspaper },
    { name: "Evidence Submissions", path: "/admin/evidence", icon: Inbox },
    { name: "Contact Enquiries", path: "/admin/contact", icon: Mail },
    { name: "Service Enquiries", path: "/admin/service-enquiries", icon: Briefcase },
  ];

  return (
    <div className="min-h-screen flex bg-gray-50">
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-sidebar text-sidebar-foreground transform transition-transform duration-300 ease-in-out ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} md:relative md:translate-x-0`}>
        <div className="h-20 flex items-center justify-center border-b border-sidebar-border px-4">
          <span className="font-serif font-bold text-lg text-white">NLEC Admin</span>
        </div>
        <div className="p-4">
          <div className="text-xs text-sidebar-foreground/50 uppercase tracking-wider mb-4 px-3">Menu</div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const active = location === item.path || (item.path !== "/admin" && location.startsWith(item.path));
              return (
                <Link key={item.name} href={item.path}>
                  <div className={`flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors cursor-pointer ${
                    active ? "bg-sidebar-accent text-white" : "text-sidebar-foreground/80 hover:bg-sidebar-border hover:text-white"
                  }`}>
                    <item.icon className="mr-3 h-5 w-5 shrink-0" />
                    {item.name}
                  </div>
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="absolute bottom-0 w-full p-4 border-t border-sidebar-border">
          <div className="flex items-center mb-4 px-3">
            <div className="h-8 w-8 rounded-full bg-sidebar-primary flex items-center justify-center text-white font-bold mr-3">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-medium text-white truncate">{user.username}</p>
              <p className="text-xs text-sidebar-foreground/60 capitalize">{user.role}</p>
            </div>
          </div>
          <Button variant="ghost" className="w-full justify-start text-sidebar-foreground/80 hover:text-white hover:bg-sidebar-border" onClick={handleLogout}>
            <LogOut className="mr-3 h-5 w-5" />
            Logout
          </Button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-20 bg-white border-b flex items-center justify-between px-6 shrink-0">
          <button className="md:hidden text-gray-500" onClick={() => setSidebarOpen(!sidebarOpen)}>
            <Menu size={24} />
          </button>
          <div className="hidden md:flex items-center text-sm text-gray-500 font-medium">
            <Link href="/" className="hover:text-primary transition-colors flex items-center">
              View Public Site <ChevronRight size={16} className="ml-1"/>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium px-3 py-1 bg-gray-100 rounded-full text-gray-600">Secure Session</span>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6 md:p-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
