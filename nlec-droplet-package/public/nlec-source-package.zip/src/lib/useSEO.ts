import { useEffect } from "react";

const CANONICAL_BASE = "https://nlec.au";
const DEFAULT_DESC = "The National Lived Experience Commission is an Australian registered charity advancing public debate, social welfare and health by translating lived experience into evidence, policy insight and practical reform.";
const DEFAULT_IMAGE = `${CANONICAL_BASE}/opengraph.jpg`;

interface SEOProps {
  title?: string;
  description?: string;
  path?: string;
  image?: string;
}

export function useSEO({ title, description, path = "", image }: SEOProps = {}) {
  const fullTitle = title
    ? `${title} | NLEC`
    : "NLEC - National Lived Experience Commission | Governance Standards & Systems Intelligence";
  const desc = description || DEFAULT_DESC;
  const canonical = `${CANONICAL_BASE}${path}`;
  const ogImage = image || DEFAULT_IMAGE;

  useEffect(() => {
    document.title = fullTitle;

    const setMeta = (name: string, content: string, prop = false) => {
      const attr = prop ? "property" : "name";
      let el = document.querySelector(`meta[${attr}="${name}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    const setLink = (rel: string, href: string) => {
      let el = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
      if (!el) {
        el = document.createElement("link");
        el.setAttribute("rel", rel);
        document.head.appendChild(el);
      }
      el.setAttribute("href", href);
    };

    setMeta("description", desc);
    setMeta("theme-color", "#0B1F3A");
    setLink("canonical", canonical);

    setMeta("og:type", "website", true);
    setMeta("og:site_name", "National Lived Experience Commission", true);
    setMeta("og:title", fullTitle, true);
    setMeta("og:description", desc, true);
    setMeta("og:url", canonical, true);
    setMeta("og:image", ogImage, true);

    setMeta("twitter:card", "summary_large_image");
    setMeta("twitter:title", fullTitle);
    setMeta("twitter:description", desc);
    setMeta("twitter:image", ogImage);
  }, [fullTitle, desc, canonical, ogImage]);
}
