export const organisation = {
  name: "National Lived Experience Commission",
  shortName: "NLEC",
  website: "nlec.au",
  email: "commissioner@nlec.au",
  phone: "0434 774 671",
  address: "53 Alinga St, Canberra ACT 2601",
  abn: "79 919 184 486",
  charityStatus: "Registered charity with the ACNC",
  established: "10 August 2025",
  remit: "Operates nationally across Australia",
};

export const publicNav = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "Our Work", href: "/our-work" },
  { label: "Lived Experience Intelligence", href: "/lived-experience-intelligence" },
  { label: "Services", href: "/services" },
  { label: "Publications", href: "/publications" },
  { label: "Contact", href: "/contact" },
];

export const charitablePurposes = [
  "Advancing public debate",
  "Advancing social or public welfare",
  "Advancing health",
];

export const nationalWorkAreas = [
  "Policy and reform",
  "Public debate and education",
  "Institutional advisory",
  "Commissioned research",
  "Health and welfare systems",
  "Service design and improvement",
];

export const responsiblePeople = [
  { name: "Daniel Vamplew", role: "Chairperson, Director, Trustee / Executive Director" },
  { name: "Brooke Flugel", role: "Treasurer" },
  { name: "Anne Miles", role: "Secretary" },
];

export const workPrograms = [
  {
    title: "Public debate and reform",
    description: "Publish measured, evidence-led material that improves public understanding of lived experience and informs reform conversation.",
  },
  {
    title: "Lived-experience evidence",
    description: "Collect, assess and synthesise lived-experience evidence as operational intelligence that can be used responsibly by institutions.",
  },
  {
    title: "Policy submissions",
    description: "Prepare formal submissions that translate frontline experience into policy insight for inquiries, reviews and consultations.",
  },
  {
    title: "Commissioned research",
    description: "Deliver targeted research projects that surface system patterns, risk signals and practical opportunities for improvement.",
  },
  {
    title: "Institutional advisory",
    description: "Support government, universities, service providers and peak bodies with structured advisory work and briefings.",
  },
  {
    title: "Health and welfare reform",
    description: "Focus on the settings where health, welfare and social policy intersect with lived experience and system harm.",
  },
  {
    title: "Community listening",
    description: "Design consultations that are trauma-informed, accessible and respectful of the people whose experience is being heard.",
  },
  {
    title: "Education and public awareness",
    description: "Build shared understanding of why lived experience matters and how it should shape public debate and institutional learning.",
  },
  {
    title: "System failure analysis",
    description: "Identify recurring blind spots, weak signals and failure patterns so institutions can prevent harm rather than respond late.",
  },
  {
    title: "Service improvement",
    description: "Turn evidence into practical recommendations for service design, accountability, quality and implementation.",
  },
];

export const intelligenceStages = [
  {
    title: "From testimony to evidence",
    description: "NLEC treats lived experience as a form of evidence that can be gathered carefully, contextually and ethically.",
  },
  {
    title: "From evidence to reform",
    description: "Evidence is translated into policy insight, institutional recommendations and public-interest reform agendas.",
  },
  {
    title: "Identifying system blind spots",
    description: "Pattern analysis can reveal gaps that institutions do not see from inside their own operating logic.",
  },
  {
    title: "Reducing harm",
    description: "Earlier recognition of risk gives governments and services a better chance of preventing avoidable harm.",
  },
  {
    title: "Improving service design",
    description: "Lived experience strengthens service design by keeping human impact visible throughout decision-making.",
  },
  {
    title: "Strengthening accountability",
    description: "When evidence is structured and transparent, accountability becomes harder to defer or dilute.",
  },
  {
    title: "Ethical use of lived experience",
    description: "NLEC uses trauma-informed, consent-aware and dignity-centred practices to avoid extraction or harm.",
  },
];

export const serviceCards = [
  {
    title: "Government advisory",
    description: "Brief departments and agencies on lived-experience evidence, system risk and reform opportunities.",
  },
  {
    title: "Lived-experience consultation design",
    description: "Design consultation processes that are inclusive, trauma-informed and capable of producing usable evidence.",
  },
  {
    title: "Institutional review",
    description: "Review systems, policies and operating models for how well they recognise and respond to lived experience.",
  },
  {
    title: "Reform submissions",
    description: "Prepare submissions for inquiries, reviews and consultations with a strong public-interest focus.",
  },
  {
    title: "Commissioned research",
    description: "Produce research on system failure, accountability, service design and public debate.",
  },
  {
    title: "Stakeholder engagement",
    description: "Facilitate structured conversations between institutions, communities and decision-makers.",
  },
  {
    title: "Lived-experience panels",
    description: "Support the creation of advisory panels with clear purpose, boundaries and respectful participation.",
  },
  {
    title: "Public education",
    description: "Develop public-facing materials that explain why lived experience matters in reform and accountability.",
  },
  {
    title: "Organisational training",
    description: "Build capability within teams so lived experience can be used responsibly and consistently.",
  },
  {
    title: "Policy and service design review",
    description: "Assess whether policy and service designs reflect human impact, implementation reality and accountability.",
  },
];

export const publicationCategories = [
  "Reports",
  "Public submissions",
  "Policy briefs",
  "Lived-experience evidence papers",
  "Media statements",
  "Discussion papers",
];

export const publicationReleases = [
  {
    category: "Executive summary",
    title: "NLEC Executive Summary",
    summary: "A concise board-approved overview of NLEC's mission, public debate mandate and the opportunity to convert lived experience into operational intelligence.",
    href: "/publications/nlec-executive-summary-2026.pdf",
  },
  {
    category: "Annual intelligence report",
    title: "National Lived Experience Intelligence Report 2026",
    summary: "NLEC's first annual intelligence report, setting the baseline for Australia's systems health from the perspective of people with lived experience.",
    href: "/publications/national-lived-experience-intelligence-report-2026.pdf",
  },
  {
    category: "Standards framework",
    title: "National Co-Design Standards Framework",
    summary: "A public-interest standards document for distinguishing genuine co-design from symbolic consultation across policy and service reform processes.",
    href: "/publications/national-co-design-standards-framework.pdf",
  },
  {
    category: "Operational program",
    title: "National Evidence Collection Program 2026-2027",
    summary: "The operational plan for recruiting participants, gathering evidence and building the primary dataset that will underpin NLEC's 2027 intelligence report.",
    href: "/publications/national-evidence-collection-program-2026-2027.pdf",
  },
];

export const publicationPlaceholders = publicationReleases;
