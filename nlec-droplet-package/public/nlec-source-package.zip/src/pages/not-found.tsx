import { PublicLayout } from "@/components/layout/PublicLayout";
import { PageHeader, ButtonLink } from "@/components/site";
import { useSEO } from "@/lib/useSEO";

export function NotFound() {
  useSEO({
    path: "/404",
    title: "Page not found",
    description: "The requested page could not be found on the National Lived Experience Commission website.",
  });

  return (
    <PublicLayout>
      <PageHeader
        eyebrow="404"
        title="Page not found"
        description="The page you were looking for does not exist. Use the navigation or return to the homepage."
      />
      <div className="site-container section-block">
        <ButtonLink href="/">Return home</ButtonLink>
      </div>
    </PublicLayout>
  );
}
