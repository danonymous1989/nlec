import { PublicLayout } from "@/components/layout/PublicLayout";
import { useGetDashboardData } from "@workspace/api-client-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, LineChart, Line, Legend } from "recharts";
import { AlertTriangle, TrendingUp, ShieldAlert } from "lucide-react";

export function Dashboard() {
  const { data, isLoading } = useGetDashboardData();

  if (isLoading) return <PublicLayout><div className="min-h-screen flex items-center justify-center"><div className="animate-spin h-12 w-12 border-b-2 border-secondary"></div></div></PublicLayout>;
  if (!data) return null;

  return (
    <PublicLayout>
      <div className="bg-primary pt-20 pb-24 text-white border-b-4 border-accent">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Systems Intelligence Dashboard</h1>
          <p className="text-xl text-white/80 font-light max-w-3xl">
            Real-time aggregate data on national governance risks, systemic pressures, and lived experience integration maturity.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 -mt-16">
        {/* Top KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 border border-gray-200 shadow-md">
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Total Evidence Base</h3>
            <div className="text-4xl font-mono text-primary font-bold">{data.totalEvidenceSubmissions.toLocaleString()}</div>
            <div className="text-sm text-green-600 mt-2 flex items-center font-medium"><TrendingUp size={16} className="mr-1"/> +12% this quarter</div>
            <div className="text-xs text-gray-400 mt-1">All service systems · NLEC national index</div>
          </div>
          <div className="bg-white p-6 border border-gray-200 shadow-md">
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Active Standards</h3>
            <div className="text-4xl font-mono text-secondary font-bold">{data.totalStandards}</div>
            <div className="text-sm text-gray-500 mt-2 font-medium">Governance standards in library</div>
          </div>
          <div className="bg-white p-6 border border-gray-200 shadow-md">
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Published Research</h3>
            <div className="text-4xl font-mono text-primary font-bold">{data.totalPublications}</div>
            <div className="text-sm text-gray-500 mt-2 font-medium">Policy & analytical reports</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Chart 1 */}
          <div className="bg-white p-6 md:p-8 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-serif font-bold text-primary mb-6">Evidence Submissions by Domain</h3>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.evidenceByType} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="category" axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 12}} />
                  <RechartsTooltip cursor={{fill: '#F3F4F6'}} contentStyle={{borderRadius: '0px', border: '1px solid #E5E7EB'}} />
                  <Bar dataKey="count" fill="hsl(var(--secondary))" radius={[2, 2, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2 */}
          <div className="bg-white p-6 md:p-8 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-serif font-bold text-primary mb-6">Governance Risk Trend</h3>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.governanceRiskTrends} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="period" axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 12}} />
                  <RechartsTooltip contentStyle={{borderRadius: '0px', border: '1px solid #E5E7EB'}} />
                  <Line type="monotone" dataKey="value" stroke="hsl(var(--accent))" strokeWidth={3} dot={{r: 4, fill: 'hsl(var(--primary))'}} activeDot={{r: 6}} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Themes Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-serif font-bold text-primary mb-6 flex items-center">
              <AlertTriangle className="mr-3 text-secondary" /> Emerging Systems Pressures
            </h3>
            <div className="space-y-4">
              {data.systemsPressureThemes.map((theme, i) => (
                <div key={i} className="bg-white border border-gray-200 p-5 pl-6 border-l-4 border-l-secondary">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-gray-900">{theme.theme}</h4>
                    <span className={`text-xs font-bold px-2 py-1 uppercase ${theme.severity === 'High' ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700'}`}>
                      {theme.severity}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{theme.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-serif font-bold text-primary mb-6 flex items-center">
              <ShieldAlert className="mr-3 text-accent" /> Critical Escalation Factors
            </h3>
            <div className="space-y-4">
              {data.escalationFactors.map((factor, i) => (
                <div key={i} className="bg-white border border-gray-200 p-5 pl-6 border-l-4 border-l-accent">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-gray-900">{factor.theme}</h4>
                    <span className="text-xs font-bold px-2 py-1 uppercase bg-red-100 text-red-700">
                      {factor.severity}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{factor.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
