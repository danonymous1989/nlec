import { Link } from "wouter";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { useSEO } from "@/lib/useSEO";
import { ArrowRight, CheckSquare, Users, Building2 } from "lucide-react";

export function Membership() {
  useSEO({ path: "/membership", title: "Membership", description: "Join the National Lived Experience Commission as a professional or institutional member. Access research, standards, and governance intelligence resources." });
  return (
    <PublicLayout>
      {/* Hero */}
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">
            MEMBERSHIP
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Membership</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl mb-4">
            The National Lived Experience Commission provides membership pathways for organisations and professionals committed to strengthening governance through lived experience intelligence.
          </p>
          <p className="text-white/70 leading-relaxed max-w-3xl">
            Membership provides access to research, standards, governance assessment tools, and the Commission's systems intelligence resources. Participation in the Commission's membership network supports the development of stronger institutions, more effective engagement frameworks, and evidence-informed governance practice.
          </p>
        </div>
      </section>

      {/* Membership Pathways */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-16">
            <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-3">Membership Categories</h2>
            <h3 className="text-3xl md:text-4xl font-serif font-bold text-primary">Two Membership Pathways</h3>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="border border-gray-200 p-10 hover:border-secondary hover:shadow-md transition-all group">
              <Users className="h-10 w-10 text-secondary mb-6" />
              <h3 className="text-2xl font-serif font-bold text-primary mb-4 group-hover:text-secondary transition-colors">Professional Membership</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                For individual practitioners, researchers, and lived experience professionals. Professional membership connects individuals to the Commission's research network and provides access to specialised resources.
              </p>
              <div className="space-y-2 mb-8">
                {["From AUD $180 per year", "Three tiers available", "Access to research, briefings and consultation", "Certification program eligibility"].map(item => (
                  <div key={item} className="flex items-start gap-2 text-sm text-gray-600">
                    <CheckSquare className="h-4 w-4 text-secondary mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <Button asChild className="w-full rounded-none bg-primary hover:bg-secondary text-white">
                <Link href="/membership/professional">View Professional Membership <ArrowRight size={16} className="ml-2" /></Link>
              </Button>
            </div>

            <div className="border border-secondary bg-secondary/5 p-10 hover:shadow-md transition-all group">
              <Building2 className="h-10 w-10 text-secondary mb-6" />
              <h3 className="text-2xl font-serif font-bold text-primary mb-4 group-hover:text-secondary transition-colors">Institutional Membership</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                For organisations seeking to strengthen governance, engagement practice, and lived experience integration. Membership enables direct engagement with the Commission's governance frameworks and standards library.
              </p>
              <div className="space-y-2 mb-8">
                {["From AUD $5,000 per year", "Three tiers available", "Standards library and governance tools", "Institutional dashboard access", "Discounted assessment services"].map(item => (
                  <div key={item} className="flex items-start gap-2 text-sm text-gray-600">
                    <CheckSquare className="h-4 w-4 text-secondary mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <Button asChild className="w-full rounded-none bg-secondary hover:bg-primary text-white">
                <Link href="/membership/institutional">View Institutional Membership <ArrowRight size={16} className="ml-2" /></Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* What membership provides */}
      <section className="py-16 bg-gray-50 border-t border-b border-gray-200">
        <div className="container mx-auto px-4 max-w-5xl">
          <h3 className="text-2xl font-serif font-bold text-primary text-center mb-12">What Membership Provides</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Research Access", desc: "Access to Commission publications, research reports, and systems intelligence briefings." },
              { title: "Standards Library", desc: "Full or tiered access to the NLEC governance standards library and associated guidance materials." },
              { title: "Governance Tools", desc: "Access to benchmarking tools, assessment frameworks, and governance maturity resources." },
              { title: "Consultation Rights", desc: "Participation in Commission consultations, working groups, and policy development processes." },
              { title: "Certification Pathways", desc: "Eligibility for Commission certification programs for individuals and organisational staff." },
              { title: "Network Participation", desc: "Access to the Commission's professional and institutional member network." },
            ].map(item => (
              <div key={item.title} className="bg-white p-6 border border-gray-100">
                <h4 className="font-bold text-primary mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary text-white text-center">
        <div className="container mx-auto px-4 max-w-2xl">
          <h3 className="text-2xl font-serif font-bold mb-4">View Pricing</h3>
          <p className="text-white/80 mb-8">Review the full pricing schedule for memberships, certification programs, and institutional services.</p>
          <Button asChild variant="outline" className="border-accent text-accent hover:bg-accent hover:text-primary rounded-none h-12 px-8">
            <Link href="/pricing">View Pricing Schedule</Link>
          </Button>
        </div>
      </section>
    </PublicLayout>
  );
}
