import { PublicLayout } from "@/components/layout/PublicLayout";
import { useSEO } from "@/lib/useSEO";
import { Link } from "wouter";

const NAV    = "#0B1F3A";
const GOLD   = "#C6A85A";
const TEXT   = "#1A1A1A";
const MUTED  = "#555";
const BORDER = "#E5E5E5";
const LIGHT  = "#F5F7FA";

const riskColors: Record<string, string> = {
  CRITICAL: "#8B0000",
  HIGH:     "#B8460A",
  ELEVATED: "#8A6A1A",
  MEDIUM:   "#4A6741",
};

function Chip({ level }: { level: string }) {
  const color = riskColors[level.toUpperCase()] || NAV;
  return (
    <span style={{
      display: "inline-block",
      background: color,
      color: "#fff",
      fontFamily: "'Source Sans 3', sans-serif",
      fontSize: "10px",
      fontWeight: 700,
      letterSpacing: "0.1em",
      padding: "2px 10px",
      textTransform: "uppercase" as const,
    }}>{level}</span>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", fontWeight: 700, letterSpacing: "0.13em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "10px" }}>
      {children}
    </p>
  );
}

function H2({ children }: { children: React.ReactNode }) {
  return (
    <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(18px, 2.5vw, 24px)", fontWeight: 600, color: NAV, letterSpacing: "0.04em", marginBottom: "20px", paddingBottom: "12px", borderBottom: `2px solid ${GOLD}` }}>
      {children}
    </h2>
  );
}

function RiskDomain({ num, title, level, description, pattern, consequence }: { num: number; title: string; level: string; description: string; pattern: string; consequence: string }) {
  return (
    <div style={{ borderTop: `1px solid ${BORDER}`, paddingTop: "28px", marginBottom: "32px" }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: "16px", marginBottom: "12px", flexWrap: "wrap" as const }}>
        <span style={{ fontFamily: "'Cinzel', serif", fontSize: "11px", fontWeight: 600, color: GOLD, letterSpacing: "0.1em", whiteSpace: "nowrap" as const }}>RISK DOMAIN {num}</span>
        <h3 style={{ fontFamily: "'Cinzel', serif", fontSize: "16px", fontWeight: 600, color: NAV, flex: 1, margin: 0 }}>{title}</h3>
        <Chip level={level} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "20px" }}>
        <div>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", fontWeight: 700, color: GOLD, letterSpacing: "0.1em", marginBottom: "6px", textTransform: "uppercase" as const }}>Description</p>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", lineHeight: 1.65, color: TEXT }}>{description}</p>
        </div>
        <div>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", fontWeight: 700, color: GOLD, letterSpacing: "0.1em", marginBottom: "6px", textTransform: "uppercase" as const }}>Observed Pattern</p>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", lineHeight: 1.65, color: TEXT }}>{pattern}</p>
        </div>
        <div>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", fontWeight: 700, color: GOLD, letterSpacing: "0.1em", marginBottom: "6px", textTransform: "uppercase" as const }}>Consequence if Unaddressed</p>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", lineHeight: 1.65, color: TEXT }}>{consequence}</p>
        </div>
      </div>
    </div>
  );
}

const dashboard = [
  { domain: "Early Warning Capability", level: "CRITICAL", status: "ABSENT",      highlight: true },
  { domain: "Escalation Threshold",     level: "CRITICAL", status: "Escalating",  highlight: false },
  { domain: "Co-Design Integrity",      level: "HIGH",     status: "Escalating",  highlight: false },
  { domain: "Complaint Intelligence",   level: "HIGH",     status: "Fragmented",  highlight: false },
  { domain: "Cross-System Coordination",level: "HIGH",     status: "Escalating",  highlight: false },
  { domain: "Data Synthesis",           level: "HIGH",     status: "Limited",     highlight: false },
  { domain: "Board Accountability",     level: "ELEVATED", status: "Monitored",   highlight: false },
  { domain: "Housing Risk Multiplier",  level: "ELEVATED", status: "Monitored",   highlight: false },
  { domain: "Transparency",             level: "ELEVATED", status: "Monitored",   highlight: false },
  { domain: "Evidence Use",             level: "MEDIUM",   status: "Persistent",  highlight: false },
  { domain: "Workforce Capability",     level: "MEDIUM",   status: "Stable",      highlight: false },
];

export function SystemsRiskBrief2026() {
  useSEO({
    path: "/publications/national-systems-risk-brief-2026",
    title: "National Systems Risk Brief — Australia (2026)",
    description: "A structured analysis of systemic governance risks across Australian service systems, identifying critical gaps in early warning capability, escalation pathways, and cross-system intelligence.",
  });

  const C = { maxWidth: "900px", margin: "0 auto", padding: "0 32px" };

  return (
    <PublicLayout>

      {/* ── PAGE HEADER ──────────────────────────────────────────── */}
      <div style={{ background: NAV, borderBottom: `3px solid ${GOLD}`, padding: "56px 0 48px" }}>
        <div style={C}>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", fontWeight: 700, color: GOLD, letterSpacing: "0.14em", textTransform: "uppercase" as const, marginBottom: "16px" }}>
            Intelligence Publication &nbsp;·&nbsp; March 2026 &nbsp;·&nbsp; For Official Use
          </p>
          <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(24px, 4vw, 38px)", fontWeight: 700, color: "#fff", letterSpacing: "0.03em", lineHeight: 1.2, marginBottom: "20px" }}>
            National Systems Risk Brief<br />Australia (2026)
          </h1>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "17px", color: "rgba(255,255,255,0.8)", lineHeight: 1.6, maxWidth: "640px", marginBottom: "32px" }}>
            A structured analysis of systemic governance risks across Australian service systems, derived from aggregated lived experience intelligence and cross-system pattern recognition.
          </p>
          <a
            href="/National_Systems_Risk_Brief_Australia_2026.pdf"
            download
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "10px",
              background: GOLD,
              color: NAV,
              fontFamily: "'Source Sans 3', sans-serif",
              fontWeight: 700,
              fontSize: "14px",
              letterSpacing: "0.06em",
              textTransform: "uppercase" as const,
              textDecoration: "none",
              padding: "14px 28px",
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="square"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Download Full Brief (PDF)
          </a>
        </div>
      </div>

      {/* ── METADATA BAR ─────────────────────────────────────────── */}
      <div style={{ background: LIGHT, borderBottom: `1px solid ${BORDER}`, padding: "16px 0" }}>
        <div style={{ ...C, display: "flex", flexWrap: "wrap" as const, gap: "32px" }}>
          {[
            ["Produced by", "National Lived Experience Commission"],
            ["Classification", "For Official Use"],
            ["Date", "March 2026"],
            ["Jurisdiction", "Australia"],
          ].map(([k, v]) => (
            <div key={k}>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, color: GOLD, letterSpacing: "0.1em", textTransform: "uppercase" as const, marginBottom: "2px" }}>{k}</p>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: NAV, fontWeight: 600 }}>{v}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── MAIN CONTENT ─────────────────────────────────────────── */}
      <div style={{ background: "#fff", padding: "64px 0" }}>
        <div style={C}>

          {/* Executive Summary */}
          <section style={{ marginBottom: "56px" }}>
            <SectionLabel>Executive Summary</SectionLabel>
            <H2>Overview</H2>
            <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "16px", lineHeight: 1.75, color: TEXT, marginBottom: "20px" }}>
              The National Lived Experience Commission (NLEC) has identified five critical risk domains that threaten system integrity and public outcomes across Australian service systems. This brief presents a structured analysis derived from aggregated lived experience intelligence and cross-system pattern recognition.
            </p>
            <div style={{ background: NAV, padding: "24px 28px", marginBottom: "28px" }}>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, color: GOLD, letterSpacing: "0.1em", textTransform: "uppercase" as const, marginBottom: "12px" }}>Core System Risk Insight</p>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "16px", color: "#fff", lineHeight: 1.65, margin: 0 }}>
                Australia lacks a coherent systems intelligence layer capable of detecting, analysing, and escalating governance risks before they manifest as system failures requiring royal commission intervention.
              </p>
            </div>
            <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 600, color: NAV, marginBottom: "12px" }}>Key Findings</p>
            {[
              "Fragmented complaint intelligence prevents system-level pattern recognition and early warning capability",
              "Escalation threshold failures result in systemic issues being managed as isolated incidents",
              "Housing instability operates as a risk multiplier across all service domains",
              "Workforce capability gaps limit effective lived experience integration and governance oversight",
              "Data silos create early warning blindness, preventing proactive risk management",
            ].map((f, i) => (
              <div key={i} style={{ display: "flex", gap: "12px", marginBottom: "10px", alignItems: "flex-start" }}>
                <div style={{ width: "5px", height: "5px", background: GOLD, marginTop: "8px", flexShrink: 0 }} />
                <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", lineHeight: 1.6, color: TEXT, margin: 0 }}>{f}</p>
              </div>
            ))}
          </section>

          {/* Intended Audience */}
          <section style={{ marginBottom: "56px" }}>
            <SectionLabel>Intended Audience</SectionLabel>
            <H2>Who This Brief Is For</H2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px" }}>
              {[
                "Government departments and policy units",
                "Oversight bodies and commissioners",
                "Institutional boards and executive leadership",
                "Funders and commissioning authorities",
                "Service system regulators and reform agencies",
              ].map((a, i) => (
                <div key={i} style={{ borderLeft: `3px solid ${GOLD}`, paddingLeft: "14px", paddingTop: "4px", paddingBottom: "4px" }}>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: NAV, margin: 0, fontWeight: 600 }}>{a}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Risk Domains */}
          <section style={{ marginBottom: "56px" }}>
            <SectionLabel>Core Analysis</SectionLabel>
            <H2>Core Systemic Risk Domains</H2>
            <RiskDomain num={1} title="Fragmented Complaint Intelligence" level="HIGH"
              description="Complaint and feedback mechanisms operate in isolation across service systems, preventing aggregation and pattern analysis that would enable system-level risk detection."
              pattern="Individual complaints are processed within organisational boundaries without cross-referencing or trend analysis. Systemic issues present as recurring individual problems rather than identifiable patterns."
              consequence="Systemic failures will continue to manifest as crisis events. Vulnerable populations will experience repeated harm while system-level causes remain unidentified." />
            <RiskDomain num={2} title="Escalation Threshold Failure" level="CRITICAL"
              description="Issues that indicate systemic problems are managed as local incidents, failing to trigger appropriate escalation to system-level governance and oversight bodies."
              pattern="Service providers and middle management resolve problems locally to demonstrate competence, inadvertently suppressing signals that indicate broader system dysfunction requiring strategic intervention."
              consequence="Systemic problems will accumulate undetected until crisis threshold is reached, requiring expensive reactive interventions and potentially triggering royal commission processes." />
            <RiskDomain num={3} title="Housing Instability as Risk Multiplier" level="ELEVATED"
              description="Housing instability operates as a cross-system risk amplifier, increasing vulnerability and service complexity across health, mental health, disability, and family services domains."
              pattern="Housing instability creates cascading effects that increase service demand, reduce intervention effectiveness, and generate complex multi-system involvement."
              consequence="Service systems will experience increasing demand and decreasing effectiveness as housing instability amplifies underlying vulnerabilities." />
            <RiskDomain num={4} title="Workforce Capability Gap" level="MEDIUM"
              description="Lived experience roles remain underdeveloped and tokenistically integrated, limiting authentic governance participation and reducing systems intelligence capability."
              pattern="Lived experience positions are often created for compliance purposes without genuine authority, appropriate support, or integration into decision-making processes."
              consequence="Systems will continue to operate without authentic lived experience intelligence, reducing their capacity to detect emerging problems and implement effective improvements." />
            <RiskDomain num={5} title="Data Silo and Early Warning Blindness" level="HIGH"
              description="Data exists across multiple systems but remains unconnected, preventing synthesis and analysis that would enable early detection of emerging systemic risks."
              pattern="Individual organisations collect extensive data on service delivery and outcomes but lack mechanisms for cross-system analysis that would reveal systemic patterns."
              consequence="Systems will remain reactive rather than proactive, responding to crises after they occur rather than detecting and preventing them through early warning analysis." />
          </section>

          {/* Dashboard */}
          <section style={{ marginBottom: "56px" }}>
            <SectionLabel>Intelligence Dashboard</SectionLabel>
            <H2>Systems Intelligence Dashboard</H2>
            <div style={{ overflowX: "auto" as const }}>
              <table style={{ width: "100%", borderCollapse: "collapse" as const, fontFamily: "'Source Sans 3', sans-serif" }}>
                <thead>
                  <tr style={{ background: NAV }}>
                    <th style={{ padding: "10px 14px", textAlign: "left" as const, fontSize: "11px", fontWeight: 700, color: "#fff", letterSpacing: "0.08em", textTransform: "uppercase" as const }}>Domain</th>
                    <th style={{ padding: "10px 14px", textAlign: "left" as const, fontSize: "11px", fontWeight: 700, color: "#fff", letterSpacing: "0.08em", textTransform: "uppercase" as const }}>Risk Level</th>
                    <th style={{ padding: "10px 14px", textAlign: "left" as const, fontSize: "11px", fontWeight: 700, color: "#fff", letterSpacing: "0.08em", textTransform: "uppercase" as const }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {dashboard.map((row, i) => (
                    <tr key={i} style={{ background: row.highlight ? "#FFF3F3" : (i % 2 === 0 ? LIGHT : "#fff"), borderBottom: `1px solid ${BORDER}` }}>
                      <td style={{ padding: "11px 14px", fontSize: "14px", fontWeight: row.highlight ? 700 : 400, color: row.highlight ? riskColors.CRITICAL : TEXT, borderLeft: row.highlight ? `4px solid ${riskColors.CRITICAL}` : "4px solid transparent" }}>
                        {row.domain}
                      </td>
                      <td style={{ padding: "11px 14px" }}>
                        <Chip level={row.level} />
                      </td>
                      <td style={{ padding: "11px 14px", fontSize: "13px", color: MUTED }}>{row.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Illustrative Intelligence Observation */}
          <section style={{ marginBottom: "56px" }}>
            <SectionLabel>Intelligence Observation</SectionLabel>
            <H2>Illustrative Intelligence Observation</H2>
            <div style={{ borderLeft: `4px solid ${GOLD}`, background: LIGHT, padding: "24px 28px" }}>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", lineHeight: 1.75, color: TEXT, marginBottom: "20px" }}>
                Preliminary systems intelligence analysis indicates a recurring pattern across multiple service domains in which complaint escalation mechanisms fail to trigger system-level review.
              </p>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 700, color: NAV, marginBottom: "12px", textTransform: "uppercase" as const, letterSpacing: "0.08em" }}>Observed indicators include:</p>
              {[
                "Repeated complaint themes across separate organisations",
                "Local resolution of issues without cross-system escalation",
                "Absence of aggregation mechanisms to identify systemic patterns",
                "Limited visibility of recurring risks at governance level",
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", gap: "12px", marginBottom: "8px", alignItems: "flex-start" }}>
                  <div style={{ width: "5px", height: "5px", background: GOLD, marginTop: "8px", flexShrink: 0 }} />
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", lineHeight: 1.6, color: TEXT, margin: 0 }}>{item}</p>
                </div>
              ))}
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", lineHeight: 1.7, color: MUTED, marginTop: "16px", marginBottom: 0, fontStyle: "italic" as const }}>
                This pattern is consistent with escalation threshold failure and fragmented complaint intelligence, reinforcing the assessment that early warning capability remains underdeveloped across service systems.
              </p>
            </div>
          </section>

          {/* Strategic Recommendations */}
          <section style={{ marginBottom: "56px" }}>
            <SectionLabel>Recommendations</SectionLabel>
            <H2>Strategic Recommendations</H2>
            {[
              ["Establish National Systems Intelligence Layer", "Develop structured intelligence capability that operates across system boundaries to detect, analyse, and escalate governance risks before they manifest as system failures."],
              ["Standardise Evidence Integration", "Implement consistent mechanisms for collecting, analysing, and utilising lived experience evidence across all service systems to inform governance and strategic decision-making."],
              ["Strengthen Escalation Pathways", "Create clear escalation mechanisms that ensure systemic issues are identified and addressed at appropriate governance levels rather than being managed as isolated incidents."],
              ["Embed Lived Experience Governance Standards", "Establish mandatory standards for authentic lived experience participation in governance processes across all publicly funded service systems."],
              ["Improve Cross-System Data Synthesis", "Develop technical and governance arrangements that enable cross-system data analysis and pattern recognition while maintaining appropriate privacy and security protections."],
            ].map(([title, detail], i) => (
              <div key={i} style={{ display: "flex", gap: "20px", marginBottom: "24px", alignItems: "flex-start" }}>
                <div style={{ width: "36px", height: "36px", background: NAV, color: GOLD, fontFamily: "'Cinzel', serif", fontSize: "14px", fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{i + 1}</div>
                <div>
                  <p style={{ fontFamily: "'Cinzel', serif", fontSize: "14px", fontWeight: 600, color: NAV, marginBottom: "6px" }}>{title}</p>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", lineHeight: 1.65, color: TEXT, margin: 0 }}>{detail}</p>
                </div>
              </div>
            ))}
          </section>

          {/* Engagement Pathway */}
          <section style={{ background: NAV, padding: "40px", marginBottom: "56px" }}>
            <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", fontWeight: 700, color: GOLD, letterSpacing: "0.14em", textTransform: "uppercase" as const, marginBottom: "14px" }}>Engagement Pathway</p>
            <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "22px", fontWeight: 600, color: "#fff", marginBottom: "20px" }}>Work with the Commission</h2>
            <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", color: "rgba(255,255,255,0.85)", lineHeight: 1.65, marginBottom: "24px" }}>
              Organisations and government entities may engage with the National Lived Experience Commission through structured systems intelligence activities, including:
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px", marginBottom: "28px" }}>
              {[
                "Baseline governance intelligence assessments",
                "Systems intelligence pilot engagements",
                "Advisory briefings and risk analysis",
                "Governance standard implementation support",
              ].map((item, i) => (
                <div key={i} style={{ borderTop: `2px solid ${GOLD}`, paddingTop: "12px" }}>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: "#fff", margin: 0, lineHeight: 1.5 }}>{item}</p>
                </div>
              ))}
            </div>
            <Link href="/contact" style={{ display: "inline-block", background: GOLD, color: NAV, fontFamily: "'Source Sans 3', sans-serif", fontWeight: 700, fontSize: "13px", letterSpacing: "0.06em", textTransform: "uppercase" as const, textDecoration: "none", padding: "12px 28px" }}>
              Request Initial Engagement
            </Link>
          </section>

          {/* Download CTA */}
          <section style={{ textAlign: "center" as const, borderTop: `1px solid ${BORDER}`, paddingTop: "48px" }}>
            <p style={{ fontFamily: "'Cinzel', serif", fontSize: "20px", fontWeight: 600, color: NAV, marginBottom: "12px" }}>Download the Full Brief</p>
            <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", color: MUTED, marginBottom: "28px", maxWidth: "480px", margin: "0 auto 28px" }}>
              The complete brief is available as a formatted PDF suitable for distribution and tabling at governance meetings.
            </p>
            <a
              href="/National_Systems_Risk_Brief_Australia_2026.pdf"
              download
              style={{ display: "inline-flex", alignItems: "center", gap: "10px", background: NAV, color: "#fff", fontFamily: "'Source Sans 3', sans-serif", fontWeight: 700, fontSize: "14px", letterSpacing: "0.06em", textTransform: "uppercase" as const, textDecoration: "none", padding: "16px 36px" }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="square"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Download Full Brief (PDF)
            </a>
          </section>

        </div>
      </div>

    </PublicLayout>
  );
}
