import { PublicLayout } from "@/components/layout/PublicLayout";
import { useListResearchPrograms, useGetResearchProgram } from "@workspace/api-client-react";
import { useSEO } from "@/lib/useSEO";
import { Link, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, FlaskConical, Target, BookOpen, Layers } from "lucide-react";

export function ResearchList() {
  useSEO({ path: "/research", title: "Research Programs", description: "NLEC research programs examining systemic governance failures, lived experience integration, and institutional accountability across Australian service systems." });
  const { data: programs, isLoading } = useListResearchPrograms();

  const icons = [FlaskConical, Target, Layers];

  return (
    <PublicLayout>
      <title>Research Programs | National Lived Experience Commission</title>
      <div className="bg-gray-50 border-b py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="inline-flex items-center px-3 py-1 border border-secondary/30 text-secondary text-xs font-bold tracking-wider mb-4">
            RESEARCH PROGRAMS
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-primary mb-6">Research and Evidence Programs</h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            NLEC's research programs build the national evidence base for lived experience governance reform, systems intelligence, and structural accountability.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-6xl">
        {isLoading ? (
          <div className="space-y-8">
            {[1,2,3].map(i => <div key={i} className="h-56 bg-gray-100 animate-pulse border" />)}
          </div>
        ) : (
          <div className="space-y-8">
            {(programs || []).map((prog, i) => {
              const Icon = icons[i % icons.length];
              return (
                <div key={prog.id} className="bg-white border border-gray-200 p-8 md:p-10 hover:border-secondary hover:shadow-md transition-all group flex flex-col md:flex-row gap-8">
                  <div className="md:w-20 flex-shrink-0">
                    <div className="w-16 h-16 bg-secondary/10 border border-secondary/20 flex items-center justify-center">
                      <Icon className="h-8 w-8 text-secondary" />
                    </div>
                    <div className="mt-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Program {String(i+1).padStart(2,"0")}</div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl md:text-3xl font-serif font-bold text-primary mb-4 group-hover:text-secondary transition-colors">
                      <Link href={`/research/${prog.id}`}>{prog.title}</Link>
                    </h3>
                    <p className="text-gray-600 leading-relaxed mb-6 line-clamp-4">{prog.overview}</p>
                    <Link href={`/research/${prog.id}`} className="inline-flex items-center text-sm font-semibold text-secondary hover:text-secondary/80">
                      Explore Program <ChevronLeft className="h-4 w-4 rotate-180 ml-1" />
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-20 bg-primary text-white p-12 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl font-serif font-bold mb-2">Contribute to NLEC Research</h2>
            <p className="text-white/80">Submit evidence, participate in consultations, or apply to join a research advisory group.</p>
          </div>
          <Button asChild className="bg-accent hover:bg-accent/90 text-white rounded-none whitespace-nowrap flex-shrink-0">
            <Link href="/submit-evidence">Submit Evidence</Link>
          </Button>
        </div>
      </div>
    </PublicLayout>
  );
}

export function ResearchDetail() {
  const { id } = useParams<{ id: string }>();
  const { data: prog, isLoading } = useGetResearchProgram(parseInt(id || "0"));

  if (isLoading) return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-24 max-w-4xl">
        <div className="space-y-4">
          {[1,2,3,4].map(i => <div key={i} className="h-6 bg-gray-100 animate-pulse rounded" />)}
        </div>
      </div>
    </PublicLayout>
  );

  if (!prog) return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-24 max-w-4xl text-center">
        <h1 className="text-3xl font-serif text-primary mb-4">Research Program Not Found</h1>
        <Link href="/research" className="text-secondary underline">Return to Research Programs</Link>
      </div>
    </PublicLayout>
  );

  const sections = [
    { title: "Program Overview", content: prog.overview, icon: BookOpen },
    { title: "Objectives", content: prog.objectives, icon: Target },
    { title: "Current Focus Areas", content: prog.currentFocusAreas, icon: FlaskConical },
    { title: "Outputs", content: prog.outputs, icon: Layers },
    { title: "Methodology", content: prog.methodology, icon: FlaskConical },
  ].filter(s => s.content);

  return (
    <PublicLayout>
      <title>{prog.title} | NLEC Research</title>
      <div className="bg-gray-50 border-b py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <Link href="/research" className="inline-flex items-center text-sm text-gray-500 hover:text-secondary mb-6 transition-colors">
            <ChevronLeft className="h-4 w-4 mr-1" /> Research Programs
          </Link>
          <div className="inline-block px-3 py-1 bg-secondary/10 border border-secondary/30 text-secondary text-xs font-bold tracking-widest mb-4">
            RESEARCH PROGRAM
          </div>
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary leading-tight">{prog.title}</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="space-y-12">
          {sections.map(({ title, content, icon: Icon }) => (
            <div key={title} className="border-l-4 border-secondary pl-6">
              <div className="flex items-center gap-3 mb-4">
                <Icon className="h-5 w-5 text-secondary" />
                <h2 className="text-xl font-serif font-bold text-primary">{title}</h2>
              </div>
              <div className="text-gray-700 leading-relaxed space-y-3">
                {content!.split("\n").map((line, i) => (
                  <p key={i} className={line.match(/^\d+\./) ? "pl-4" : ""}>{line}</p>
                ))}
              </div>
            </div>
          ))}

          {prog.relatedPublications && (
            <div className="bg-gray-50 border border-gray-200 p-6">
              <h2 className="text-lg font-serif font-bold text-primary mb-3">Related Publications</h2>
              <p className="text-gray-600">{prog.relatedPublications}</p>
              <Link href="/publications" className="mt-3 inline-flex items-center text-sm font-semibold text-secondary hover:text-secondary/80">
                Browse Publications Repository <ChevronLeft className="h-4 w-4 rotate-180 ml-1" />
              </Link>
            </div>
          )}
        </div>

        <div className="mt-12 flex flex-col sm:flex-row gap-4">
          <Button asChild className="bg-secondary hover:bg-secondary/90 text-white rounded-none">
            <Link href="/submit-evidence">Submit Evidence to This Program</Link>
          </Button>
          <Button variant="outline" asChild className="rounded-none border-primary text-primary hover:bg-primary hover:text-white">
            <Link href="/research">All Research Programs</Link>
          </Button>
        </div>
      </div>
    </PublicLayout>
  );
}
