import { PublicLayout } from "@/components/layout/PublicLayout";
import { useListStandards, useGetStandardBySlug } from "@workspace/api-client-react";
import { useSEO } from "@/lib/useSEO";
import { Link, useParams } from "wouter";
import { ChevronLeft, Download, FileText, ArrowRight } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

const NAV = "#0B1F3A";
const GOLD = "#C6A85A";
const BORDER = "#E5E5E5";
const TEXT = "#1A1A1A";
const MUTED = "#6B6B6B";

const CATEGORIES = [
  "Governance",
  "Lived Experience Workforce",
  "Engagement Practice",
  "Accountability",
  "Evidence and Intelligence",
  "Safeguarding",
];

const STATUS_OPTS = ["Active", "Draft", "Archived"];

function StatusBadge({ status }: { status: string }) {
  const colours: Record<string, { bg: string; text: string; border: string }> = {
    Active:   { bg: "#F0F7F0", text: "#1B5E20", border: "#A5D6A7" },
    Draft:    { bg: "#FFF8E1", text: "#7B5800", border: "#FFCC80" },
    Archived: { bg: "#F5F5F5", text: "#616161", border: "#BDBDBD" },
  };
  const c = colours[status] ?? colours.Draft;
  return (
    <span style={{
      display: "inline-block",
      fontSize: "10px",
      fontWeight: 700,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      padding: "3px 8px",
      background: c.bg,
      color: c.text,
      border: `1px solid ${c.border}`,
    }}>
      {status}
    </span>
  );
}

export function StandardsList() {
  useSEO({
    path: "/standards",
    title: "Standards Library",
    description: "The NLEC Standards Library contains 10 active governance standards for lived experience integration in Australian institutions — covering governance, workforce, engagement, accountability, and systems intelligence.",
  });

  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const { data: standards, isLoading } = useListStandards();

  const filtered = (standards || []).filter(s => {
    const matchSearch = !search ||
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.code.toLowerCase().includes(search.toLowerCase()) ||
      s.overview.toLowerCase().includes(search.toLowerCase());
    const matchCat = !catFilter || s.category === catFilter;
    const matchStatus = !statusFilter || s.status === statusFilter;
    return matchSearch && matchCat && matchStatus;
  });

  const hasFilter = Boolean(search || catFilter || statusFilter);

  return (
    <PublicLayout>
      <div style={{ background: NAV, borderBottom: `4px solid ${GOLD}`, padding: "80px 0 56px" }}>
        <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "0 24px" }}>
          <div style={{ fontSize: "10px", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", color: GOLD, marginBottom: "16px", fontFamily: "'Source Sans 3', sans-serif" }}>
            NLEC Standards Library
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(28px, 5vw, 48px)", fontWeight: 700, color: "#fff", margin: "0 0 16px", lineHeight: 1.15 }}>
            Governance Standards
          </h1>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "17px", color: "rgba(255,255,255,0.75)", maxWidth: "640px", lineHeight: 1.65, margin: "0 0 40px" }}>
            Governance codes of practice for the structural integration of lived experience in Australian institutions. Ten active standards covering governance architecture, workforce, engagement, accountability, and systems intelligence.
          </p>

          <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
            <div style={{ position: "relative", flex: "1 1 280px", maxWidth: "420px" }}>
              <input
                type="text"
                placeholder="Search by code, title, or keyword…"
                value={search}
                onChange={e => setSearch(e.target.value)}
                style={{
                  width: "100%",
                  height: "44px",
                  padding: "0 16px 0 44px",
                  background: "rgba(255,255,255,0.08)",
                  border: "1px solid rgba(255,255,255,0.2)",
                  color: "#fff",
                  fontFamily: "'Source Sans 3', sans-serif",
                  fontSize: "14px",
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
              <span style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.4)", pointerEvents: "none", fontSize: "16px" }}>⌕</span>
            </div>

            <select
              value={catFilter}
              onChange={e => setCatFilter(e.target.value)}
              style={{ height: "44px", padding: "0 14px", background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", color: catFilter ? "#fff" : "rgba(255,255,255,0.55)", fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", outline: "none" }}
            >
              <option value="">All Categories</option>
              {CATEGORIES.map(c => <option key={c} value={c} style={{ color: TEXT, background: "#fff" }}>{c}</option>)}
            </select>

            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              style={{ height: "44px", padding: "0 14px", background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", color: statusFilter ? "#fff" : "rgba(255,255,255,0.55)", fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", outline: "none" }}
            >
              <option value="">All Statuses</option>
              {STATUS_OPTS.map(s => <option key={s} value={s} style={{ color: TEXT, background: "#fff" }}>{s}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "48px 24px" }}>
        {hasFilter && (
          <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "24px" }}>
            <span style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: MUTED }}>
              {filtered.length} standard{filtered.length !== 1 ? "s" : ""} found
            </span>
            <button
              onClick={() => { setSearch(""); setCatFilter(""); setStatusFilter(""); }}
              style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: GOLD, background: "none", border: "none", cursor: "pointer", padding: 0, textDecoration: "underline" }}
            >
              Clear filters
            </button>
          </div>
        )}

        {isLoading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            {[1, 2, 3, 4].map(i => (
              <div key={i} style={{ height: "120px", background: "#f5f5f5", border: `1px solid ${BORDER}`, animation: "pulse 1.5s infinite" }} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "80px 0", color: MUTED, fontFamily: "'Source Sans 3', sans-serif" }}>
            <div style={{ fontSize: "32px", marginBottom: "12px", opacity: 0.3 }}>⊘</div>
            <p>No standards match your current filters.</p>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
            {filtered.map(std => (
              <div key={std.id} style={{
                background: "#fff",
                border: `1px solid ${BORDER}`,
                borderLeft: `4px solid transparent`,
                display: "grid",
                gridTemplateColumns: "180px 1fr auto",
                gap: "24px",
                padding: "28px 32px",
                alignItems: "start",
                transition: "border-color 0.15s",
              }}
                onMouseEnter={e => (e.currentTarget.style.borderLeftColor = GOLD)}
                onMouseLeave={e => (e.currentTarget.style.borderLeftColor = "transparent")}
              >
                <div>
                  <div style={{
                    display: "inline-block",
                    fontFamily: "monospace",
                    fontSize: "11px",
                    fontWeight: 700,
                    letterSpacing: "0.06em",
                    background: NAV,
                    color: "#fff",
                    padding: "4px 10px",
                    marginBottom: "10px",
                  }}>
                    {std.code}
                  </div>
                  <div style={{ marginTop: "8px" }}>
                    <StatusBadge status={std.status} />
                  </div>
                  <div style={{ marginTop: "10px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", color: MUTED, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                    {std.category}
                  </div>
                </div>

                <div>
                  <h3 style={{ fontFamily: "'Cinzel', serif", fontSize: "17px", fontWeight: 600, color: NAV, margin: "0 0 10px", lineHeight: 1.3 }}>
                    <Link href={`/standards/${std.code.toLowerCase()}`} style={{ color: "inherit", textDecoration: "none" }}>
                      {std.title}
                    </Link>
                  </h3>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: TEXT, lineHeight: 1.65, margin: 0, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                    {std.overview}
                  </p>
                </div>

                <div style={{ paddingTop: "4px" }}>
                  <Link
                    href={`/standards/${std.code.toLowerCase()}`}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "6px",
                      fontFamily: "'Source Sans 3', sans-serif",
                      fontSize: "12px",
                      fontWeight: 700,
                      letterSpacing: "0.06em",
                      textTransform: "uppercase",
                      color: NAV,
                      textDecoration: "none",
                      borderBottom: `2px solid ${GOLD}`,
                      paddingBottom: "2px",
                      whiteSpace: "nowrap",
                    }}
                  >
                    View Standard <ArrowRight size={12} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}

        <div style={{ marginTop: "48px", padding: "24px 28px", background: "#F8F8F8", border: `1px solid ${BORDER}`, borderLeft: `4px solid ${GOLD}` }}>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: MUTED, margin: 0, lineHeight: 1.6 }}>
            NLEC governance standards are live reference documents subject to review. All standards are free to access. For implementation support, assessment services, or questions about standards application, contact the Commission.
          </p>
        </div>
      </div>
    </PublicLayout>
  );
}

export function StandardDetail() {
  const params = useParams<{ id: string }>();
  const slug = params.id || "";
  const { data: std, isLoading, isError } = useGetStandardBySlug(slug);

  useSEO({
    path: `/standards/${slug}`,
    title: std ? `${std.code} — ${std.title}` : "Standard",
    description: std?.overview ?? "NLEC governance standard for lived experience integration in Australian institutions.",
  });

  if (isLoading) return (
    <PublicLayout>
      <div style={{ minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: "40px", height: "40px", border: `3px solid ${BORDER}`, borderTopColor: GOLD, borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
      </div>
    </PublicLayout>
  );

  if (isError || !std) return (
    <PublicLayout>
      <div style={{ padding: "80px 24px", textAlign: "center", maxWidth: "600px", margin: "0 auto" }}>
        <div style={{ fontFamily: "'Cinzel', serif", fontSize: "48px", color: BORDER, marginBottom: "24px" }}>404</div>
        <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: "24px", color: NAV, marginBottom: "12px" }}>Standard Not Found</h1>
        <p style={{ fontFamily: "'Source Sans 3', sans-serif", color: MUTED, marginBottom: "28px" }}>The standard you requested could not be located in the Standards Library.</p>
        <Link href="/standards" style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 700, color: NAV, textDecoration: "none", borderBottom: `2px solid ${GOLD}`, paddingBottom: "2px", letterSpacing: "0.06em", textTransform: "uppercase" }}>
          Return to Standards Library
        </Link>
      </div>
    </PublicLayout>
  );

  const publishedDate = std.publishedAt ? format(new Date(std.publishedAt), "d MMMM yyyy") : null;

  const sections = [
    { num: "1", heading: "Purpose", content: std.purpose },
    { num: "2", heading: "Scope of Application", content: std.scope },
    { num: "3", heading: "Key Principles", content: std.keyPrinciples },
    { num: "4", heading: "Implementation Requirements", content: std.implementationConsiderations },
  ].filter(s => s.content);

  return (
    <PublicLayout>
      <div style={{ background: NAV, borderBottom: `4px solid ${GOLD}`, padding: "60px 0 48px" }}>
        <div style={{ maxWidth: "980px", margin: "0 auto", padding: "0 24px" }}>
          <Link href="/standards" style={{
            display: "inline-flex", alignItems: "center", gap: "6px",
            fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700,
            letterSpacing: "0.08em", textTransform: "uppercase", color: "rgba(255,255,255,0.55)",
            textDecoration: "none", marginBottom: "32px",
          }}>
            <ChevronLeft size={14} /> Standards Library
          </Link>

          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px", flexWrap: "wrap" }}>
            <span style={{ fontFamily: "monospace", fontSize: "12px", fontWeight: 700, letterSpacing: "0.06em", background: GOLD, color: NAV, padding: "5px 12px" }}>
              {std.code}
            </span>
            <StatusBadge status={std.status} />
            <span style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", color: "rgba(255,255,255,0.5)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
              {std.category}
            </span>
          </div>

          <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(22px, 4vw, 38px)", fontWeight: 700, color: "#fff", margin: "0 0 20px", lineHeight: 1.2 }}>
            {std.title}
          </h1>

          <div style={{ display: "flex", gap: "28px", flexWrap: "wrap" }}>
            {publishedDate && (
              <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: "rgba(255,255,255,0.55)" }}>
                <span style={{ color: GOLD, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", fontSize: "10px", display: "block", marginBottom: "2px" }}>Published</span>
                {publishedDate}
              </div>
            )}
            <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: "rgba(255,255,255,0.55)" }}>
              <span style={{ color: GOLD, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", fontSize: "10px", display: "block", marginBottom: "2px" }}>Reference</span>
              {std.code}
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: "980px", margin: "0 auto", padding: "48px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: "48px", alignItems: "start" }}>

          <div>
            <div style={{ background: "#F8F8F8", borderLeft: `4px solid ${GOLD}`, padding: "24px 28px", marginBottom: "40px" }}>
              <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: GOLD, marginBottom: "10px" }}>Overview</div>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "16px", color: TEXT, lineHeight: 1.7, margin: 0 }}>{std.overview}</p>
            </div>

            {sections.map(sec => (
              <div key={sec.num} style={{ marginBottom: "40px" }}>
                <div style={{ display: "flex", alignItems: "baseline", gap: "16px", marginBottom: "16px", paddingBottom: "12px", borderBottom: `1px solid ${BORDER}` }}>
                  <span style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", fontWeight: 700, color: GOLD, letterSpacing: "0.1em" }}>{sec.num}</span>
                  <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "18px", fontWeight: 600, color: NAV, margin: 0 }}>{sec.heading}</h2>
                </div>
                <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", color: TEXT, lineHeight: 1.75, margin: 0 }}>
                  {sec.content}
                </p>
              </div>
            ))}
          </div>

          <div style={{ position: "sticky", top: "24px", display: "flex", flexDirection: "column", gap: "24px" }}>
            <div style={{ background: "#fff", border: `1px solid ${BORDER}`, padding: "24px" }}>
              <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: GOLD, marginBottom: "16px" }}>
                Downloads
              </div>
              <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "10px" }}>
                {[
                  { label: "Full Standard (PDF)" },
                  { label: "Implementation Guide" },
                  { label: "Quick Reference Card" },
                ].map(item => (
                  <li key={item.label}>
                    <a href="#" style={{
                      display: "flex", alignItems: "center", gap: "10px",
                      fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px",
                      color: NAV, textDecoration: "none",
                    }}
                      onClick={e => e.preventDefault()}
                    >
                      <FileText size={14} style={{ color: GOLD, flexShrink: 0 }} />
                      <span style={{ borderBottom: `1px solid ${BORDER}`, paddingBottom: "1px" }}>{item.label}</span>
                    </a>
                  </li>
                ))}
              </ul>
              <div style={{ marginTop: "14px", paddingTop: "14px", borderTop: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "11px", color: MUTED }}>
                PDF editions available shortly.
              </div>
            </div>

            {std.relatedPublications && (
              <div style={{ background: "#F8F8F8", border: `1px solid ${BORDER}`, padding: "24px" }}>
                <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: GOLD, marginBottom: "12px" }}>
                  Related Publications
                </div>
                <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: TEXT, lineHeight: 1.6, margin: "0 0 12px" }}>
                  {std.relatedPublications}
                </p>
                <Link href="/publications" style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, color: NAV, textDecoration: "none", borderBottom: `1px solid ${GOLD}`, paddingBottom: "1px", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                  Browse Publications →
                </Link>
              </div>
            )}

            <div style={{ background: NAV, padding: "24px" }}>
              <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: GOLD, marginBottom: "12px" }}>
                Assessment Services
              </div>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: "rgba(255,255,255,0.75)", lineHeight: 1.6, margin: "0 0 16px" }}>
                Organisations can request independent assessment of alignment with this standard through the NLEC Assessment Program.
              </p>
              <Link href="/governance-assessment" style={{
                display: "inline-block",
                fontFamily: "'Source Sans 3', sans-serif",
                fontSize: "11px",
                fontWeight: 700,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                color: GOLD,
                textDecoration: "none",
                border: `1px solid ${GOLD}`,
                padding: "8px 14px",
              }}>
                Assessment Program
              </Link>
            </div>
          </div>
        </div>

        <div style={{ marginTop: "48px", paddingTop: "32px", borderTop: `1px solid ${BORDER}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "16px" }}>
          <Link href="/standards" style={{ display: "inline-flex", alignItems: "center", gap: "6px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", color: NAV, textDecoration: "none", borderBottom: `2px solid ${GOLD}`, paddingBottom: "2px" }}>
            <ChevronLeft size={14} /> All Standards
          </Link>
          <span style={{ fontFamily: "monospace", fontSize: "11px", color: MUTED }}>{std.code} · {std.status}</span>
        </div>
      </div>
    </PublicLayout>
  );
}
