import { PublicLayout } from "@/components/layout/PublicLayout";
import { CTASection, InfoCard, PageHeader, SectionHeading } from "@/components/site";
import { intelligenceStages } from "@/lib/site";
import { useSEO } from "@/lib/useSEO";

export function LivedExperienceIntelligence() {
  useSEO({
    path: "/lived-experience-intelligence",
    title: "Lived Experience Intelligence",
    description: "NLEC's signature explanation of how lived experience becomes operational intelligence for national reform.",
  });

  return (
    <PublicLayout>
      <PageHeader
        eyebrow="Lived Experience Intelligence"
        title="The Commission's core idea: lived experience is operational intelligence"
        description="This is NLEC's signature framework. It explains how carefully gathered lived experience can move from testimony to evidence, and from evidence to reform."
      />

      <section className="section-block">
        <div className="site-container">
          <div className="muted-panel grid gap-6 lg:grid-cols-[1fr_1.1fr] lg:items-start">
            <div>
              <p className="card-kicker">Operational cycle</p>
              <h2 className="font-serif text-[clamp(1.8rem,3vw,2.5rem)] leading-[1.05] tracking-[0.02em] text-[color:var(--nav)]">
                From listening to change
              </h2>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {["listen", "analyse", "translate", "act"].map((step) => (
                <div key={step} className="rounded-2xl border border-[color:var(--line)] bg-white px-4 py-4">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-[color:var(--gold)]">
                    Stage
                  </p>
                  <p className="mt-2 font-serif text-xl tracking-[0.03em] text-[color:var(--nav)]">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container">
          <SectionHeading
            eyebrow="Framework"
            title="A careful chain from testimony to institutional learning"
            description="The Commission's approach is not extractive. It is designed to preserve meaning, identify patterns and translate them into practical reform work."
          />
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {intelligenceStages.map((item) => (
              <InfoCard key={item.title} kicker="Principle" title={item.title} description={item.description} />
            ))}
          </div>
        </div>
      </section>

      <section className="section-block">
        <div className="site-container grid gap-6 lg:grid-cols-3">
          <InfoCard
            kicker="Blind spots"
            title="Identifying system blind spots"
            description="Aggregate evidence can show where institutions stop seeing the consequences of their own processes."
          />
          <InfoCard
            kicker="Harm reduction"
            title="Reducing harm"
            description="Earlier recognition of risk creates more room for prevention, repair and better decision-making."
          />
          <InfoCard
            kicker="Service design"
            title="Improving service design"
            description="Lived experience keeps human impact visible while services are designed, reviewed and implemented."
          />
          <InfoCard
            kicker="Accountability"
            title="Strengthening accountability"
            description="Structured evidence makes it easier to ask who knew what, when, and what they did in response."
          />
          <InfoCard
            kicker="Ethics"
            title="Ethical use of lived experience"
            description="NLEC uses consent-aware, trauma-informed and dignity-centred methods to reduce risk to participants."
          />
          <InfoCard
            kicker="Reform"
            title="From evidence to reform"
            description="The point of the work is practical change in policy, governance, service design and public debate."
          />
        </div>
      </section>

      <CTASection
        title="Need to translate experience into evidence?"
        description="NLEC can help design the process, frame the questions and shape the outputs so that lived experience is used carefully and effectively."
        primary={{ label: "Discuss a partnership", href: "/services" }}
        secondary={{ label: "Contact us", href: "/contact" }}
      />
    </PublicLayout>
  );
}
