import { PublicLayout } from "@/components/layout/PublicLayout";
import { CTASection, InfoCard, PageHeader, SectionHeading } from "@/components/site";
import { workPrograms } from "@/lib/site";
import { useSEO } from "@/lib/useSEO";

export function OurWork() {
  useSEO({
    path: "/our-work",
    title: "Our Work",
    description: "Public debate and reform, lived-experience evidence, policy submissions, commissioned research and institutional advisory work at NLEC.",
  });

  return (
    <PublicLayout>
      <PageHeader
        eyebrow="Our Work"
        title="Practical workstreams that turn lived experience into reform"
            description="NLEC's work is designed to be public-interest focused, nationally relevant and useful to institutions that want to improve how they operate."
      />

      <section className="section-block">
        <div className="site-container">
          <SectionHeading
            eyebrow="Program areas"
            title="A broad reform agenda with clear, disciplined boundaries"
            description="Each workstream is separate, but they all move toward the same goal: better public debate, stronger accountability and better human outcomes."
          />
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {workPrograms.map((item, index) => (
              <article key={item.title} className="site-card">
                <p className="card-kicker">0{index + 1}</p>
                <h3 className="card-title">{item.title}</h3>
                <p className="card-copy">{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container grid gap-6 lg:grid-cols-3">
          <InfoCard
            kicker="Public debate"
            title="Explain the human impact of systems"
            description="NLEC contributes to public conversation by making lived experience visible in a structured and careful way."
          />
          <InfoCard
            kicker="Reform"
            title="Support institutions to learn"
            description="The Commission translates evidence into recommendations that can be acted on within existing governance and service settings."
          />
          <InfoCard
            kicker="Accountability"
            title="Make failure patterns harder to ignore"
            description="NLEC helps institutions see where repeated harm, omission or weak design are creating unacceptable outcomes."
          />
        </div>
      </section>

      <CTASection
        title="Need a structured engagement or advisory scope?"
        description="NLEC can shape the brief, method and outputs so the work stays useful, ethical and aligned to public-interest reform."
        primary={{ label: "Discuss a partnership", href: "/services" }}
        secondary={{ label: "View publications", href: "/publications" }}
      />
    </PublicLayout>
  );
}
