import { PublicLayout } from "@/components/layout/PublicLayout";
import { useListNewsPosts, useGetNewsPost } from "@workspace/api-client-react";
import { Link, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Calendar, Tag } from "lucide-react";
import { format } from "date-fns";

const categoryColors: Record<string, string> = {
  "Announcement": "bg-primary/10 text-primary border-primary/30",
  "Research": "bg-secondary/10 text-secondary border-secondary/30",
  "Consultation": "bg-accent/10 text-amber-700 border-accent/30",
  "Intelligence": "bg-slate-100 text-slate-700 border-slate-300",
};

export function NewsList() {
  const { data: posts, isLoading } = useListNewsPosts();

  return (
    <PublicLayout>
      <title>News and Updates | National Lived Experience Commission</title>
      <div className="bg-gray-50 border-b py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="inline-flex items-center px-3 py-1 border border-secondary/30 text-secondary text-xs font-bold tracking-wider mb-4">
            NEWS AND UPDATES
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-primary mb-6">Commission Announcements</h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            Latest announcements, research releases, consultation invitations, and intelligence bulletins from the National Lived Experience Commission.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-6xl">
        {isLoading ? (
          <div className="space-y-6">
            {[1,2,3].map(i => <div key={i} className="h-40 bg-gray-100 animate-pulse border" />)}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {(posts || []).map((post, i) => (
              <div key={post.id} className={`bg-white border border-gray-200 p-6 md:p-8 hover:border-secondary hover:shadow-md transition-all group ${i === 0 ? "md:col-span-2" : ""}`}>
                <div className="flex flex-wrap gap-3 mb-4">
                  {post.category && (
                    <span className={`text-xs font-bold tracking-wide px-3 py-1 border ${categoryColors[post.category] || "bg-gray-100 text-gray-600 border-gray-200"}`}>
                      {post.category}
                    </span>
                  )}
                  {post.publishedAt && (
                    <span className="inline-flex items-center gap-1 text-xs text-gray-500">
                      <Calendar className="h-3 w-3" />
                      {format(new Date(post.publishedAt), "d MMMM yyyy")}
                    </span>
                  )}
                </div>
                <h3 className={`font-serif font-bold text-primary mb-3 group-hover:text-secondary transition-colors ${i === 0 ? "text-2xl md:text-3xl" : "text-xl"}`}>
                  <Link href={`/news/${post.id}`}>{post.title}</Link>
                </h3>
                <p className="text-gray-600 leading-relaxed mb-4 line-clamp-3">{post.summary}</p>
                <Link href={`/news/${post.id}`} className="inline-flex items-center text-sm font-semibold text-secondary hover:text-secondary/80 transition-colors">
                  Read full announcement <ChevronLeft className="h-4 w-4 rotate-180 ml-1" />
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </PublicLayout>
  );
}

export function NewsDetail() {
  const { id } = useParams<{ id: string }>();
  const { data: post, isLoading } = useGetNewsPost(parseInt(id || "0"));

  if (isLoading) return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-24 max-w-3xl">
        <div className="space-y-4">
          {[1,2,3,4].map(i => <div key={i} className="h-6 bg-gray-100 animate-pulse rounded" />)}
        </div>
      </div>
    </PublicLayout>
  );

  if (!post) return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-24 max-w-3xl text-center">
        <h1 className="text-3xl font-serif text-primary mb-4">Announcement Not Found</h1>
        <Link href="/news" className="text-secondary underline">Return to News</Link>
      </div>
    </PublicLayout>
  );

  return (
    <PublicLayout>
      <title>{post.title} | NLEC News</title>
      <div className="bg-gray-50 border-b py-12">
        <div className="container mx-auto px-4 max-w-3xl">
          <Link href="/news" className="inline-flex items-center text-sm text-gray-500 hover:text-secondary mb-6 transition-colors">
            <ChevronLeft className="h-4 w-4 mr-1" /> News and Updates
          </Link>
          <div className="flex flex-wrap gap-3 mb-4">
            {post.category && (
              <span className={`text-xs font-bold tracking-wide px-3 py-1 border ${categoryColors[post.category] || "bg-gray-100 text-gray-600 border-gray-200"}`}>
                {post.category}
              </span>
            )}
            {post.publishedAt && (
              <span className="inline-flex items-center gap-1 text-xs text-gray-500">
                <Calendar className="h-3 w-3" />
                {format(new Date(post.publishedAt), "d MMMM yyyy")}
              </span>
            )}
          </div>
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary leading-tight">{post.title}</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-3xl">
        <p className="text-xl text-gray-600 leading-relaxed mb-10 font-light border-l-4 border-secondary pl-6">{post.summary}</p>

        {post.body && (
          <div className="space-y-6">
            {post.body.split("\n\n").map((para, i) => (
              <p key={i} className="text-gray-700 leading-relaxed">{para}</p>
            ))}
          </div>
        )}

        <div className="mt-12 pt-8 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-4">National Lived Experience Commission — Official Announcement</p>
          <Button variant="outline" asChild className="rounded-none border-secondary text-secondary hover:bg-secondary hover:text-white">
            <Link href="/news">All Announcements</Link>
          </Button>
        </div>
      </div>
    </PublicLayout>
  );
}
