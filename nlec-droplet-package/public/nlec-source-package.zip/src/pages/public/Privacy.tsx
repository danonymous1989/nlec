import { PublicLayout } from "@/components/layout/PublicLayout";
import { Link } from "wouter";

export function Privacy() {
  return (
    <PublicLayout>
      <title>Privacy Policy | National Lived Experience Commission</title>
      <div className="bg-gray-50 border-b py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="text-4xl font-serif font-bold text-primary mb-4">Privacy Policy</h1>
          <p className="text-gray-500 text-sm">Last updated: 1 March 2024</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="prose prose-gray max-w-none">
          {sections.map(({ heading, content }) => (
            <div key={heading} className="mb-12 border-l-4 border-secondary/30 pl-6">
              <h2 className="text-2xl font-serif font-bold text-primary mb-4">{heading}</h2>
              <div className="space-y-4 text-gray-700 leading-relaxed">
                {content.map((para, i) => <p key={i}>{para}</p>)}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gray-50 border border-gray-200 p-8">
          <h3 className="text-lg font-serif font-bold text-primary mb-3">Privacy Enquiries</h3>
          <p className="text-gray-600 mb-4">If you have questions about this Privacy Policy or how the Commission handles your personal information, please contact us.</p>
          <Link href="/contact" className="text-secondary font-semibold underline hover:text-secondary/80">Contact the Commission</Link>
        </div>
      </div>
    </PublicLayout>
  );
}

const sections = [
  {
    heading: "1. Introduction",
    content: [
      "The National Lived Experience Commission (NLEC, 'the Commission', 'we', 'us') is an independent non-government organisation registered with the Australian Charities and Not-for-profits Commission (ACNC). We are committed to protecting the privacy of individuals who interact with our website, submit evidence, make enquiries, or engage with our work.",
      "This Privacy Policy explains how we collect, use, store, and disclose personal information in accordance with the Privacy Act 1988 (Cth) and the Australian Privacy Principles (APPs).",
      "By using our website or submitting information to us, you consent to the handling of your personal information in accordance with this policy.",
    ],
  },
  {
    heading: "2. What Information We Collect",
    content: [
      "We collect personal information that is reasonably necessary for the Commission's functions. The types of information we collect include:",
      "Contact information: name, email address, phone number, postal address, and organisational affiliation where provided.",
      "Evidence submissions: personal accounts, governance concerns, systems issues, policy feedback, and other information submitted through our evidence portal.",
      "Enquiry information: the content of enquiries submitted through our contact form, including information about the nature of the enquiry.",
      "Website usage data: de-identified technical information about how visitors interact with our website, including device type, browser, pages visited, and referral sources.",
      "We do not collect sensitive information (as defined under the Privacy Act) unless you choose to provide it in the course of an evidence submission, and only with your explicit consent.",
    ],
  },
  {
    heading: "3. How We Collect Information",
    content: [
      "We collect personal information through:",
      "The evidence submission portal on our website, where individuals voluntarily submit evidence for consideration by the Commission.",
      "The contact form on our website, where individuals submit enquiries or requests.",
      "Direct correspondence, including email, phone, and written communications.",
      "Engagement activities, including consultations, forums, and research participation.",
      "We will generally collect personal information directly from you. We may also collect information from publicly available sources where relevant to our governance intelligence functions.",
    ],
  },
  {
    heading: "4. How We Use Your Information",
    content: [
      "We use personal information for the purposes for which it was provided, and for related purposes that you would reasonably expect, including:",
      "Processing and analysing evidence submissions as part of the Commission's research, standards development, and systems intelligence functions.",
      "Responding to enquiries and requests.",
      "Consulting with individuals and organisations as part of policy and standards development processes.",
      "Maintaining records of engagement activities as required for accountability purposes.",
      "Sending updates, consultation invitations, and publications to individuals who have requested this information.",
      "We do not use personal information for direct marketing or share it with commercial third parties.",
    ],
  },
  {
    heading: "5. Evidence Submission Confidentiality",
    content: [
      "Evidence submitted through the Commission's portal is handled with particular care. Unless you explicitly consent to identification, evidence is de-identified before being used in Commission research, reports, or publications.",
      "You may submit evidence anonymously or confidentially. Confidential submissions will not be published or shared with third parties in an identified form.",
      "The Commission is not a complaints body and cannot act on behalf of individuals in relation to specific grievances. Evidence is used to inform the Commission's systemic governance intelligence work.",
      "Where evidence raises issues of immediate safety or serious legal concern, the Commission may refer the matter to appropriate authorities. We will advise you before doing so wherever possible.",
    ],
  },
  {
    heading: "6. Disclosure of Personal Information",
    content: [
      "We do not sell, rent, or trade personal information.",
      "We may disclose personal information to third parties in limited circumstances, including:",
      "Where you have provided consent to disclosure.",
      "Where disclosure is required by law or regulatory obligation.",
      "To contracted service providers who assist with our operations (such as website hosting), under strict confidentiality and data security requirements.",
      "To partner research institutions, where you have consented to information being shared for specific research purposes.",
      "We do not disclose personal information to overseas recipients except where required by law or with your explicit consent.",
    ],
  },
  {
    heading: "7. Data Security",
    content: [
      "The Commission takes reasonable steps to protect personal information from misuse, interference, loss, unauthorised access, modification, and disclosure.",
      "Our website and evidence portal are secured using industry-standard encryption. Access to personal information within the Commission is restricted to staff and contractors with a legitimate need.",
      "We retain personal information only as long as necessary for the purposes for which it was collected, or as required by law.",
    ],
  },
  {
    heading: "8. Your Rights",
    content: [
      "You have the right to request access to personal information the Commission holds about you, and to request corrections where the information is inaccurate, incomplete, or out of date.",
      "To make an access or correction request, please contact us using the contact details on our website. We will respond within 30 days.",
      "If you believe the Commission has not handled your personal information appropriately, you have the right to make a complaint. We will acknowledge and investigate your complaint promptly.",
      "If you are not satisfied with our response, you may make a complaint to the Office of the Australian Information Commissioner (OAIC) at www.oaic.gov.au.",
    ],
  },
  {
    heading: "9. Cookies and Website Analytics",
    content: [
      "Our website uses cookies and similar technologies to improve user experience and to understand how visitors use the site.",
      "We use de-identified analytics data to improve the design and content of our website. This data does not identify individual visitors.",
      "You can configure your browser to refuse cookies, but this may affect the functionality of some features of our website.",
    ],
  },
  {
    heading: "10. Changes to This Policy",
    content: [
      "The Commission may update this Privacy Policy from time to time to reflect changes in our practices or applicable law. The updated policy will be published on our website with the date of revision noted.",
      "Your continued use of our website or submission of information following any update constitutes acceptance of the revised policy.",
    ],
  },
];
