import { PublicLayout } from "@/components/layout/PublicLayout";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckSquare, Shield, Users, BarChart2, FileSearch, Layers, ArrowRight, ChevronRight } from "lucide-react";
import { useSEO } from "@/lib/useSEO";

const domains = [
  { code: "D1", name: "Governance Architecture", desc: "The structural integrity of governing bodies, committee arrangements, decision-making processes, and delegation frameworks." },
  { code: "D2", name: "Lived Experience Integration", desc: "The quality and authenticity of lived experience participation in governance, including structural role design, authority, and accountability." },
  { code: "D3", name: "Evidence Management", desc: "How evidence is collected, handled, analysed, and used in institutional decision-making, including compliance with NLEC-LEGS-006." },
  { code: "D4", name: "Accountability Systems", desc: "The effectiveness of internal, community, sector, and independent accountability mechanisms, aligned with NLEC-LEGS-005 and NLEC-LEGS-010." },
  { code: "D5", name: "Safeguarding Infrastructure", desc: "The quality, currency, and operational effectiveness of safeguarding policies, procedures, and oversight mechanisms." },
  { code: "D6", name: "Engagement Practice", desc: "The integrity of community and lived experience engagement practices, aligned with NLEC-LEGS-003 and NLEC-LEGS-008." },
  { code: "D7", name: "Psychological Safety", desc: "The structural and cultural conditions for psychological safety in all lived experience participation contexts, aligned with NLEC-LEGS-004." },
  { code: "D8", name: "Systems Intelligence", desc: "The organisation's capacity to collect, analyse, and act on lived experience intelligence at systemic level, aligned with NLEC-LEGS-007." },
];

const assessmentPathways = [
  {
    code: "NLEC-GA-01",
    name: "Governance Maturity Assessment",
    description: "A comprehensive assessment of organisational governance maturity across all eight governance domains. Suitable for organisations seeking a complete picture of governance performance and a structured improvement roadmap.",
    scope: "All 8 governance domains",
    output: "Maturity assessment report, domain ratings, improvement roadmap",
    duration: "8–12 weeks",
    from: "from $35,000",
  },
  {
    code: "NLEC-GA-02",
    name: "Standards Alignment Assessment",
    description: "A focused assessment of alignment with specific NLEC governance standards. Suitable for organisations targeting particular governance improvement priorities or seeking to demonstrate alignment with specific standards.",
    scope: "Selected standards (minimum 3)",
    output: "Standards alignment report, gap analysis, implementation guidance",
    duration: "4–8 weeks",
    from: "from $20,000",
  },
  {
    code: "NLEC-GA-03",
    name: "Workforce Integration Review",
    description: "A targeted review of lived experience workforce integration, examining role design, cultural conditions, supervision, remuneration, and capability development practices against NLEC-LEGS-002.",
    scope: "NLEC-LEGS-002 focused",
    output: "Workforce integration report, recommendations, implementation framework",
    duration: "4–6 weeks",
    from: "from $20,000",
  },
  {
    code: "NLEC-GA-04",
    name: "Engagement Integrity Assessment",
    description: "An assessment of engagement processes and their alignment with the NLEC Engagement Integrity Standard (NLEC-LEGS-003) and Community Participation Standard (NLEC-LEGS-008).",
    scope: "NLEC-LEGS-003 and NLEC-LEGS-008",
    output: "Engagement integrity report, standards alignment assessment, redesign guidance",
    duration: "4–6 weeks",
    from: "from $25,000",
  },
];

const maturityLevels = [
  { level: 1, name: "Emergent", desc: "Lived experience engagement exists in isolated, informal ways without structural embedding or accountability mechanisms.", colour: "bg-red-100 text-red-800 border-red-200" },
  { level: 2, name: "Developing", desc: "Formal lived experience roles exist but operate in an advisory capacity without decision-making authority or consistent support.", colour: "bg-orange-100 text-orange-800 border-orange-200" },
  { level: 3, name: "Established", desc: "Lived experience is structurally integrated with defined authority, but accountability mechanisms are underdeveloped.", colour: "bg-yellow-100 text-yellow-800 border-yellow-200" },
  { level: 4, name: "Advanced", desc: "Governance integration is substantive, accountable, and subject to independent review, with evidence of genuine governance influence.", colour: "bg-green-100 text-green-800 border-green-200" },
  { level: 5, name: "Leading", desc: "Lived experience governance is deeply embedded, culturally authentic, continuously improving, and serves as a sector reference model.", colour: "bg-teal-100 text-teal-800 border-teal-200" },
];

export function GovernanceAssessment() {
  useSEO({
    path: "/assessments",
    title: "Institutional Assessments",
    description: "The National Lived Experience Commission provides independent governance assessments across eight domains. Assessments produce maturity ratings, board-level recommendations, and structured improvement pathways.",
  });
  return (
    <PublicLayout>
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">
            GOVERNANCE ASSESSMENT PROGRAM
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Institutional Governance Assessment</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl mb-4">
            The NLEC Institutional Governance Assessment Program provides organisations with structured, independent assessments of governance maturity and standards alignment.
          </p>
          <p className="text-white/70 leading-relaxed max-w-3xl">
            Assessments are conducted by Commission-trained assessors using validated frameworks. All engagements are voluntary, independent, and conducted under conditions of confidentiality. Assessment findings are provided to the commissioning organisation and are not published without consent.
          </p>
        </div>
      </section>

      {/* Purpose */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-3">Assessment Program</h2>
            <h3 className="text-3xl font-serif font-bold text-primary">Purpose of the Assessment Program</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <p className="text-gray-700 leading-relaxed mb-4">
                The Institutional Governance Assessment Program enables organisations to understand their current governance performance against NLEC standards in a structured, evidence-based, and non-judgmental environment. The program is designed to support improvement, not to create compliance obligations.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                Assessments provide organisations with an independent, authoritative analysis of governance strengths and gaps, calibrated against the NLEC Governance Maturity Model and the Commission's Standards Library. Assessment reports provide a clear baseline for governance improvement planning and a framework for tracking progress over time.
              </p>
              <p className="text-gray-700 leading-relaxed">
                The Commission recognises that governance improvement is a longitudinal process. Organisations are encouraged to treat assessment as the first step in a structured improvement cycle, with repeat assessments to measure progress against initial findings.
              </p>
            </div>
            <div className="space-y-4">
              {[
                { icon: Shield, title: "Independent", desc: "Assessments are conducted independently of operational management and are not subject to interference by the assessed organisation." },
                { icon: FileSearch, title: "Evidence-Based", desc: "Assessment findings are grounded in documentary evidence, structured interviews, and validated assessment frameworks." },
                { icon: Users, title: "Participatory", desc: "Assessment processes include direct engagement with lived experience staff, governance participants, and community representatives." },
                { icon: BarChart2, title: "Standards-Referenced", desc: "Findings are calibrated against the NLEC Standards Library and Governance Maturity Model, providing a nationally consistent benchmark." },
              ].map(item => (
                <div key={item.title} className="flex gap-4 p-4 border border-gray-200">
                  <item.icon className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-primary text-sm mb-1">{item.title}</div>
                    <div className="text-xs text-gray-600 leading-relaxed">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Participation model */}
      <section className="py-16 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <h3 className="text-2xl font-serif font-bold text-primary text-center mb-10">Participation Model</h3>
          <div className="grid sm:grid-cols-4 gap-6">
            {[
              { step: "01", title: "Initial Enquiry", desc: "Organisations submit a service enquiry through the Commission's website or by direct contact with the Standards and Policy division." },
              { step: "02", title: "Scoping Discussion", desc: "A Commission representative discusses the organisation's context, objectives, and preferred assessment pathway to develop a tailored scope." },
              { step: "03", title: "Formal Proposal", desc: "The Commission provides a formal assessment proposal including methodology, timeline, team composition, confidentiality arrangements, and fee estimate." },
              { step: "04", title: "Assessment Engagement", desc: "Following agreement, the assessment commences in accordance with the agreed workplan, culminating in a formal assessment report." },
            ].map(s => (
              <div key={s.step} className="text-center">
                <div className="text-5xl font-mono font-bold text-secondary/25 mb-3">{s.step}</div>
                <h4 className="font-bold text-primary mb-2 text-sm">{s.title}</h4>
                <p className="text-xs text-gray-600 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Assessment pathways */}
      <section className="py-20 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-12">
            <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-3">Assessment Pathways</h2>
            <h3 className="text-3xl font-serif font-bold text-primary">Assessment Services</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {assessmentPathways.map(ap => (
              <div key={ap.code} className="border border-gray-200 p-8 hover:border-secondary hover:shadow-md transition-all">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-xs font-mono font-bold text-primary border border-primary/20 px-2 py-1">{ap.code}</span>
                  <span className="text-sm font-semibold text-secondary">{ap.from}</span>
                </div>
                <h4 className="text-lg font-serif font-bold text-primary mb-3">{ap.name}</h4>
                <p className="text-sm text-gray-600 leading-relaxed mb-5">{ap.description}</p>
                <div className="space-y-2 text-xs text-gray-600">
                  <div className="flex gap-2"><span className="font-semibold text-primary min-w-20">Scope:</span>{ap.scope}</div>
                  <div className="flex gap-2"><span className="font-semibold text-primary min-w-20">Output:</span>{ap.output}</div>
                  <div className="flex gap-2"><span className="font-semibold text-primary min-w-20">Duration:</span>{ap.duration}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Domains */}
      <section className="py-16 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-10">
            <h3 className="text-2xl font-serif font-bold text-primary">Eight Governance Domains</h3>
            <p className="text-gray-600 mt-3 text-sm max-w-2xl mx-auto">All Governance Maturity Assessments (NLEC-GA-01) evaluate performance across eight governance domains. Standards alignment assessments are calibrated to relevant domains.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {domains.map(d => (
              <div key={d.code} className="bg-white border border-gray-200 p-5 hover:border-secondary transition-colors">
                <div className="text-xs font-mono font-bold text-secondary mb-2">{d.code}</div>
                <h4 className="font-bold text-primary text-sm mb-2">{d.name}</h4>
                <p className="text-xs text-gray-600 leading-relaxed">{d.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Maturity model */}
      <section className="py-16 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-10">
            <h3 className="text-2xl font-serif font-bold text-primary">Governance Maturity Model</h3>
            <p className="text-gray-600 mt-3 text-sm max-w-2xl mx-auto">Assessment findings are calibrated against the NLEC five-level Governance Maturity Model, providing a nationally consistent benchmark for governance performance.</p>
          </div>
          <div className="space-y-3">
            {maturityLevels.map(l => (
              <div key={l.level} className={`flex items-start gap-4 p-5 border ${l.colour}`}>
                <div className="font-mono font-bold text-2xl shrink-0 opacity-60">L{l.level}</div>
                <div>
                  <div className="font-bold">{l.name}</div>
                  <div className="text-sm mt-1 opacity-80">{l.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Assessment methodology */}
      <section className="py-16 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <h3 className="text-2xl font-serif font-bold text-primary text-center mb-10">Assessment Methodology</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { title: "Document Review", desc: "Systematic review of governance documentation including constitutions, board papers, policy frameworks, accountability reports, and engagement records against NLEC standards requirements." },
              { title: "Stakeholder Interviews", desc: "Structured interviews with governing body members, executive leaders, lived experience staff and participants, and community representatives using validated interview protocols." },
              { title: "Observation", desc: "Where appropriate and with organisational consent, assessment may include observation of governance meetings, engagement processes, and operational activities." },
              { title: "Survey Instruments", desc: "Validated survey instruments assess governance culture, lived experience participant perspectives, and staff awareness of governance frameworks." },
              { title: "Benchmarking Analysis", desc: "Assessment findings are benchmarked against NLEC standards requirements, Governance Maturity Model levels, and de-identified findings from the Commission's broader assessment program." },
              { title: "Reporting and Recommendations", desc: "Findings are presented in a formal assessment report with domain ratings, maturity level assessments, and prioritised recommendations supported by evidence from the assessment process." },
            ].map(item => (
              <div key={item.title} className="bg-white border border-gray-200 p-6">
                <h4 className="font-bold text-primary mb-2 text-sm">{item.title}</h4>
                <p className="text-sm text-gray-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Confidentiality and ethics */}
      <section className="py-12 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <h3 className="text-xl font-serif font-bold text-primary mb-6">Confidentiality and Ethics</h3>
          <div className="prose max-w-none text-gray-700 text-sm leading-relaxed space-y-4">
            <p><strong className="text-primary">Confidentiality:</strong> Information shared with the Commission in the context of governance assessment engagements is treated as strictly confidential. Assessment reports are provided to the commissioning organisation only. The Commission does not publish assessment findings or identify assessed organisations in any public reporting without explicit written consent.</p>
            <p><strong className="text-primary">Independent Assessors:</strong> Assessors are trained and accredited by the Commission. All assessors are required to declare and manage conflicts of interest prior to engagement commencement. Assessors are independent of organisational management throughout the assessment process.</p>
            <p><strong className="text-primary">Participant Protections:</strong> All assessment participants — including lived experience staff, community representatives, and governance participants — are provided with information about their rights, the confidential handling of their contributions, and access to independent support. The Commission's assessment processes comply with NLEC-LEGS-004 (Psychological Safety Standard) and NLEC-LEGS-009 (Ethical Engagement Standard).</p>
            <p><strong className="text-primary">Data Management:</strong> Assessment data is stored, managed, and disposed of in accordance with the Commission's data governance framework and applicable privacy law. De-identified, aggregated assessment data contributes to the Commission's systems intelligence work, subject to disclosure in assessment agreements.</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <h3 className="text-2xl font-serif font-bold mb-4">Request a Governance Assessment</h3>
          <p className="text-white/80 mb-8 leading-relaxed">
            To discuss an assessment engagement for your organisation, submit a service enquiry through the Commission's services portal. A Standards and Policy Division representative will be in contact within 3 business days.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="rounded-none bg-accent hover:bg-accent/90 text-primary h-12 px-8 font-semibold">
              <Link href="/services">Request an Assessment <ArrowRight size={16} className="ml-2" /></Link>
            </Button>
            <Button asChild variant="outline" className="rounded-none border-white text-white hover:bg-white hover:text-primary h-12 px-8">
              <Link href="/standards">View Standards Library</Link>
            </Button>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
