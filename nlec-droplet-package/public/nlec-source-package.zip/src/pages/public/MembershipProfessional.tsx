import { useState } from "react";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { CheckSquare } from "lucide-react";
import { CheckoutModal } from "@/components/CheckoutModal";

const tiers = [
  {
    name: "Professional Member",
    price: "$180",
    priceDisplay: "$180 AUD / year",
    priceNote: "AUD per year",
    tierKey: "professional_member",
    highlight: false,
    benefits: [
      "Access to member briefings and research updates",
      "Participation in Commission consultations",
      "Eligibility for certification programs",
      "Access to selected standards resources",
      "Inclusion in the Commission's professional network",
    ],
  },
  {
    name: "Advanced Professional Member",
    price: "$360",
    priceDisplay: "$360 AUD / year",
    priceNote: "AUD per year",
    tierKey: "advanced_professional_member",
    highlight: true,
    badge: "Most Popular",
    benefits: [
      "All Professional Member benefits",
      "Full access to Commission research publications",
      "Member-only governance guidance notes",
      "Discounted certification programs",
      "Priority access to Commission events",
    ],
  },
  {
    name: "Fellow / Specialist Member",
    price: "$480",
    priceDisplay: "$480 AUD / year",
    priceNote: "AUD per year",
    tierKey: "fellow_specialist_member",
    highlight: false,
    benefits: [
      "All Advanced Member benefits",
      "Recognition within the Commission's professional community",
      "Participation in specialist working groups",
      "Early access to new standards and research reports",
    ],
  },
];

export function MembershipProfessional() {
  const [modal, setModal] = useState<typeof tiers[0] | null>(null);

  return (
    <PublicLayout>
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">
            PROFESSIONAL MEMBERSHIP
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Professional Membership</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl mb-4">
            Professional membership connects individuals to the Commission's research network and provides access to specialised resources designed to strengthen governance and engagement practice.
          </p>
          <p className="text-white/70 leading-relaxed max-w-3xl">
            Professional members include lived experience leaders, researchers, policy professionals, consultants, and practitioners working across government, health, social services, and community sectors.
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid md:grid-cols-3 gap-6">
            {tiers.map((tier) => (
              <div
                key={tier.name}
                className={`flex flex-col border p-8 transition-all ${
                  tier.highlight
                    ? "border-secondary shadow-md bg-secondary/5"
                    : "border-gray-200 hover:border-secondary hover:shadow-sm"
                }`}
              >
                {tier.badge && (
                  <div className="text-xs font-bold tracking-wider text-white bg-secondary px-3 py-1 mb-4 self-start">
                    {tier.badge}
                  </div>
                )}
                <h3 className="text-xl font-serif font-bold text-primary mb-2">{tier.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-mono font-bold text-secondary">{tier.price}</span>
                  <span className="text-gray-500 text-sm ml-2">{tier.priceNote}</span>
                </div>
                <ul className="space-y-3 mb-8 flex-grow">
                  {tier.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-2 text-sm text-gray-700">
                      <CheckSquare className="h-4 w-4 text-secondary mt-0.5 shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  onClick={() => setModal(tier)}
                  className={`w-full rounded-none ${
                    tier.highlight
                      ? "bg-secondary hover:bg-primary text-white"
                      : "bg-primary hover:bg-secondary text-white"
                  }`}
                >
                  Join Now — Pay with Card
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-gray-50 border-t text-center">
        <p className="text-gray-600 text-sm mb-2">All memberships are billed annually in Australian Dollars (AUD) and renewed automatically.</p>
        <p className="text-gray-500 text-sm">
          For institutional enquiries contact{" "}
          <a href="mailto:commissioner@nlec.au" className="text-secondary hover:underline">commissioner@nlec.au</a>
        </p>
      </section>

      {modal && (
        <CheckoutModal
          tierKey={modal.tierKey}
          tierName={modal.name}
          tierPrice={modal.priceDisplay}
          mode="subscription"
          onClose={() => setModal(null)}
        />
      )}
    </PublicLayout>
  );
}
