import { PublicLayout } from "@/components/layout/PublicLayout";
import { useSEO } from "@/lib/useSEO";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const NAV = "#0B1F3A";
const GOLD = "#C6A85A";
const BORDER = "#E5E5E5";
const MUTED = "#555";
const TEXT = "#1A1A1A";

const briefingSchema = z.object({
  organisation: z.string().min(2, "Organisation name is required"),
  name: z.string().min(2, "Full name is required"),
  email: z.string().email("A valid email address is required"),
  role: z.string().min(2, "Your role or title is required"),
  enquiryType: z.string().min(1, "Please select an enquiry type"),
  description: z.string().min(30, "Please provide at least a brief description of your enquiry (30+ characters)"),
  confidential: z.boolean().optional(),
});

type BriefingFormData = z.infer<typeof briefingSchema>;

const enquiryTypes = [
  "Governance Standards Overview",
  "Institutional Assessment Enquiry",
  "Systems Intelligence Briefing",
  "Policy and Advisory Briefing",
  "Research and Publications Overview",
  "Other",
];

const briefingExamples = [
  "Understanding how NLEC governance standards apply to your organisation's operating context",
  "Requesting intelligence on governance risk trends in a specific service domain",
  "Exploring the Commission's independent assessment program for your board or leadership team",
  "Briefing for a government department on NLEC standards and advisory outputs",
  "Policy briefing on lived experience governance frameworks for reform processes",
  "Pre-assessment consultation prior to commissioning a formal governance review",
];

export function RequestBriefing() {
  useSEO({
    path: "/request-briefing",
    title: "Request a Briefing",
    description: "Request a confidential institutional briefing from the National Lived Experience Commission. Briefings are available to government departments, institutional boards, policy units, and senior leadership teams.",
  });

  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);

  const form = useForm<BriefingFormData>({
    resolver: zodResolver(briefingSchema),
    defaultValues: {
      organisation: "",
      name: "",
      email: "",
      role: "",
      enquiryType: "",
      description: "",
      confidential: true,
    },
  });

  const onSubmit = async (data: BriefingFormData) => {
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: data.name,
          email: data.email,
          organisation: data.organisation,
          message: `BRIEFING REQUEST\n\nRole: ${data.role}\nEnquiry Type: ${data.enquiryType}\nConfidential: ${data.confidential ? "Yes" : "No"}\n\nDescription:\n${data.description}`,
          subject: `Briefing Request — ${data.enquiryType}`,
        }),
      });
      if (!res.ok) throw new Error("Submission failed");
      setSubmitted(true);
    } catch {
      toast({
        title: "Submission error",
        description: "There was a problem submitting your request. Please try again or email commissioner@nlec.au directly.",
        variant: "destructive",
      });
    }
  };

  const C = { maxWidth: "1100px", margin: "0 auto", padding: "0 32px" };

  if (submitted) {
    return (
      <PublicLayout>
        <section style={{ background: NAV, padding: "80px 0 64px", borderBottom: `4px solid ${GOLD}` }}>
          <div style={C}>
            <div style={{ fontSize: "10px", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "16px", fontFamily: "'Source Sans 3', sans-serif" }}>
              Request Submitted
            </div>
            <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(24px, 4vw, 36px)", fontWeight: 700, color: "#fff", letterSpacing: "0.04em", lineHeight: 1.2, marginBottom: "16px" }}>
              Briefing Request Received
            </h1>
            <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "16px", color: "rgba(255,255,255,0.75)", maxWidth: "560px", lineHeight: 1.7 }}>
              Thank you. The Commission's office will respond to your briefing request within 5 business days.
            </p>
          </div>
        </section>
        <section style={{ background: "#fff", padding: "56px 0" }}>
          <div style={C}>
            <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", color: MUTED, marginBottom: "32px", lineHeight: 1.7 }}>
              While you wait, you may wish to explore the Commission's standards library or recent publications.
            </p>
            <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" as const }}>
              <Link href="/standards" style={{ display: "inline-block", background: NAV, color: "#fff", padding: "11px 24px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 600, textDecoration: "none" }}>
                Explore Standards
              </Link>
              <Link href="/publications" style={{ display: "inline-block", border: `1px solid ${NAV}`, color: NAV, padding: "11px 24px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 600, textDecoration: "none" }}>
                Read Publications
              </Link>
            </div>
          </div>
        </section>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      {/* Header */}
      <section style={{ background: NAV, padding: "80px 0 64px", borderBottom: `4px solid ${GOLD}` }}>
        <div style={C}>
          <div style={{ fontSize: "10px", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "16px", fontFamily: "'Source Sans 3', sans-serif" }}>
            Institutional Enquiry
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(24px, 4vw, 38px)", fontWeight: 700, color: "#fff", letterSpacing: "0.04em", lineHeight: 1.2, marginBottom: "20px" }}>
            Request a Briefing
          </h1>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "17px", color: "rgba(255,255,255,0.8)", maxWidth: "620px", lineHeight: 1.7 }}>
            The Commission provides confidential briefings to government departments, institutional boards, peak bodies, and senior leadership teams on its governance standards, intelligence outputs, and assessment framework.
          </p>
        </div>
      </section>

      {/* Main content */}
      <section style={{ background: "#fff", padding: "64px 0" }}>
        <div style={C}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: "64px", alignItems: "start" }}>

            {/* Form */}
            <div>
              <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "20px", fontWeight: 600, color: NAV, letterSpacing: "0.04em", marginBottom: "32px" }}>
                Briefing Request Form
              </h2>

              <form onSubmit={form.handleSubmit(onSubmit)}>
                <div style={{ display: "grid", gap: "24px" }}>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                    {/* Organisation */}
                    <div>
                      <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" as const, color: NAV, marginBottom: "8px" }}>
                        Organisation *
                      </label>
                      <input
                        {...form.register("organisation")}
                        placeholder="Organisation name"
                        style={{ width: "100%", padding: "10px 12px", border: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: TEXT, outline: "none", boxSizing: "border-box" as const }}
                      />
                      {form.formState.errors.organisation && (
                        <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: "#C0392B", marginTop: "4px" }}>{form.formState.errors.organisation.message}</p>
                      )}
                    </div>

                    {/* Role */}
                    <div>
                      <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" as const, color: NAV, marginBottom: "8px" }}>
                        Role / Title *
                      </label>
                      <input
                        {...form.register("role")}
                        placeholder="e.g. CEO, Director of Policy"
                        style={{ width: "100%", padding: "10px 12px", border: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: TEXT, outline: "none", boxSizing: "border-box" as const }}
                      />
                      {form.formState.errors.role && (
                        <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: "#C0392B", marginTop: "4px" }}>{form.formState.errors.role.message}</p>
                      )}
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                    {/* Name */}
                    <div>
                      <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" as const, color: NAV, marginBottom: "8px" }}>
                        Full Name *
                      </label>
                      <input
                        {...form.register("name")}
                        placeholder="Your full name"
                        style={{ width: "100%", padding: "10px 12px", border: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: TEXT, outline: "none", boxSizing: "border-box" as const }}
                      />
                      {form.formState.errors.name && (
                        <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: "#C0392B", marginTop: "4px" }}>{form.formState.errors.name.message}</p>
                      )}
                    </div>

                    {/* Email */}
                    <div>
                      <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" as const, color: NAV, marginBottom: "8px" }}>
                        Email Address *
                      </label>
                      <input
                        {...form.register("email")}
                        type="email"
                        placeholder="commissioner@nlec.au"
                        style={{ width: "100%", padding: "10px 12px", border: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: TEXT, outline: "none", boxSizing: "border-box" as const }}
                      />
                      {form.formState.errors.email && (
                        <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: "#C0392B", marginTop: "4px" }}>{form.formState.errors.email.message}</p>
                      )}
                    </div>
                  </div>

                  {/* Enquiry type */}
                  <div>
                    <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" as const, color: NAV, marginBottom: "8px" }}>
                      Type of Enquiry *
                    </label>
                    <select
                      {...form.register("enquiryType")}
                      style={{ width: "100%", padding: "10px 12px", border: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: TEXT, outline: "none", background: "#fff", boxSizing: "border-box" as const }}
                    >
                      <option value="">Select enquiry type…</option>
                      {enquiryTypes.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                    {form.formState.errors.enquiryType && (
                      <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: "#C0392B", marginTop: "4px" }}>{form.formState.errors.enquiryType.message}</p>
                    )}
                  </div>

                  {/* Description */}
                  <div>
                    <label style={{ display: "block", fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" as const, color: NAV, marginBottom: "8px" }}>
                      Brief Description *
                    </label>
                    <textarea
                      {...form.register("description")}
                      rows={5}
                      placeholder="Please describe the purpose of your briefing request, your organisation's context, and any specific areas of interest."
                      style={{ width: "100%", padding: "10px 12px", border: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: TEXT, outline: "none", resize: "vertical" as const, boxSizing: "border-box" as const }}
                    />
                    {form.formState.errors.description && (
                      <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: "#C0392B", marginTop: "4px" }}>{form.formState.errors.description.message}</p>
                    )}
                  </div>

                  {/* Confidentiality */}
                  <div style={{ display: "flex", gap: "10px", alignItems: "flex-start", padding: "16px", background: "#F8F8F8", border: `1px solid ${BORDER}` }}>
                    <input
                      type="checkbox"
                      {...form.register("confidential")}
                      defaultChecked
                      id="confidential"
                      style={{ marginTop: "2px", accentColor: NAV }}
                    />
                    <label htmlFor="confidential" style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: MUTED, lineHeight: 1.6 }}>
                      I request that this enquiry be treated as confidential. The Commission will not disclose the fact of this enquiry or its content without consent.
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={form.formState.isSubmitting}
                    style={{
                      background: NAV,
                      color: "#fff",
                      padding: "14px 32px",
                      border: "none",
                      fontFamily: "'Source Sans 3', sans-serif",
                      fontSize: "15px",
                      fontWeight: 600,
                      cursor: "pointer",
                      letterSpacing: "0.02em",
                      opacity: form.formState.isSubmitting ? 0.7 : 1,
                    }}
                  >
                    {form.formState.isSubmitting ? "Submitting…" : "Submit Briefing Request"}
                  </button>
                </div>
              </form>
            </div>

            {/* Sidebar */}
            <div>
              {/* Intended users */}
              <div style={{ borderTop: `3px solid ${NAV}`, paddingTop: "24px", marginBottom: "32px" }}>
                <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "12px" }}>
                  Intended Requesters
                </p>
                <div style={{ borderTop: `1px solid ${BORDER}` }}>
                  {[
                    "Government departments and policy units",
                    "Institutional boards and governance committees",
                    "Peak bodies and sector organisations",
                    "Regulatory bodies and commissioning authorities",
                    "Senior organisational leadership",
                    "Parliamentary offices and advisers",
                  ].map(user => (
                    <div key={user} style={{ padding: "10px 0", borderBottom: `1px solid ${BORDER}`, fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: TEXT, display: "flex", gap: "10px" }}>
                      <span style={{ color: GOLD, flexShrink: 0 }}>·</span>
                      {user}
                    </div>
                  ))}
                </div>
              </div>

              {/* Example topics */}
              <div style={{ borderTop: `1px solid ${BORDER}`, paddingTop: "24px", marginBottom: "32px" }}>
                <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "12px" }}>
                  Example Briefing Scope
                </p>
                <div style={{ display: "grid", gap: "10px" }}>
                  {briefingExamples.map(ex => (
                    <div key={ex} style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: MUTED, lineHeight: 1.6, paddingLeft: "12px", borderLeft: `2px solid ${BORDER}` }}>
                      {ex}
                    </div>
                  ))}
                </div>
              </div>

              {/* Privacy note */}
              <div style={{ background: "#F0F2F5", padding: "20px", borderLeft: `3px solid ${GOLD}` }}>
                <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase" as const, color: NAV, marginBottom: "8px" }}>
                  Privacy &amp; Confidentiality
                </p>
                <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "12px", color: MUTED, lineHeight: 1.65 }}>
                  Information submitted through this form is handled in accordance with the Commission's <Link href="/privacy" style={{ color: NAV, fontWeight: 600 }}>Privacy Policy</Link> and the Australian Privacy Principles. Confidential briefing requests are not disclosed to third parties without consent.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA strip */}
      <section style={{ background: "#F8F8F8", borderTop: `1px solid ${BORDER}`, padding: "40px 0" }}>
        <div style={C}>
          <div style={{ display: "flex", gap: "32px", flexWrap: "wrap" as const, alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <p style={{ fontFamily: "'Cinzel', serif", fontSize: "15px", fontWeight: 600, color: NAV, marginBottom: "4px" }}>
                Not ready for a briefing?
              </p>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: MUTED }}>
                Explore our standards library or send a general enquiry.
              </p>
            </div>
            <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" as const }}>
              <Link href="/standards" style={{ display: "inline-block", background: NAV, color: "#fff", padding: "10px 22px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 600, textDecoration: "none" }}>
                Explore Standards
              </Link>
              <Link href="/contact" style={{ display: "inline-block", border: `1px solid ${NAV}`, color: NAV, padding: "10px 22px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 600, textDecoration: "none" }}>
                Contact the Commission
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
