import { PublicLayout } from "@/components/layout/PublicLayout";
import { CTASection, PageHeader, PublicationCard, SectionHeading } from "@/components/site";
import { publicationCategories, publicationReleases } from "@/lib/site";
import { useSEO } from "@/lib/useSEO";

export function Publications() {
  useSEO({
    path: "/publications",
    title: "Publications",
    description: "Reports, submissions, policy briefs, evidence papers, media statements and discussion papers from NLEC.",
  });

  return (
    <PublicLayout>
      <PageHeader
        eyebrow="Publications"
        title="A public repository for NLEC's reports, submissions and evidence papers"
        description="The publication library now includes the Commission's first released PDFs, with direct access to the executive summary, intelligence report, standards framework and evidence collection program."
      />

      <section className="section-block">
        <div className="site-container">
          <div className="muted-panel grid gap-4 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <p className="card-kicker">Current release set</p>
              <p className="text-balance font-serif text-2xl tracking-[0.03em] text-[color:var(--nav)]">
                Four public NLEC documents are now available for review and download.
              </p>
              <p className="mt-4 max-w-3xl text-base leading-8 text-[color:var(--muted)]">
                Each publication opens as a PDF in a new tab so visitors can read the document directly from the website without leaving the repository.
              </p>
            </div>
            <a className="inline-flex items-center justify-center rounded-full border border-[color:var(--line)] px-5 py-3 text-sm font-semibold text-[color:var(--nav)] transition-colors hover:bg-[color:var(--surface)]" href="/publications/national-lived-experience-intelligence-report-2026.pdf" target="_blank" rel="noreferrer">
              View flagship report
            </a>
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container">
          <SectionHeading
            eyebrow="Publication categories"
            title="The types of documents NLEC will publish"
          />
          <div className="flex flex-wrap gap-3">
            {publicationCategories.map((category) => (
              <span key={category} className="pill">
                {category}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="section-block">
        <div className="site-container">
          <SectionHeading
            eyebrow="Publication library"
            title="The first release wave of NLEC publications"
          />
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-2">
            {publicationReleases.map((item) => (
              <PublicationCard key={item.title} category={item.category} title={item.title} summary={item.summary} href={item.href} />
            ))}
          </div>
        </div>
      </section>

      <CTASection
        title="Need a publication or submission pathway?"
        description="NLEC can help shape the scope, language and format of a document so it is credible, public-facing and useful."
        primary={{ label: "Discuss a partnership", href: "/contact" }}
        secondary={{ label: "Explore our work", href: "/our-work" }}
      />
    </PublicLayout>
  );
}
