import { Link } from "wouter";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { ChevronRight } from "lucide-react";

const foundingSeats = [
  {
    seat: "Governance & Board Practice Advisor",
    focus: "Independent review of governance standards and institutional board practice across assessed organisations.",
  },
  {
    seat: "Lived Experience Systems Advisor",
    focus: "Sector representation and quality assurance for lived experience integration methodology and evidence frameworks.",
  },
  {
    seat: "Public Policy Advisor",
    focus: "Government interface, policy environment analysis, and alignment of Commission outputs with policy development cycles.",
  },
  {
    seat: "Clinical Systems Advisor",
    focus: "Mental health and disability systems intelligence, clinical governance standards, and safeguarding frameworks.",
  },
  {
    seat: "Ethics & Research Integrity Advisor",
    focus: "Research methodology oversight, ethical conduct review, and integrity assurance for published intelligence outputs.",
  },
];

const selectionCriteria = [
  { title: "Lived Experience", desc: "A majority of members must have direct lived experience of one or more of the service systems within the Commission's mandate." },
  { title: "Sector Diversity", desc: "Membership must reflect diversity of experience, background, geography, and sector, including First Nations and CALD representation." },
  { title: "Expertise", desc: "Collectively, the Council must provide expertise across governance, research methodology, public administration, ethics, and systems intelligence." },
  { title: "Independence", desc: "Members must be free from conflicts of interest that would prevent independent advice. All potential conflicts must be declared and managed." },
];

export function AdvisoryCouncil() {
  return (
    <PublicLayout>

      {/* Hero */}
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">
            ADVISORY COUNCIL — FOUNDING PHASE
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Advisory Council</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl mb-4">
            The NLEC Advisory Council provides independent expert review of the Commission's governance standards, research outputs, and systems intelligence publications. The Council is central to the Commission's quality assurance and accountability framework.
          </p>
          <p className="text-white/70 leading-relaxed max-w-3xl">
            The Commission is currently in its establishment phase. Founding Advisory Council appointments are being made progressively, with members announced as appointments are confirmed.
          </p>
        </div>
      </section>

      {/* Formation notice */}
      <section className="py-10 bg-amber-50 border-b border-amber-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="flex items-start gap-4">
            <div className="w-5 h-5 rounded-full bg-amber-500 shrink-0 mt-0.5 flex items-center justify-center">
              <span className="text-white text-xs font-bold">i</span>
            </div>
            <div>
              <h3 className="font-bold text-amber-900 mb-1">Council Formation in Progress</h3>
              <p className="text-amber-800 text-sm leading-relaxed">
                The National Lived Experience Commission was established in August 2025. The Advisory Council is being constituted during the Commission's establishment phase (2025–2027). Founding appointments will be announced progressively as they are confirmed. The governance framework, selection principles, and council remit described on this page are operational.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Purpose */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-14">
            <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-3">Council Remit</h2>
            <h3 className="text-3xl font-serif font-bold text-primary">Purpose and Role</h3>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="border border-gray-200 p-8">
              <h4 className="font-serif font-bold text-primary text-xl mb-4">Purpose</h4>
              <p className="text-gray-700 leading-relaxed text-sm mb-4">
                The Advisory Council ensures that the Commission's work is grounded in expertise, lived experience, and independence. It provides structured external input into the Commission's research, standards development, and governance assessment functions — supporting the quality and rigour of Commission outputs.
              </p>
              <p className="text-gray-700 leading-relaxed text-sm">
                The Council functions as an accountability mechanism, providing independent scrutiny of the Commission's research and standards work. Its formal review role in standards development ensures that NLEC governance standards are subjected to rigorous expert assessment before publication.
              </p>
            </div>
            <div className="border border-gray-200 p-8">
              <h4 className="font-serif font-bold text-primary text-xl mb-4">Independent Review Functions</h4>
              <ul className="space-y-3 text-sm text-gray-700">
                {[
                  "Reviews draft governance standards prior to public consultation",
                  "Recommends adoption of standards to the governing body",
                  "Advises on research priorities and methodological approaches",
                  "Reviews significant research outputs prior to publication",
                  "Provides expertise on lived experience governance and sector developments",
                  "Advises the governing body on referred matters",
                  "Acts as an independent voice in the Commission's accountability framework",
                ].map(item => (
                  <li key={item} className="flex items-start gap-2">
                    <ChevronRight className="h-4 w-4 text-secondary shrink-0 mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Terms */}
          <div className="bg-gray-50 border border-gray-200 p-8">
            <h4 className="font-serif font-bold text-primary text-xl mb-4">Terms of Appointment</h4>
            <div className="grid md:grid-cols-2 gap-6 text-sm text-gray-700">
              <div>
                <p className="font-semibold text-primary mb-2">Tenure</p>
                <p className="leading-relaxed">Founding members serve initial terms of two years from the date of appointment. Terms are renewable, with staggered renewal to ensure continuity of expertise across membership cycles.</p>
              </div>
              <div>
                <p className="font-semibold text-primary mb-2">Meetings</p>
                <p className="leading-relaxed">The Advisory Council meets a minimum of four times per year once constituted. Written consultations may also be convened by the Chair or Commissioner as required by the Commission's work program.</p>
              </div>
              <div>
                <p className="font-semibold text-primary mb-2">Remuneration</p>
                <p className="leading-relaxed">All Advisory Council members receive remuneration for their participation, reflecting the Commission's commitment to equitable recognition of lived experience expertise and professional contribution.</p>
              </div>
              <div>
                <p className="font-semibold text-primary mb-2">Governance Reporting</p>
                <p className="leading-relaxed">The Advisory Council Chair reports on Council activities in the Commission's governance disclosures. Individual member participation records are maintained as part of the Commission's transparency obligations.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Founding seats */}
      <section className="py-20 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-14">
            <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-3">Founding Council</h2>
            <h3 className="text-3xl font-serif font-bold text-primary">Advisory Seats</h3>
            <p className="text-gray-600 mt-4 max-w-2xl mx-auto text-sm leading-relaxed">
              The founding Advisory Council comprises five advisory seats, each focused on a distinct area of expertise critical to the Commission's work. Initial appointments will be announced progressively during the establishment phase.
            </p>
          </div>

          <div className="space-y-3">
            {foundingSeats.map((seat, i) => (
              <div key={seat.seat} className="bg-white border border-gray-200 px-7 py-6 flex gap-6 items-start">
                <div className="shrink-0 w-8 h-8 bg-primary/5 border border-primary/10 flex items-center justify-center text-xs font-bold text-secondary font-mono">
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div className="flex-1">
                  <p className="font-bold text-primary text-sm mb-1">{seat.seat}</p>
                  <p className="text-xs text-gray-500 leading-relaxed">{seat.focus}</p>
                </div>
                <span className="shrink-0 text-xs text-gray-400 italic mt-0.5">Appointment in progress</span>
              </div>
            ))}
          </div>

          <div className="mt-8 p-6 bg-primary/5 border border-primary/10 text-sm text-gray-700">
            <strong className="text-primary">Nomination and Selection:</strong> Advisory Council members are identified through direct approach, sector referral, and expression of interest. All appointments are approved by the governing body. The Commission is actively seeking nominations from communities with direct lived experience of disability, mental health, housing, and child and family service systems.
          </div>
        </div>
      </section>

      {/* Selection principles */}
      <section className="py-16 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <h3 className="text-2xl font-serif font-bold text-primary text-center mb-10">Selection Principles</h3>
          <div className="grid md:grid-cols-2 gap-5">
            {selectionCriteria.map(c => (
              <div key={c.title} className="bg-gray-50 border border-gray-200 p-6">
                <h4 className="font-bold text-primary mb-2">{c.title}</h4>
                <p className="text-sm text-gray-600 leading-relaxed">{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-12 bg-primary text-white text-center">
        <div className="container mx-auto px-4 max-w-2xl">
          <h3 className="text-xl font-serif font-bold mb-4">Governance Documents</h3>
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            {[
              { label: "Commission Charter", href: "/about" },
              { label: "Governance Structure", href: "/governance" },
              { label: "Standards Library", href: "/standards" },
              { label: "Research Programs", href: "/research" },
            ].map(doc => (
              <Link key={doc.label} href={doc.href} className="text-accent hover:text-white flex items-center gap-1">
                <ChevronRight size={14} />{doc.label}
              </Link>
            ))}
          </div>
        </div>
      </section>

    </PublicLayout>
  );
}
