import { useState } from "react";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { useSEO } from "@/lib/useSEO";
import { Button } from "@/components/ui/button";
import { CheckSquare, Award, ArrowRight } from "lucide-react";
import { CheckoutModal } from "@/components/CheckoutModal";

const certifications = [
  {
    code: "NLEC-CERT-001",
    name: "Certified Lived Experience Governance Practitioner",
    price: "$2,500",
    priceNote: "AUD — one-time enrolment",
    priceId: "cert_governance_practitioner",
    duration: "Approximately 12 weeks",
    level: "Practitioner",
    description:
      "This certification supports professionals responsible for designing and implementing lived experience governance frameworks within organisations. It provides structured grounding in the Commission's governance standards and assessment methodology.",
    areas: [
      "Governance frameworks and accountability structures",
      "Ethical engagement practice",
      "Safeguarding and psychological safety",
      "Institutional accountability",
    ],
    suitable: ["Governance advisors", "Policy professionals", "NGO board members", "Health system planners"],
  },
  {
    code: "NLEC-CERT-002",
    name: "Certified Systems Intelligence Analyst",
    price: "$3,500",
    priceNote: "AUD — one-time enrolment",
    priceId: "cert_systems_intelligence",
    duration: "Approximately 16 weeks",
    level: "Analyst",
    description:
      "This certification focuses on the analysis of lived experience evidence and the interpretation of systemic patterns within institutions. Graduates are equipped to produce and interpret systems intelligence in governance contexts.",
    areas: [
      "Systems intelligence methodologies",
      "Governance risk indicators",
      "Evidence analysis and synthesis",
      "Reporting frameworks",
    ],
    suitable: ["Researchers and analysts", "Policy officers", "Evaluation specialists", "Data professionals in public service"],
  },
  {
    code: "NLEC-CERT-003",
    name: "Certified Institutional Engagement Specialist",
    price: "$4,800",
    priceNote: "AUD — one-time enrolment",
    priceId: "cert_engagement_specialist",
    duration: "Approximately 20 weeks",
    level: "Specialist",
    description:
      "This program prepares professionals responsible for designing and managing lived experience engagement programs within institutions. It integrates the Commission's engagement integrity standards and organisational change frameworks.",
    areas: [
      "Engagement design and facilitation",
      "Institutional maturity frameworks",
      "Governance integration",
      "Organisational change and implementation",
    ],
    suitable: ["Engagement managers", "Community development professionals", "Lived experience leads", "Institutional reform advisors"],
  },
];

export function Certifications() {
  useSEO({ path: "/certifications", title: "Certification Programs", description: "NLEC certification programs for lived experience governance, engagement practice, and workforce integration. Professionally recognised credentials." });
  const [modal, setModal] = useState<typeof certifications[0] | null>(null);

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">
            CERTIFICATION PROGRAMS
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Certification Programs</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl mb-4">
            The Commission offers professional certification programs designed to strengthen governance capability and institutional engagement with lived experience expertise.
          </p>
          <p className="text-white/70 leading-relaxed max-w-3xl">
            These programs provide structured learning pathways supported by the Commission's research, standards, and governance frameworks.
          </p>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl space-y-10">
          {certifications.map((cert, i) => (
            <div key={cert.code} className="border border-gray-200 hover:border-secondary transition-all">
              <div className="p-8 md:p-10">
                <div className="flex flex-col md:flex-row md:items-start gap-6">
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                      <span className="text-xs font-mono font-bold text-primary border border-primary/30 px-2 py-1">{cert.code}</span>
                      <span className="text-xs font-semibold text-secondary border border-secondary/30 px-2 py-1">{cert.level}</span>
                      <span className="text-xs text-gray-500 border border-gray-200 px-2 py-1">{cert.duration}</span>
                    </div>
                    <h3 className="text-2xl font-serif font-bold text-primary mb-3">{cert.name}</h3>
                    <p className="text-gray-600 leading-relaxed mb-6">{cert.description}</p>

                    <div className="grid sm:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-bold text-primary uppercase tracking-wider mb-3">Program Areas</h4>
                        <ul className="space-y-2">
                          {cert.areas.map(area => (
                            <li key={area} className="flex items-start gap-2 text-sm text-gray-700">
                              <CheckSquare className="h-4 w-4 text-secondary mt-0.5 shrink-0" />
                              {area}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-primary uppercase tracking-wider mb-3">Suitable For</h4>
                        <ul className="space-y-2">
                          {cert.suitable.map(s => (
                            <li key={s} className="flex items-start gap-2 text-sm text-gray-700">
                              <ArrowRight className="h-4 w-4 text-secondary mt-0.5 shrink-0" />
                              {s}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="md:w-64 md:ml-6 border border-gray-100 p-6 bg-gray-50 flex flex-col items-center text-center shrink-0">
                    <Award className="h-8 w-8 text-secondary mb-3" />
                    <div className="text-3xl font-mono font-bold text-secondary mb-1">{cert.price}</div>
                    <div className="text-xs text-gray-500 mb-6">{cert.priceNote}</div>
                    <Button
                      onClick={() => setModal(cert)}
                      className="w-full rounded-none bg-secondary hover:bg-primary text-white"
                    >
                      Enrol Now — Pay with Card
                    </Button>
                    <p className="text-xs text-gray-400 mt-3">Secure checkout via Stripe — AUD</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Program notes */}
      <section className="py-12 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="grid md:grid-cols-3 gap-6 text-center">
            {[
              { title: "Issued by NLEC", desc: "All certificates are issued by the National Lived Experience Commission." },
              { title: "Nationally Recognised", desc: "Programs align with the Commission's governance standards framework." },
              { title: "Ongoing Support", desc: "Enrollees access Commission resources throughout their program." },
            ].map(item => (
              <div key={item.title} className="bg-white p-6 border border-gray-200">
                <h4 className="font-bold text-primary mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
          <p className="text-center text-sm text-gray-500 mt-8">
            For group enrolments or scholarship enquiries, contact{" "}
            <a href="mailto:commissioner@nlec.au" className="text-secondary hover:underline">commissioner@nlec.au</a>
          </p>
        </div>
      </section>

      {modal && (
        <CheckoutModal
          tierKey={modal.priceId}
          tierName={modal.name}
          tierPrice={`${modal.price} ${modal.priceNote}`}
          mode="payment"
          onClose={() => setModal(null)}
        />
      )}
    </PublicLayout>
  );
}
