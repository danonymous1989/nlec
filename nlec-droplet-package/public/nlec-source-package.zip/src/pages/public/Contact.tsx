import { useState } from "react";
import type { FormEvent } from "react";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { ButtonLink, ContactBlock, PageHeader, SectionHeading } from "@/components/site";
import { organisation } from "@/lib/site";
import { useSEO } from "@/lib/useSEO";

export function Contact() {
  useSEO({
    path: "/contact",
    title: "Contact",
    description: "Contact NLEC for partnership enquiries, media requests or general enquiries.",
  });

  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    // TODO: connect this form to backend handling if/when a submission service is added to the site.
    setSubmitted(true);
    event.currentTarget.reset();
  }

  return (
    <PublicLayout>
      <PageHeader
        eyebrow="Contact"
        title="Contact the Commission"
        description="Use this page for partnership enquiries, media requests and general contact with NLEC."
      />

      <section className="section-block">
        <div className="site-container grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="space-y-6">
            <ContactBlock />
            <div className="site-card">
              <p className="card-kicker">Enquiry types</p>
              <div className="flex flex-wrap gap-3">
                <span className="pill">Partnership</span>
                <span className="pill">Media</span>
                <span className="pill">Research</span>
                <span className="pill">General</span>
              </div>
            </div>
          </div>

          <div className="site-card">
            <SectionHeading
              eyebrow="Enquiry form"
              title="Send a message"
              description="This is a static first-version form. It is ready for backend integration when required."
            />

            {submitted ? (
              <div className="rounded-2xl border border-[color:var(--line)] bg-[color:var(--surface)] px-5 py-4 text-sm leading-7 text-[color:var(--nav)]">
                Thank you. Your enquiry has been captured locally for this first release and can now be connected to a backend when needed.
              </div>
            ) : null}

            <form className="grid gap-5" onSubmit={handleSubmit}>
              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label className="field-label" htmlFor="name">Name</label>
                  <input id="name" name="name" className="field-input" required />
                </div>
                <div>
                  <label className="field-label" htmlFor="email">Email</label>
                  <input id="email" name="email" type="email" className="field-input" required />
                </div>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label className="field-label" htmlFor="organisation">Organisation</label>
                  <input id="organisation" name="organisation" className="field-input" />
                </div>
                <div>
                  <label className="field-label" htmlFor="subject">Subject</label>
                  <input id="subject" name="subject" className="field-input" required />
                </div>
              </div>

              <div>
                <label className="field-label" htmlFor="type">Enquiry type</label>
                <select id="type" name="type" className="field-input">
                  <option>Partnership</option>
                  <option>Media</option>
                  <option>Research</option>
                  <option>General</option>
                </select>
              </div>

              <div>
                <label className="field-label" htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  className="field-input field-textarea"
                  minLength={10}
                  required
                />
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-[color:var(--nav)] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#132d53] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--accent)] focus-visible:ring-offset-2"
                >
                  Send enquiry
                </button>
                <ButtonLink href={`mailto:${organisation.email}?subject=Partnership%20enquiry`} tone="ghost">
                  Email directly
                </ButtonLink>
              </div>
            </form>
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container grid gap-6 lg:grid-cols-2">
          <div className="site-card">
            <p className="card-kicker">Partnership enquiry</p>
            <h3 className="card-title">Discuss a partnership</h3>
            <p className="card-copy">
              We can help scope the method, audience and outputs for advisory, research, education or consultation work.
            </p>
          </div>
          <div className="site-card">
            <p className="card-kicker">Media enquiry</p>
            <h3 className="card-title">Contact the Commission for comment or background</h3>
            <p className="card-copy">
              Media requests should be directed to {organisation.email} and clearly marked in the subject line.
            </p>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
