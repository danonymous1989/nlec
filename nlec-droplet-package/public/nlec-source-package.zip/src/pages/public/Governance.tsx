import { Link } from "wouter";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { useSEO } from "@/lib/useSEO";
import { ChevronRight, Shield, Users, BookOpen, FileSearch, Mic2, ClipboardList } from "lucide-react";

const roles = [
  {
    id: "governing-body",
    icon: Shield,
    title: "Governing Body",
    subtitle: "Board of the National Lived Experience Commission",
    responsibilities: [
      "Sets the strategic direction of the Commission in alignment with the Commission Charter",
      "Oversees the financial performance, risk management, and governance of the Commission",
      "Appoints and reviews the performance of the Executive Director",
      "Approves significant research outputs, governance standards, and policy positions",
      "Maintains the Commission's independence from government and sector interests",
      "Publishes an annual governance accountability report in accordance with NLEC-LEGS-010",
      "Reviews and approves the Commission Charter on a three-year cycle",
      "Manages conflicts of interest among governing body members",
    ],
    note: "The governing body comprises a minimum of five and maximum of nine members with expertise across lived experience governance, law, public administration, research, ethics, and finance. A majority of members must have direct lived experience of the systems within the Commission's mandate.",
  },
  {
    id: "responsible-persons",
    icon: Shield,
    title: "Responsible Persons / Trustees",
    subtitle: "Accountable Persons under the ACNC Framework",
    responsibilities: [
      "Exercise the duties of responsible persons as defined under the Australian Charities and Not-for-profits Commission Act 2012",
      "Act with reasonable care and diligence in governing the Commission",
      "Act honestly and in the best interests of the Commission and the public",
      "Disclose conflicts of interest to the governing body",
      "Ensure the Commission's financial affairs are managed responsibly and in accordance with its charitable purposes",
      "Report serious incidents or governance concerns to the ACNC as required",
      "Maintain the Commission's commitment to its charitable purposes under the Charter",
    ],
    note: "Responsible persons are the governing body members who bear personal accountability under the ACNC Act. All governing body members are responsible persons of the Commission.",
  },
  {
    id: "executive-director",
    icon: Users,
    title: "Executive Director",
    subtitle: "Chief Executive Officer of the Commission",
    responsibilities: [
      "Leads the operational management of the Commission in accordance with governing body direction",
      "Implements the Commission's strategic plan and reports on progress to the governing body",
      "Manages the Commission's staff, contractor, and advisory relationships",
      "Represents the Commission in external relationships with government, sector bodies, and stakeholders",
      "Oversees the Commission's financial management, including budget preparation and financial reporting",
      "Ensures the Commission's operations comply with the ACNC Act, the Commission Charter, and applicable law",
      "Implements governing body decisions and reports material matters to the governing body in a timely manner",
      "Maintains a public register of conflicts of interest for Commission staff and Advisory Council members",
    ],
    note: "The Executive Director is appointed by and accountable to the governing body. The Executive Director participates in governing body meetings in a non-voting capacity.",
  },
  {
    id: "research-director",
    icon: BookOpen,
    title: "Research Director",
    subtitle: "Head of Research and Systems Intelligence",
    responsibilities: [
      "Leads the Commission's research programs: National Systems Intelligence Program, Lived Experience Governance Program, and Institutional Reform and Accountability Program",
      "Oversees design, conduct, quality assurance, and publication of all Commission research outputs",
      "Manages the Commission's research partnerships with universities and international research bodies",
      "Ensures research methodology meets the Commission's evidence and ethics standards",
      "Develops and maintains the Commission's research governance framework",
      "Leads the peer review process for significant research publications",
      "Contributes to standards development by providing the evidence base for governance standards",
      "Oversees the Commission's evidence collection portal and evidence governance protocols",
    ],
    note: "The Research Director is a senior executive role with direct accountability to the Executive Director and functional accountability to the governing body on research matters.",
  },
  {
    id: "standards-director",
    icon: ClipboardList,
    title: "Standards and Policy Director",
    subtitle: "Head of Governance Standards and Policy",
    responsibilities: [
      "Leads the development, review, and maintenance of the NLEC Standards Library",
      "Manages public consultation processes for new and revised governance standards",
      "Oversees the Commission's governance assessment program and assessment services",
      "Develops and maintains implementation guidance resources for NLEC standards",
      "Coordinates the Commission's policy analysis and policy engagement functions",
      "Manages relationships with government departments, regulatory bodies, and sector peak organisations",
      "Oversees the Commission's professional certification and accreditation programs",
      "Contributes to the Commission's institutional engagement and advisory services",
    ],
    note: "The Standards and Policy Director works closely with the Research Director to ensure governance standards are grounded in current evidence, and with the Advisory Council to ensure standards reflect lived experience expertise.",
  },
  {
    id: "advisory-council",
    icon: Mic2,
    title: "Advisory Council",
    subtitle: "Independent Expert Advisory Body",
    responsibilities: [
      "Provides independent expert advice on the Commission's research, standards development, and governance assessment work",
      "Reviews draft governance standards prior to public consultation and recommends adoption to the governing body",
      "Advises on research priorities, methodological approaches, and evidence interpretation",
      "Reviews significant research outputs prior to publication",
      "Provides expertise on lived experience governance, sector developments, and emerging policy issues",
      "Participates in specialist working groups addressing specific standards or research questions",
      "Advises the governing body on matters referred by the governing body or Executive Director",
      "Acts as an independent voice in the Commission's accountability framework",
    ],
    note: "The Advisory Council operates in an advisory capacity and does not exercise governance authority. Full details of membership, composition, and working groups are available on the Advisory Council page.",
    link: "/advisory-council",
  },
  {
    id: "research-fellows",
    icon: BookOpen,
    title: "Research Fellows",
    subtitle: "Commission Research and Policy Specialists",
    responsibilities: [
      "Conduct research projects under the direction of the Research Director within Commission research programs",
      "Prepare research publications, intelligence reports, discussion papers, and policy analyses for Commission review",
      "Contribute specialist expertise to standards development, governance assessments, and policy work",
      "Represent the Commission at conferences, sector events, and research forums",
      "Engage with the Commission's university research partners and international networks",
      "Contribute to evidence collection and systems intelligence functions",
      "Support the Advisory Council in reviewing research outputs and providing expert analysis",
    ],
    note: "Research Fellows may be employed, contracted, or appointed as adjunct or honorary fellows. All fellows are subject to the Commission's conflict of interest and research integrity policies.",
  },
  {
    id: "secretariat",
    icon: FileSearch,
    title: "Secretariat",
    subtitle: "Operations, Communications, and Governance Support",
    responsibilities: [
      "Provides administrative and operational support to the governing body, Executive Director, and Commission programs",
      "Manages the Commission's public communications, website, and publications",
      "Administers the Commission's evidence submission portal and correspondence management",
      "Supports the Advisory Council secretariat function, including meeting coordination and records management",
      "Manages the Commission's membership and certification administration",
      "Coordinates service enquiry, assessment scheduling, and client management processes",
      "Maintains the Commission's financial records and supports financial reporting obligations",
      "Administers ACNC reporting, governance register, and compliance obligations",
    ],
    note: "The Secretariat function is led by an Operations Manager reporting to the Executive Director.",
  },
];

const orgChart = [
  { level: 1, label: "Governing Body (Board of Trustees)", sub: "Strategic governance, independence, and accountability" },
  { level: 2, label: "Executive Director (CEO)", sub: "Operational leadership and external representation" },
  { level: 3, label: "Research Director   |   Standards & Policy Director", sub: "Research programs, standards library, intelligence, assessment" },
  { level: 4, label: "Research Fellows   |   Assessment Specialists   |   Policy Analysts", sub: "Program delivery, publications, and specialist functions" },
  { level: 5, label: "Secretariat (Operations Manager + Staff)", sub: "Operations, communications, and governance support" },
];

export function Governance() {
  useSEO({ path: "/governance", title: "Governance & Accountability", description: "NLEC governance structure, accountability frameworks, and operational transparency as an independent ACNC-registered charity." });
  return (
    <PublicLayout>
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">
            GOVERNANCE AND ACCOUNTABILITY
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Governance and Accountability</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl mb-4">
            The Commission is governed in accordance with its Charter, the ACNC Act, and the governance standards it applies to other organisations — including its own obligations under NLEC-LEGS-005 (Institutional Accountability) and NLEC-LEGS-010 (Governance Transparency).
          </p>
          <p className="text-white/70 leading-relaxed max-w-3xl">
            Independence from government, funding bodies, and sector interests is a foundational governance requirement. The Commission publishes its governance framework, charter, conflict of interest register, and accountability reports publicly.
          </p>
        </div>
      </section>

      {/* Governance principles */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="container mx-auto px-4 max-w-5xl">
          <h2 className="text-2xl font-serif font-bold text-primary text-center mb-10">Governance Principles</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { title: "Independence", desc: "The Commission is not subject to direction by any government, funding body, or sector interest in its research, standards, or assessment functions." },
              { title: "Transparency", desc: "The Commission publishes its governance documents, financial information, conflict of interest register, and operational reports publicly, in accordance with NLEC-LEGS-010." },
              { title: "Accountability", desc: "The Commission applies the same governance standards to its own operations that it sets for others. It is subject to independent accountability mechanisms and ACNC reporting." },
              { title: "Lived Experience Leadership", desc: "A majority of governing body members have direct lived experience of the systems within the Commission's mandate." },
              { title: "Research Integrity", desc: "Research outputs are produced without interference from any party with an interest in the findings, and are subject to independent peer review before publication." },
              { title: "Ethical Conduct", desc: "All Commission operations adhere to the highest ethical standards, including in evidence collection, research methodology, and institutional engagement." },
            ].map(p => (
              <div key={p.title} className="border border-gray-200 p-6 bg-gray-50 hover:border-secondary transition-colors">
                <h4 className="font-bold text-primary mb-2">{p.title}</h4>
                <p className="text-sm text-gray-600 leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Org chart */}
      <section className="py-16 bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4 max-w-3xl">
          <h2 className="text-2xl font-serif font-bold text-primary text-center mb-10">Organisational Hierarchy</h2>
          <div className="space-y-2">
            {orgChart.map(row => (
              <div key={row.label} className={`p-5 border-l-4 ${row.level === 1 ? "border-primary bg-primary text-white" : row.level === 2 ? "border-secondary bg-secondary/10" : "border-gray-300 bg-white"}`}>
                <div className={`font-bold ${row.level === 1 ? "text-white" : "text-primary"}`}>{row.label}</div>
                <div className={`text-sm mt-1 ${row.level === 1 ? "text-white/75" : "text-gray-500"}`}>{row.sub}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-4 bg-secondary/10 border border-secondary/30 text-sm text-gray-600">
            <strong className="text-secondary">Advisory Council</strong> — operates independently alongside this hierarchy, providing expert advice to the governing body and Research Director without decision-making authority.
          </div>
        </div>
      </section>

      {/* Roles detail */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-14">
            <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-3">Governance Structure</h2>
            <h3 className="text-3xl font-serif font-bold text-primary">Roles and Responsibilities</h3>
          </div>

          <div className="space-y-12">
            {roles.map(role => (
              <div key={role.id} id={role.id} className="border-t-2 border-gray-200 pt-8">
                <div className="flex items-start gap-4 mb-5">
                  <div className="h-10 w-10 bg-secondary/10 flex items-center justify-center shrink-0">
                    <role.icon className="h-5 w-5 text-secondary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-serif font-bold text-primary">{role.title}</h3>
                    <p className="text-gray-500 text-sm">{role.subtitle}</p>
                  </div>
                </div>
                <ul className="space-y-2 mb-5 ml-14">
                  {role.responsibilities.map((r, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                      <ChevronRight className="h-4 w-4 text-secondary shrink-0 mt-0.5" />
                      {r}
                    </li>
                  ))}
                </ul>
                {role.note && (
                  <div className="ml-14 p-4 bg-gray-50 border-l-4 border-secondary text-sm text-gray-600 italic leading-relaxed">
                    {role.note}{" "}
                    {role.link && (
                      <Link href={role.link} className="text-secondary hover:underline not-italic font-semibold">View Advisory Council details →</Link>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ACNC registration */}
      <section className="py-12 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-serif font-bold text-primary text-xl mb-4">ACNC Registration Details</h3>
              <div className="space-y-2.5 text-sm">
                {[
                  ["Organisation", "National Lived Experience Commission"],
                  ["ABN", "79 919 184 486"],
                  ["Registered Charity", "ACNC Registration"],
                  ["Established", "10 August 2025"],
                  ["Financial Year End", "30 June"],
                  ["Registered Address", "Canberra ACT, Australia"],
                  ["Email", "commissioner@nlec.au"],
                ].map(([k, v]) => (
                  <div key={k} className="flex gap-3">
                    <span className="font-semibold text-primary min-w-44">{k}:</span>
                    <span className="text-gray-700">{v}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-serif font-bold text-primary text-xl mb-4">Governance Documents</h3>
              <div className="space-y-3">
                {[
                  { label: "Commission Charter", href: "/about" },
                  { label: "Advisory Council Framework", href: "/advisory-council" },
                  { label: "NLEC Standards Library", href: "/standards" },
                  { label: "Research Publications", href: "/publications" },
                  { label: "Privacy Policy", href: "/privacy" },
                  { label: "Refund Policy", href: "/refund-policy" },
                ].map(doc => (
                  <Link key={doc.label} href={doc.href} className="flex items-center gap-2 text-sm text-secondary hover:text-primary font-medium">
                    <ChevronRight size={14} />{doc.label}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
