import { PublicLayout } from "@/components/layout/PublicLayout";
import { useSEO } from "@/lib/useSEO";
import { Link } from "wouter";

const NAV = "#0B1F3A";
const GOLD = "#C6A85A";
const BORDER = "#E5E5E5";
const MUTED = "#555";
const TEXT = "#1A1A1A";

export function Methodology() {
  useSEO({
    path: "/methodology",
    title: "Commission Methodology",
    description: "How the National Lived Experience Commission approaches standards development, governance assessment, and the use of lived experience as systems intelligence. Evidence principles, research methodology, and public-interest posture.",
  });

  const C = { maxWidth: "1100px", margin: "0 auto", padding: "0 32px" };

  return (
    <PublicLayout>
      {/* Header */}
      <section style={{ background: NAV, padding: "80px 0 64px", borderBottom: `4px solid ${GOLD}` }}>
        <div style={C}>
          <div style={{ fontSize: "10px", fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "16px", fontFamily: "'Source Sans 3', sans-serif" }}>
            Commission Methodology
          </div>
          <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(24px, 4vw, 38px)", fontWeight: 700, color: "#fff", letterSpacing: "0.04em", lineHeight: 1.2, marginBottom: "20px" }}>
            How the Commission Works
          </h1>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "17px", color: "rgba(255,255,255,0.8)", maxWidth: "640px", lineHeight: 1.7 }}>
            The Commission's authority derives from the quality, rigour, and independence of its methods. This page sets out how NLEC approaches standards development, governance assessment, and the use of lived experience as systems intelligence.
          </p>
        </div>
      </section>

      {/* Intro */}
      <section style={{ background: "#F0F2F5", borderBottom: `1px solid ${BORDER}`, padding: "32px 0" }}>
        <div style={C}>
          <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", color: NAV, lineHeight: 1.7, maxWidth: "820px" }}>
            NLEC is a public-interest standards and advisory platform. Its methodology is designed to ensure that governance standards, assessments, and intelligence outputs are credible, evidence-grounded, independent, and practically useful for institutions operating across complex service systems.
          </p>
        </div>
      </section>

      {/* Standards approach */}
      <section style={{ background: "#fff", borderBottom: `1px solid ${BORDER}`, padding: "64px 0" }}>
        <div style={C}>
          <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: "56px", alignItems: "start" }}>
            <div>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "10px" }}>
                01
              </p>
              <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "20px", fontWeight: 600, color: NAV, letterSpacing: "0.04em", lineHeight: 1.3, marginBottom: "12px" }}>
                Standards Development
              </h2>
              <Link href="/standards" style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 600, color: NAV, textDecoration: "none", borderBottom: `1px solid ${NAV}`, paddingBottom: "1px" }}>
                View Standards Library
              </Link>
            </div>
            <div style={{ borderTop: `1px solid ${BORDER}` }}>
              {[
                {
                  title: "Evidence-grounded development",
                  text: "Each standard is developed from a base of lived experience evidence, sector consultation, and governance research. Standards are not aspirational documents — they reflect what governance excellence actually requires.",
                },
                {
                  title: "Structured review and consultation",
                  text: "Draft standards are subject to public consultation before finalisation. Lived experience communities, governance practitioners, and sector stakeholders are engaged in the review process.",
                },
                {
                  title: "Regular review cycle",
                  text: "Standards are reviewed on a defined cycle to ensure they remain current, reflect emerging governance evidence, and respond to sector feedback.",
                },
                {
                  title: "Domain alignment",
                  text: "Standards are organised across governance domains — including accountability, co-design integrity, evidence management, psychological safety, and workforce design — ensuring comprehensive coverage of lived experience governance requirements.",
                },
                {
                  title: "Public interest posture",
                  text: "Standards are published openly and free of charge. The Commission does not restrict access to its standards framework — wide adoption strengthens governance practice across the sector.",
                },
              ].map(item => (
                <div key={item.title} style={{ padding: "20px 0", borderBottom: `1px solid ${BORDER}` }}>
                  <h3 style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 700, color: NAV, marginBottom: "6px" }}>{item.title}</h3>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: MUTED, lineHeight: 1.65 }}>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Governance assessment approach */}
      <section style={{ background: "#F8F8F8", borderBottom: `1px solid ${BORDER}`, padding: "64px 0" }}>
        <div style={C}>
          <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: "56px", alignItems: "start" }}>
            <div>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "10px" }}>
                02
              </p>
              <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "20px", fontWeight: 600, color: NAV, letterSpacing: "0.04em", lineHeight: 1.3, marginBottom: "12px" }}>
                Governance Assessment
              </h2>
              <Link href="/assessments" style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 600, color: NAV, textDecoration: "none", borderBottom: `1px solid ${NAV}`, paddingBottom: "1px" }}>
                About Assessments
              </Link>
            </div>
            <div style={{ borderTop: `1px solid ${BORDER}` }}>
              {[
                {
                  title: "Eight-domain assessment framework",
                  text: "Assessments cover all eight governance domains: Governance Architecture, Lived Experience Integration, Evidence Management, Accountability Systems, Safeguarding Infrastructure, Engagement Practice, Psychological Safety, and Systems Intelligence.",
                },
                {
                  title: "Independence of assessors",
                  text: "Assessment personnel are subject to conflict of interest protocols. Assessors do not hold existing relationships with assessed organisations that could compromise assessment integrity.",
                },
                {
                  title: "Maturity rating methodology",
                  text: "Assessments produce domain-level maturity ratings against defined standards, structured recommendations for improvement, and board-level accountability findings. Ratings reflect evidence gathered — not self-reported compliance.",
                },
                {
                  title: "Confidentiality of findings",
                  text: "Assessment reports are provided to the commissioning organisation. They are not published without explicit consent. Organisations may choose to publish findings — the Commission does not require publication.",
                },
                {
                  title: "Voluntary engagement",
                  text: "All governance assessments are voluntary. The Commission does not exercise binding powers. Its authority derives from the rigour and credibility of the assessment process.",
                },
              ].map(item => (
                <div key={item.title} style={{ padding: "20px 0", borderBottom: `1px solid ${BORDER}` }}>
                  <h3 style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 700, color: NAV, marginBottom: "6px" }}>{item.title}</h3>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: MUTED, lineHeight: 1.65 }}>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Lived experience as systems intelligence */}
      <section style={{ background: "#fff", borderBottom: `1px solid ${BORDER}`, padding: "64px 0" }}>
        <div style={C}>
          <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: "56px", alignItems: "start" }}>
            <div>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "10px" }}>
                03
              </p>
              <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "20px", fontWeight: 600, color: NAV, letterSpacing: "0.04em", lineHeight: 1.3, marginBottom: "12px" }}>
                Lived Experience as Systems Intelligence
              </h2>
              <Link href="/dashboard" style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 600, color: NAV, textDecoration: "none", borderBottom: `1px solid ${NAV}`, paddingBottom: "1px" }}>
                Intelligence Dashboard
              </Link>
            </div>
            <div style={{ borderTop: `1px solid ${BORDER}` }}>
              {[
                {
                  title: "Lived experience as primary intelligence",
                  text: "The Commission proceeds from the position that lived experience evidence constitutes primary operational intelligence — not supplementary anecdote. Evidence from people with direct service system experience is collected and analysed using validated protocols that preserve its rigour and integrity.",
                },
                {
                  title: "Mixed-methods research model",
                  text: "Systems intelligence combines qualitative analysis of lived experience evidence with quantitative analysis of sector-wide data. Neither method is treated as superior — the strength of the intelligence lies in their integration.",
                },
                {
                  title: "Structured evidence aggregation",
                  text: "Individual evidence submissions are aggregated into domain-level intelligence findings. Submissions from multiple sources across a domain allow the Commission to identify structural patterns that no single submission reveals.",
                },
                {
                  title: "Pattern identification, not case advocacy",
                  text: "The Commission's intelligence function is systemic, not case-by-case. It does not investigate individual complaints or advocate for individual outcomes. It identifies governance patterns and structural failure modes.",
                },
                {
                  title: "Anonymisation and evidence sovereignty",
                  text: "Evidence contributors retain sovereignty over their submissions. Published intelligence outputs do not identify individuals or organisations without consent. Anonymisation protocols are applied before any aggregation.",
                },
              ].map(item => (
                <div key={item.title} style={{ padding: "20px 0", borderBottom: `1px solid ${BORDER}` }}>
                  <h3 style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 700, color: NAV, marginBottom: "6px" }}>{item.title}</h3>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: MUTED, lineHeight: 1.65 }}>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Evidence principles */}
      <section style={{ background: "#F8F8F8", borderBottom: `1px solid ${BORDER}`, padding: "64px 0" }}>
        <div style={C}>
          <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: "56px", alignItems: "start" }}>
            <div>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "10px" }}>
                04
              </p>
              <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "20px", fontWeight: 600, color: NAV, letterSpacing: "0.04em", lineHeight: 1.3 }}>
                Evidence &amp; Assessment Principles
              </h2>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1px", background: BORDER }}>
              {[
                { title: "Transparency of method", text: "The Commission discloses its research methods, data collection protocols, analytical frameworks, and limitations in all outputs." },
                { title: "Independent review", text: "Significant research outputs are subject to independent peer review before publication. The Advisory Council includes methodology expertise." },
                { title: "Proportionate standards", text: "The Commission recognises resource constraints. Governance standards are proportionate to organisational capacity while maintaining integrity." },
                { title: "Ethical conduct", text: "All research involving human participants follows the National Statement on Ethical Conduct in Human Research and the Commission's Ethics principles." },
                { title: "Non-advocacy posture", text: "The Commission does not advocate for political outcomes. Its work is grounded in evidence and standards, not advocacy or lobbying." },
                { title: "Conflict of interest management", text: "Declared conflicts of interest are managed through protocols that preserve the integrity of affected standards, assessments, and research." },
              ].map(item => (
                <div key={item.title} style={{ background: "#fff", padding: "24px 28px" }}>
                  <h3 style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", fontWeight: 700, color: NAV, marginBottom: "8px" }}>{item.title}</h3>
                  <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: MUTED, lineHeight: 1.65 }}>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Public interest posture */}
      <section style={{ background: NAV, padding: "56px 0" }}>
        <div style={C}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "48px", alignItems: "center" }}>
            <div>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "10px", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase" as const, color: GOLD, marginBottom: "12px" }}>
                Public-Interest Posture
              </p>
              <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(18px, 2.5vw, 26px)", fontWeight: 600, color: "#fff", letterSpacing: "0.04em", lineHeight: 1.3, marginBottom: "16px" }}>
                Not a regulator. Not a peak body.
              </h2>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "15px", color: "rgba(255,255,255,0.75)", lineHeight: 1.7 }}>
                The Commission's authority is reputational, not regulatory. It produces independent standards and intelligence that institutions, governments, and regulators may adopt — but it cannot compel compliance. Its influence depends entirely on the quality and credibility of its work.
              </p>
            </div>
            <div style={{ borderTop: "1px solid rgba(255,255,255,0.15)" }}>
              {[
                { label: "Not", text: "A government regulatory body or statutory authority" },
                { label: "Not", text: "A representative peak body or advocacy organisation" },
                { label: "Not", text: "A complaints management or investigative body" },
                { label: "Is", text: "An independent public-interest standards platform" },
                { label: "Is", text: "An assessment and advisory body" },
                { label: "Is", text: "A systems intelligence and governance capability" },
              ].map((item, i) => (
                <div key={i} style={{ padding: "14px 0", borderBottom: "1px solid rgba(255,255,255,0.1)", display: "flex", gap: "16px", alignItems: "center" }}>
                  <span style={{
                    fontFamily: "'Source Sans 3', sans-serif",
                    fontSize: "10px",
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                    color: item.label === "Is" ? GOLD : "rgba(255,255,255,0.4)",
                    flexShrink: 0,
                    width: "28px",
                  }}>{item.label}</span>
                  <span style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "13px", color: item.label === "Is" ? "rgba(255,255,255,0.85)" : "rgba(255,255,255,0.45)", lineHeight: 1.5 }}>{item.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ background: "#fff", borderTop: `1px solid ${BORDER}`, padding: "56px 0" }}>
        <div style={C}>
          <div style={{ display: "flex", gap: "32px", flexWrap: "wrap" as const, alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: "18px", fontWeight: 600, color: NAV, marginBottom: "8px" }}>
                Ready to engage the Commission?
              </h2>
              <p style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", color: MUTED }}>
                Request a briefing, commission an assessment, or explore the standards library.
              </p>
            </div>
            <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" as const }}>
              <Link href="/request-briefing" style={{ display: "inline-block", background: NAV, color: "#fff", padding: "11px 24px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 600, textDecoration: "none" }}>
                Request Briefing
              </Link>
              <Link href="/assessments" style={{ display: "inline-block", border: `1px solid ${NAV}`, color: NAV, padding: "11px 24px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 600, textDecoration: "none" }}>
                Commission an Assessment
              </Link>
              <Link href="/standards" style={{ display: "inline-block", border: `1px solid ${BORDER}`, color: MUTED, padding: "11px 24px", fontFamily: "'Source Sans 3', sans-serif", fontSize: "14px", fontWeight: 600, textDecoration: "none" }}>
                Explore Standards
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
