import { useEffect, useState } from "react";
import { Link, useSearch } from "wouter";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, Loader2, Mail, FileText, ArrowRight } from "lucide-react";

export function PaymentSuccess() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const sessionId = params.get("session_id");

  const [session, setSession] = useState<{ status: string; customerEmail?: string; amountTotal?: number } | null>(null);
  const [loading, setLoading] = useState(!!sessionId);
  const [fetchError, setFetchError] = useState(false);

  useEffect(() => {
    if (!sessionId) return;
    fetch(`/api/stripe/session/${sessionId}`)
      .then(r => {
        if (!r.ok) throw new Error("not found");
        return r.json();
      })
      .then(data => {
        setSession(data);
        setLoading(false);
      })
      .catch(() => {
        setFetchError(true);
        setLoading(false);
      });
  }, [sessionId]);

  const verified = session?.status === "paid";

  return (
    <PublicLayout>
      <section className="py-24 bg-white min-h-[60vh] flex items-center">
        <div className="container mx-auto px-4 max-w-2xl text-center">

          {/* No session_id in URL */}
          {!sessionId && (
            <>
              <div className="flex justify-center mb-8">
                <AlertTriangle className="h-20 w-20 text-amber-500" />
              </div>
              <div className="inline-flex items-center px-3 py-1 border border-amber-300 bg-amber-50 text-amber-700 text-sm font-semibold tracking-wider mb-6">
                NO PAYMENT REFERENCE
              </div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-6">Payment Not Found</h1>
              <p className="text-gray-600 leading-relaxed mb-8">
                This page could not locate a payment reference. If you have completed a payment, please check your email for a confirmation receipt.
              </p>
              <p className="mb-8">
                <a href="mailto:commissioner@nlec.au" className="text-secondary font-semibold hover:underline">commissioner@nlec.au</a>
              </p>
              <Button asChild className="rounded-none bg-primary hover:bg-secondary text-white">
                <Link href="/">Return to Homepage</Link>
              </Button>
            </>
          )}

          {/* Loading while session is retrieved */}
          {sessionId && loading && (
            <>
              <div className="flex justify-center mb-8">
                <Loader2 className="h-20 w-20 text-primary animate-spin" />
              </div>
              <h1 className="text-2xl font-serif font-bold text-primary mb-4">Verifying Payment</h1>
              <p className="text-gray-600">Please wait while your payment is confirmed with our payment processor.</p>
            </>
          )}

          {/* Session retrieved but payment not in paid state */}
          {!loading && sessionId && (fetchError || !verified) && (
            <>
              <div className="flex justify-center mb-8">
                <AlertTriangle className="h-20 w-20 text-amber-500" />
              </div>
              <div className="inline-flex items-center px-3 py-1 border border-amber-300 bg-amber-50 text-amber-700 text-sm font-semibold tracking-wider mb-6">
                PAYMENT NOT CONFIRMED
              </div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-6">Payment Could Not Be Verified</h1>
              <p className="text-gray-600 leading-relaxed mb-4">
                Your payment has not been confirmed as successfully processed. This may be because the payment is still pending, was declined, or the session reference is invalid.
              </p>
              <p className="text-gray-600 leading-relaxed mb-8">
                Please do not re-submit payment without first contacting the Commission to confirm your transaction status.
              </p>
              <div className="bg-amber-50 border border-amber-200 p-6 mb-8 text-left">
                <p className="text-sm text-amber-800 font-medium mb-2">Contact the Commission</p>
                <a href="mailto:commissioner@nlec.au" className="text-secondary font-semibold hover:underline">commissioner@nlec.au</a>
              </div>
              <Button asChild className="rounded-none bg-primary hover:bg-secondary text-white">
                <Link href="/">Return to Homepage</Link>
              </Button>
            </>
          )}

          {/* Payment verified as paid */}
          {!loading && verified && (
            <>
              <div className="flex justify-center mb-8">
                <CheckCircle className="h-20 w-20 text-green-500" />
              </div>
              <div className="inline-flex items-center px-3 py-1 border border-green-300 bg-green-50 text-green-700 text-sm font-semibold tracking-wider mb-6">
                PAYMENT CONFIRMED
              </div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-6">Payment Confirmation</h1>
              <p className="text-xl text-gray-700 leading-relaxed mb-4">
                Thank you for your transaction.
              </p>
              <p className="text-gray-600 leading-relaxed mb-4">
                Your payment has been successfully processed.
              </p>
              {session?.customerEmail ? (
                <p className="text-gray-600 mb-6">
                  A confirmation receipt has been sent to <strong>{session.customerEmail}</strong>.
                </p>
              ) : (
                <p className="text-gray-600 mb-6">
                  A confirmation receipt has been sent to your registered email address.
                </p>
              )}

              <div className="grid sm:grid-cols-2 gap-4 mb-10 text-left">
                <div className="border border-gray-200 p-5 flex gap-3">
                  <Mail className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-primary text-sm mb-1">Receipt Emailed</div>
                    <div className="text-xs text-gray-600">A tax receipt has been sent to your email address.</div>
                  </div>
                </div>
                <div className="border border-gray-200 p-5 flex gap-3">
                  <FileText className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-primary text-sm mb-1">Access Provisioned</div>
                    <div className="text-xs text-gray-600">Your membership or enrolment access will be activated within 1 business day.</div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 border border-gray-200 p-6 mb-8 text-left">
                <h3 className="font-semibold text-primary mb-3">Questions?</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  If you have any questions regarding your membership, certification enrolment, or service request, please contact the Commission.
                </p>
                <p className="mt-3">
                  <a href="mailto:commissioner@nlec.au" className="text-secondary font-semibold hover:underline">commissioner@nlec.au</a>
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild className="rounded-none bg-primary hover:bg-secondary text-white">
                  <Link href="/">Return to Homepage</Link>
                </Button>
                <Button asChild variant="outline" className="rounded-none border-secondary text-secondary hover:bg-secondary hover:text-white">
                  <Link href="/standards">Explore Standards Library <ArrowRight size={14} className="ml-2" /></Link>
                </Button>
              </div>
            </>
          )}

        </div>
      </section>
    </PublicLayout>
  );
}
