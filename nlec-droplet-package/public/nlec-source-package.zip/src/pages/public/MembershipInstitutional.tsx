import { useState } from "react";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { CheckSquare } from "lucide-react";
import { CheckoutModal } from "@/components/CheckoutModal";

const tiers = [
  {
    name: "Foundation Institutional Member",
    price: "$5,000",
    priceDisplay: "$5,000 AUD / year",
    priceNote: "AUD per year",
    tierKey: "foundation_institutional",
    highlight: false,
    canCheckout: true,
    benefits: [
      "Access to the Commission's standards library",
      "Governance briefing materials",
      "Research publication access",
      "Participation in consultation processes",
    ],
  },
  {
    name: "Professional Institutional Member",
    price: "$12,000",
    priceDisplay: "$12,000 AUD / year",
    priceNote: "AUD per year",
    tierKey: "professional_institutional",
    highlight: true,
    badge: "Recommended",
    canCheckout: true,
    benefits: [
      "All Foundation benefits",
      "Governance benchmarking tools",
      "Institutional dashboard access",
      "Priority participation in research initiatives",
      "Discounted assessment services",
    ],
  },
  {
    name: "Strategic Institutional Member",
    price: "$25,000",
    priceDisplay: "$25,000 AUD / year",
    priceNote: "AUD per year",
    tierKey: "strategic_institutional",
    highlight: false,
    canCheckout: true,
    benefits: [
      "All Professional benefits",
      "Direct engagement with Commission advisory programs",
      "Customised governance briefings",
      "Early access to systems intelligence reports",
      "Priority participation in institutional assessment programs",
    ],
  },
];

export function MembershipInstitutional() {
  const [modal, setModal] = useState<typeof tiers[0] | null>(null);

  return (
    <PublicLayout>
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">
            INSTITUTIONAL MEMBERSHIP
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Institutional Membership</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl mb-4">
            Institutional membership enables organisations to engage directly with the Commission's governance frameworks, standards library, and systems intelligence resources.
          </p>
          <p className="text-white/70 leading-relaxed max-w-3xl">
            Membership supports organisations seeking to strengthen engagement with lived experience expertise and enhance institutional accountability.
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid md:grid-cols-3 gap-6">
            {tiers.map((tier) => (
              <div
                key={tier.name}
                className={`flex flex-col border p-8 transition-all ${
                  tier.highlight
                    ? "border-secondary shadow-md bg-secondary/5"
                    : "border-gray-200 hover:border-secondary hover:shadow-sm"
                }`}
              >
                {tier.badge && (
                  <div className="text-xs font-bold tracking-wider text-white bg-secondary px-3 py-1 mb-4 self-start">
                    {tier.badge}
                  </div>
                )}
                <h3 className="text-xl font-serif font-bold text-primary mb-2">{tier.name}</h3>
                <div className="mb-6">
                  <span className="text-3xl font-mono font-bold text-secondary">{tier.price}</span>
                  <span className="text-gray-500 text-sm ml-2">{tier.priceNote}</span>
                </div>
                <ul className="space-y-3 mb-8 flex-grow">
                  {tier.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-2 text-sm text-gray-700">
                      <CheckSquare className="h-4 w-4 text-secondary mt-0.5 shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  onClick={() => setModal(tier)}
                  className={`w-full rounded-none ${
                    tier.highlight
                      ? "bg-secondary hover:bg-primary text-white"
                      : "bg-primary hover:bg-secondary text-white"
                  }`}
                >
                  Subscribe — Pay with Card
                </Button>
                <p className="text-xs text-gray-400 text-center mt-2">
                  Or contact <a href="mailto:commissioner@nlec.au" className="underline">commissioner@nlec.au</a> to arrange invoicing
                </p>
              </div>
            ))}
          </div>

          <div className="mt-10 p-6 border border-gray-200 bg-gray-50 text-sm text-gray-600 text-center">
            <strong className="text-primary">Invoice preference?</strong> Institutional memberships can also be invoiced annually. Contact{" "}
            <a href="mailto:commissioner@nlec.au" className="text-secondary hover:underline font-semibold">commissioner@nlec.au</a> to arrange an invoice.
          </div>
        </div>
      </section>

      <section className="py-12 bg-gray-50 border-t">
        <div className="container mx-auto px-4 max-w-4xl">
          <h3 className="text-xl font-serif font-bold text-primary text-center mb-8">Who Joins as Institutional Members</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {["Government departments and agencies", "Public hospitals and health services", "Universities and research institutions", "Non-government organisations (NGOs)", "Mental health and community service providers", "Advisory and consulting firms"].map(org => (
              <div key={org} className="flex items-center gap-2 text-sm text-gray-700 p-3 border border-gray-100 bg-white">
                <CheckSquare className="h-4 w-4 text-secondary shrink-0" />
                {org}
              </div>
            ))}
          </div>
        </div>
      </section>

      {modal && (
        <CheckoutModal
          tierKey={modal.tierKey}
          tierName={modal.name}
          tierPrice={modal.priceDisplay}
          mode="subscription"
          onClose={() => setModal(null)}
        />
      )}
    </PublicLayout>
  );
}
