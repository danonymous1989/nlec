import { PublicLayout } from "@/components/layout/PublicLayout";
import { Link } from "wouter";

export function Terms() {
  return (
    <PublicLayout>
      <title>Terms of Use | National Lived Experience Commission</title>
      <div className="bg-gray-50 border-b py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="text-4xl font-serif font-bold text-primary mb-4">Terms of Use</h1>
          <p className="text-gray-500 text-sm">Last updated: 1 March 2024</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="space-y-12">
          {termsSections.map(({ heading, content }) => (
            <div key={heading} className="border-l-4 border-secondary/30 pl-6">
              <h2 className="text-2xl font-serif font-bold text-primary mb-4">{heading}</h2>
              <div className="space-y-4 text-gray-700 leading-relaxed">
                {content.map((para, i) => <p key={i}>{para}</p>)}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gray-50 border border-gray-200 p-8">
          <h3 className="text-lg font-serif font-bold text-primary mb-3">Questions About These Terms</h3>
          <p className="text-gray-600 mb-4">If you have questions about these Terms of Use, please contact the Commission.</p>
          <Link href="/contact" className="text-secondary font-semibold underline hover:text-secondary/80">Contact the Commission</Link>
        </div>
      </div>
    </PublicLayout>
  );
}

const termsSections = [
  {
    heading: "1. Acceptance of Terms",
    content: [
      "By accessing and using the National Lived Experience Commission (NLEC) website, you accept and agree to be bound by these Terms of Use. If you do not agree to these terms, you should not use this website.",
      "The Commission reserves the right to amend these terms at any time. Continued use of the website following the publication of revised terms constitutes acceptance of those terms.",
    ],
  },
  {
    heading: "2. About This Website",
    content: [
      "This website is operated by the National Lived Experience Commission, an independent Australian public interest body and ACNC-registered charity. The Commission is not a government department or statutory authority. The website provides information about the Commission's work, publications, standards, research programs, and evidence submission services.",
      "The Commission endeavours to ensure that information on this website is accurate and current. However, the Commission makes no warranties or representations about the accuracy, completeness, or suitability of the information for any particular purpose.",
    ],
  },
  {
    heading: "3. Use of Content",
    content: [
      "Content published on this website, including text, documents, reports, and images, is protected by copyright. Unless otherwise indicated, copyright is owned by the National Lived Experience Commission.",
      "You may access, download, and reproduce Commission content for personal, educational, research, or non-commercial purposes, provided that the Commission is clearly attributed as the source and the content is reproduced in full and without modification.",
      "Reproduction of Commission content for commercial purposes requires prior written permission from the Commission.",
      "Nothing in these terms affects rights that may exist under the Copyright Act 1968 (Cth), including fair dealing provisions.",
    ],
  },
  {
    heading: "4. Evidence Submissions",
    content: [
      "The evidence submission portal on this website enables individuals and organisations to submit evidence that may be used to inform the Commission's research, standards development, and systems intelligence functions.",
      "By submitting evidence through this portal, you represent that the information you provide is accurate to the best of your knowledge, and you consent to the Commission using that information in accordance with its Privacy Policy and the Evidence Integrity Standard (NLEC-LEGS-005).",
      "The Commission is not a complaints resolution body. Evidence submitted through the portal is used for systemic governance intelligence purposes and does not constitute a formal complaint or grievance process.",
      "Evidence submissions that contain information about another person's personal circumstances will be handled with particular care and in accordance with the Commission's privacy obligations.",
    ],
  },
  {
    heading: "5. Acceptable Use",
    content: [
      "You agree to use this website only for lawful purposes and in a manner that does not infringe the rights of others or restrict or inhibit the use of the website by any third party.",
      "You must not use this website to submit false, misleading, or deliberately harmful information.",
      "You must not attempt to gain unauthorised access to any part of this website or its underlying systems.",
      "You must not use this website in any way that could damage, disable, or impair the website or interfere with other users.",
    ],
  },
  {
    heading: "6. External Links",
    content: [
      "This website may contain links to external websites operated by third parties. These links are provided for convenience only and do not constitute endorsement of those sites or their content by the Commission.",
      "The Commission is not responsible for the content, accuracy, or availability of external websites and makes no representations about them.",
    ],
  },
  {
    heading: "7. Disclaimer",
    content: [
      "The information on this website is provided for general informational purposes only and does not constitute legal, professional, or regulatory advice.",
      "The Commission does not warrant that the website will be continuously available, error-free, or free from viruses or other harmful components.",
      "To the maximum extent permitted by law, the Commission excludes liability for any loss or damage arising from use of or reliance on information provided on this website.",
    ],
  },
  {
    heading: "8. Governing Law",
    content: [
      "These Terms of Use are governed by the laws of the Australian Capital Territory and the Commonwealth of Australia.",
      "Any disputes arising from use of this website will be subject to the exclusive jurisdiction of the courts of the Australian Capital Territory.",
    ],
  },
  {
    heading: "9. Contact",
    content: [
      "If you have questions about these Terms of Use or wish to report a concern about website content or use, please contact the Commission using the contact details available on the Contact page.",
    ],
  },
];
