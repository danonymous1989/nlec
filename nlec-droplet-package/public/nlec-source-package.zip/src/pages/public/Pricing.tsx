import { Link } from "wouter";
import { PublicLayout } from "@/components/layout/PublicLayout";
import { Button } from "@/components/ui/button";
import { CheckSquare, ArrowRight } from "lucide-react";

const membershipProfessional = [
  { name: "Professional Member", price: "$180 / year", features: ["Member briefings and research updates", "Commission consultations", "Certification eligibility", "Selected standards resources", "Professional network"] },
  { name: "Advanced Professional Member", price: "$360 / year", features: ["All Professional benefits", "Full research publication access", "Governance guidance notes", "Discounted certifications", "Priority event access"] },
  { name: "Fellow / Specialist Member", price: "$480 / year", features: ["All Advanced benefits", "Community recognition", "Specialist working groups", "Early access to standards and reports"] },
];

const membershipInstitutional = [
  { name: "Foundation Institutional Member", price: "$5,000 / year", features: ["Standards library access", "Governance briefings", "Research publications", "Consultation participation"] },
  { name: "Professional Institutional Member", price: "$12,000 / year", features: ["All Foundation benefits", "Benchmarking tools", "Institutional dashboard", "Research priority access", "Discounted assessments"] },
  { name: "Strategic Institutional Member", price: "$25,000 / year", features: ["All Professional benefits", "Advisory program access", "Customised briefings", "Early intelligence reports", "Assessment priority access"] },
];

const certifications = [
  { name: "Certified Lived Experience Governance Practitioner", code: "NLEC-CERT-001", price: "$2,500" },
  { name: "Certified Systems Intelligence Analyst", code: "NLEC-CERT-002", price: "$3,500" },
  { name: "Certified Institutional Engagement Specialist", code: "NLEC-CERT-003", price: "$4,800" },
];

const services = [
  { name: "Lived Experience Governance Audit", from: "from $20,000" },
  { name: "Institutional Maturity Assessment", from: "from $35,000" },
  { name: "Workforce Integration Review", from: "from $20,000" },
  { name: "Engagement Integrity Assessment", from: "from $25,000" },
  { name: "Safeguarding and Psychological Safety Review", from: "from $20,000" },
  { name: "Systems Intelligence Baseline Assessment", from: "from $50,000" },
];

export function Pricing() {
  return (
    <PublicLayout>
      <section className="bg-primary text-white py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">PRICING</div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Pricing Schedule</h1>
          <p className="text-xl text-white/85 leading-relaxed max-w-3xl">
            All prices are in Australian Dollars (AUD). Memberships are billed annually. Certifications are one-time enrolment fees. Institutional services are quoted on engagement.
          </p>
        </div>
      </section>

      {/* Professional Membership */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10">
            <div>
              <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-2">Individual</h2>
              <h3 className="text-3xl font-serif font-bold text-primary">Professional Membership</h3>
            </div>
            <Link href="/membership/professional" className="text-secondary font-semibold flex items-center mt-4 md:mt-0 hover:text-primary">View details <ArrowRight size={16} className="ml-1" /></Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {membershipProfessional.map((tier, i) => (
              <div key={tier.name} className={`border p-8 flex flex-col ${i === 1 ? "border-secondary bg-secondary/5" : "border-gray-200"}`}>
                <h4 className="font-serif font-bold text-primary mb-2">{tier.name}</h4>
                <div className="text-2xl font-mono font-bold text-secondary mb-4">{tier.price}</div>
                <ul className="space-y-2 flex-grow mb-6">
                  {tier.features.map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                      <CheckSquare className="h-3.5 w-3.5 text-secondary mt-0.5 shrink-0" />{f}
                    </li>
                  ))}
                </ul>
                <Button asChild className="w-full rounded-none bg-primary hover:bg-secondary text-white text-sm">
                  <Link href="/membership/professional">Join Now</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Institutional Membership */}
      <section className="py-20 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10">
            <div>
              <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-2">Organisations</h2>
              <h3 className="text-3xl font-serif font-bold text-primary">Institutional Membership</h3>
            </div>
            <Link href="/membership/institutional" className="text-secondary font-semibold flex items-center mt-4 md:mt-0 hover:text-primary">View details <ArrowRight size={16} className="ml-1" /></Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {membershipInstitutional.map((tier, i) => (
              <div key={tier.name} className={`border p-8 flex flex-col ${i === 1 ? "border-secondary shadow-md bg-white" : "border-gray-200 bg-white"}`}>
                <h4 className="font-serif font-bold text-primary mb-2">{tier.name}</h4>
                <div className="text-2xl font-mono font-bold text-secondary mb-4">{tier.price}</div>
                <ul className="space-y-2 flex-grow mb-6">
                  {tier.features.map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                      <CheckSquare className="h-3.5 w-3.5 text-secondary mt-0.5 shrink-0" />{f}
                    </li>
                  ))}
                </ul>
                <Button asChild className="w-full rounded-none bg-primary hover:bg-secondary text-white text-sm">
                  <Link href="/membership/institutional">Enquire</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-20 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10">
            <div>
              <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-2">Professional Development</h2>
              <h3 className="text-3xl font-serif font-bold text-primary">Certification Programs</h3>
            </div>
            <Link href="/certifications" className="text-secondary font-semibold flex items-center mt-4 md:mt-0 hover:text-primary">View programs <ArrowRight size={16} className="ml-1" /></Link>
          </div>
          <div className="space-y-4">
            {certifications.map(cert => (
              <div key={cert.name} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-6 border border-gray-200 hover:border-secondary transition-colors gap-4">
                <div className="flex items-start gap-4">
                  <span className="text-xs font-mono font-bold text-primary border border-primary/20 px-2 py-1 whitespace-nowrap">{cert.code}</span>
                  <span className="font-serif font-semibold text-primary">{cert.name}</span>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className="text-xl font-mono font-bold text-secondary">{cert.price}</span>
                  <Button asChild size="sm" className="rounded-none bg-secondary hover:bg-primary text-white">
                    <Link href="/certifications">Enrol</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <p className="text-sm text-gray-500 mt-4">Certification fees are one-time enrolment fees, billed in AUD.</p>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10">
            <div>
              <h2 className="text-sm font-bold tracking-widest text-secondary uppercase mb-2">For Organisations</h2>
              <h3 className="text-3xl font-serif font-bold text-primary">Institutional Assessment Services</h3>
            </div>
            <Link href="/services" className="text-secondary font-semibold flex items-center mt-4 md:mt-0 hover:text-primary">Request service <ArrowRight size={16} className="ml-1" /></Link>
          </div>
          <div className="space-y-3">
            {services.map(svc => (
              <div key={svc.name} className="flex items-center justify-between p-5 border border-gray-200 bg-white hover:border-secondary transition-colors">
                <span className="font-medium text-primary">{svc.name}</span>
                <span className="text-secondary font-semibold text-sm">{svc.from} AUD</span>
              </div>
            ))}
          </div>
          <div className="mt-6 p-5 border border-gray-200 bg-white text-sm text-gray-600">
            Service fees are indicative only. Final pricing is provided in a formal proposal following scoping discussions. Custom enterprise engagements are available.
          </div>
          <div className="mt-4 text-center">
            <Button asChild className="rounded-none bg-secondary hover:bg-primary text-white px-10">
              <Link href="/services#enquiry">Request a Consultation</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Payment note */}
      <section className="py-10 bg-primary text-white text-center">
        <div className="container mx-auto px-4 max-w-2xl">
          <p className="text-white/80 text-sm leading-relaxed mb-2">
            All payments are processed securely via Stripe. Institutional invoicing is available for memberships and services. For billing enquiries, contact{" "}
            <a href="mailto:commissioner@nlec.au" className="text-accent hover:underline">commissioner@nlec.au</a>
          </p>
          <p className="text-white/60 text-xs">ABN 79 919 184 486 — National Lived Experience Commission</p>
        </div>
      </section>
    </PublicLayout>
  );
}
