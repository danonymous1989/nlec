import { PublicLayout } from "@/components/layout/PublicLayout";

const sections = [
  {
    heading: "Overview",
    content: `This Refund Policy applies to all payments made to the National Lived Experience Commission (NLEC, ABN 79 919 184 486) for membership subscriptions, certification program enrolments, and institutional service deposits.\n\nThe Commission is committed to fair and transparent refund practices consistent with Australian Consumer Law.`,
  },
  {
    heading: "Annual Membership Subscriptions",
    content: `Membership subscriptions are billed annually in advance.\n\nCancellations within 14 days of the initial subscription payment or annual renewal will receive a full refund.\n\nAfter the 14-day cooling-off period, membership fees are non-refundable. Members who cancel after this period will retain access to their membership benefits until the end of their current subscription year.\n\nMembership subscriptions will be cancelled and not renewed at the end of the subscription year upon written request to commissioner@nlec.au.`,
  },
  {
    heading: "Certification Program Enrolments",
    content: `Enrolment fees for Commission certification programs are refundable as follows:\n\n• Full refund: If cancellation is requested within 14 days of payment, provided program materials have not been accessed.\n\n• 50% refund: If cancellation is requested more than 14 days after payment, provided the program has not been commenced.\n\n• No refund: Once the program has commenced (materials accessed, assessments submitted, or modules commenced).\n\nIn exceptional circumstances, the Commission may approve deferral of enrolment to a future program intake at its discretion.`,
  },
  {
    heading: "Institutional Service Deposits",
    content: `Deposit payments for institutional services are refundable if the Commission is unable to commence the agreed engagement within the timeframe specified in the service agreement.\n\nDeposit payments are non-refundable once the scoping or assessment engagement has commenced in accordance with the agreed workplan.\n\nAny dispute regarding service delivery will be managed in accordance with the terms of the relevant service agreement.`,
  },
  {
    heading: "How to Request a Refund",
    content: `To request a refund, please contact the Commission in writing:\n\nEmail: commissioner@nlec.au\nSubject line: Refund Request — [your name / organisation name]\n\nPlease include your payment confirmation details and the reason for your request. The Commission will acknowledge your request within 3 business days and process eligible refunds within 10 business days.`,
  },
  {
    heading: "Australian Consumer Law",
    content: `Nothing in this Refund Policy limits your rights under the Australian Consumer Law (Competition and Consumer Act 2010, Schedule 2). If a service is not fit for purpose, not delivered as described, or not of acceptable quality, you may be entitled to a remedy under the Australian Consumer Law.`,
  },
  {
    heading: "Policy Review",
    content: `This Refund Policy is reviewed annually. The Commission reserves the right to amend this policy at any time. Any amendments will be published on this page with an updated effective date.\n\nLast reviewed: March 2026`,
  },
];

export function RefundPolicy() {
  return (
    <PublicLayout>
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 border border-accent/40 bg-accent/10 text-accent text-sm font-semibold tracking-wider mb-6">LEGAL</div>
          <h1 className="text-4xl font-serif font-bold mb-4">Refund Policy</h1>
          <p className="text-white/80">National Lived Experience Commission — ABN 79 919 184 486</p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="prose prose-lg max-w-none">
            {sections.map(s => (
              <div key={s.heading} className="mb-10">
                <h2 className="text-xl font-serif font-bold text-primary mb-4 pb-2 border-b border-gray-200">{s.heading}</h2>
                {s.content.split("\n\n").map((para, i) => (
                  <p key={i} className="text-gray-700 leading-relaxed mb-3">{para}</p>
                ))}
              </div>
            ))}
          </div>
          <div className="mt-12 p-6 bg-gray-50 border border-gray-200 text-sm text-gray-600">
            <strong className="text-primary">Contact:</strong> For questions about this policy, contact the Commission at{" "}
            <a href="mailto:commissioner@nlec.au" className="text-secondary hover:underline">commissioner@nlec.au</a>.
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
