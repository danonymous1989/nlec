import { PublicLayout } from "@/components/layout/PublicLayout";
import { CTASection, ContactBlock, PageHeader, ServiceCard, SectionHeading } from "@/components/site";
import { serviceCards } from "@/lib/site";
import { useSEO } from "@/lib/useSEO";

export function Services() {
  useSEO({
    path: "/services",
    title: "Services / Partner With Us",
    description: "Government advisory, consultation design, institutional review, research, stakeholder engagement and policy-service design review at NLEC.",
  });

  return (
    <PublicLayout>
      <PageHeader
        eyebrow="Services"
        title="Partner with NLEC on reform, evidence and public-interest work"
        description="The Commission offers professional, careful and nationally relevant services for organisations that want to engage lived experience responsibly."
      />

      <section className="section-block">
        <div className="site-container grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <SectionHeading
              eyebrow="Service offering"
              title="Professional services that support practical change"
              description="Each service can be shaped to the institution, issue and audience. The goal is to keep the work evidence-led, trauma-informed and useful."
            />
            <div className="grid gap-6 md:grid-cols-2">
              {serviceCards.map((item) => (
                <ServiceCard key={item.title} title={item.title} description={item.description} />
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <ContactBlock />
            <div className="site-card">
              <p className="card-kicker">How we work</p>
              <h3 className="card-title">Careful scope, clear outputs, accountable process</h3>
              <p className="card-copy">
                NLEC works best when the brief is precise, the audience is clear and the intended use of the work is stated upfront.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container grid gap-6 md:grid-cols-3">
          <ServiceCard
            title="Government advisory"
            description="Support departments, agencies and cross-sector initiatives with public-interest advice rooted in lived-experience evidence."
          />
          <ServiceCard
            title="Organisational training"
            description="Build internal capability so teams can use lived experience in ways that are respectful, structured and useful."
          />
          <ServiceCard
            title="Public education"
            description="Create briefings, talks and material that improve public understanding of lived experience, reform and accountability."
          />
        </div>
      </section>

      <CTASection
        title="Ready to scope a partnership?"
        description="If you need an advisory, research or engagement partner that can keep the work clear, ethical and practical, discuss it with NLEC."
        primary={{ label: "Discuss a partnership", href: "/contact" }}
        secondary={{ label: "View publications", href: "/publications" }}
      />
    </PublicLayout>
  );
}

