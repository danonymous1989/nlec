import { PublicLayout } from "@/components/layout/PublicLayout";
import {
  ButtonLink,
  CTASection,
  Hero,
  InfoCard,
  PublicationCard,
  SectionHeading,
  StatCard,
} from "@/components/site";
import {
  charitablePurposes,
  nationalWorkAreas,
  organisation,
  publicationReleases,
} from "@/lib/site";
import { useSEO } from "@/lib/useSEO";

const heroAside = (
    <div className="muted-panel space-y-5">
      <div>
        <p className="card-kicker">National remit</p>
        <p className="text-lg font-serif tracking-[0.03em] text-[color:var(--nav)]">
          Independent, nationally focused and reform-oriented.
        </p>
      </div>
      <ul className="space-y-3 text-sm leading-7 text-[color:var(--muted)]">
        <li>- Lived experience is evidence.</li>
        <li>- Evidence should inform accountability.</li>
        <li>- Reform should be practical and trauma-informed.</li>
      </ul>
      <ButtonLink href="/contact" tone="secondary">
        Contact the Commission
      </ButtonLink>
    </div>
);

export function Home() {
  useSEO({
    path: "/",
    title: "Home",
    description: "The National Lived Experience Commission advances public debate, social welfare and health by translating lived experience into evidence, policy insight and practical reform.",
  });

  return (
    <PublicLayout>
      <Hero
        eyebrow="National Lived Experience Commission"
        title="Lived experience is operational intelligence for national reform."
        description="The National Lived Experience Commission advances public debate, social welfare and health by translating lived experience into evidence, policy insight, institutional learning and practical reform."
        primaryCta={{ label: "Partner with NLEC", href: "/services" }}
        secondaryCta={{ label: "Explore our work", href: "/our-work" }}
        aside={heroAside}
      />

      <section className="section-block">
        <div className="site-container">
          <SectionHeading
            eyebrow="What NLEC does"
            title="A national body that turns lived experience into usable intelligence"
            description="NLEC is designed to support governments, institutions, researchers, service providers, media and communities with careful, evidence-led work that respects the human source of the evidence."
          />
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            <InfoCard
              kicker="Evidence"
              title="Collect and structure lived-experience evidence"
              description="Design consultation processes and evidence pathways that preserve context, reduce extraction and make the material usable for reform."
            />
            <InfoCard
              kicker="Insight"
              title="Translate evidence into policy and governance insight"
              description="Move from testimony to analysis, and from analysis to the reform questions that matter to decision-makers."
            />
            <InfoCard
              kicker="Action"
              title="Support institutions to improve how they operate"
              description="Work with organisations that want stronger service design, better accountability and more reliable responses to human impact."
            />
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container">
          <SectionHeading
            eyebrow="Why lived experience matters"
            title="It is often the earliest signal that a system is failing"
            description="Lived experience can reveal service breakdowns, harmful assumptions and implementation gaps before they become visible in official data."
          />
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            <StatCard value="Earlier" label="Recognition of system blind spots and avoidable harm." />
            <StatCard value="Clearer" label="Understanding of what policy looks like in real life." />
            <StatCard value="Safer" label="Consultation processes that are respectful and trauma-informed." />
            <StatCard value="Stronger" label="Accountability when evidence is structured and shared responsibly." />
          </div>
        </div>
      </section>

      <section className="section-block">
        <div className="site-container">
          <SectionHeading
            eyebrow="Our charitable purposes"
            title="Public-interest purposes that guide every part of the Commission's work"
          />
          <div className="grid gap-6 md:grid-cols-3">
            {charitablePurposes.map((purpose) => (
              <InfoCard
                key={purpose}
                kicker="Purpose"
                title={purpose}
                description="NLEC advances this purpose through publications, submissions, advisory work, research, listening and public education."
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container">
          <SectionHeading
            eyebrow="National areas of work"
            title="We work across the settings where lived experience shapes institutional outcomes"
          />
          <div className="flex flex-wrap gap-3">
            {nationalWorkAreas.map((area) => (
              <span key={area} className="pill">
                {area}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="section-block">
        <div className="site-container">
          <SectionHeading
            eyebrow="Services and partnerships"
            title="NLEC supports institutions that want practical reform, not symbolic consultation"
          />
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            <InfoCard
              kicker="Advisory"
              title="Briefings and institutional advice"
              description="Short-form or ongoing support for governments, boards, service leaders and sector bodies."
            />
            <InfoCard
              kicker="Research"
              title="Commissioned research and analysis"
              description="Targeted research on system failure, accountability, service design and lived-experience evidence."
            />
            <InfoCard
              kicker="Consultation"
              title="Trauma-informed listening design"
              description="Consultation structures that are ethical, accessible and capable of producing high-quality evidence."
            />
            <InfoCard
              kicker="Review"
              title="Policy and service design review"
              description="Independent review of whether policies, processes and services match the reality people face."
            />
          </div>
        </div>
      </section>

      <section className="section-block border-y border-[color:var(--line)] bg-[color:var(--surface)]">
        <div className="site-container">
          <SectionHeading
            eyebrow="Latest publications"
            title="The Commission's first public PDFs"
            description="NLEC has begun publishing its core public documents, including the flagship intelligence report, a standards framework and supporting operational material."
          />
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {publicationReleases.map((item) => (
              <PublicationCard key={item.title} category={item.category} title={item.title} summary={item.summary} href={item.href} />
            ))}
          </div>
        </div>
      </section>

      <CTASection
        title={`Work with ${organisation.shortName} on evidence-led reform`}
        description="If you are a government department, service provider, university, funder, media organisation or community group, we can help shape the way lived experience is translated into action."
        primary={{ label: "Partner with NLEC", href: "/services" }}
        secondary={{ label: "Contact us", href: "/contact" }}
      />
    </PublicLayout>
  );
}
