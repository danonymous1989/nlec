import { PublicLayout } from "@/components/layout/PublicLayout";
import { useSubmitEvidence } from "@workspace/api-client-react";
import { useSEO } from "@/lib/useSEO";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { AlertCircle, CheckCircle2 } from "lucide-react";

const evidenceSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Valid email is required"),
  organisation: z.string().optional(),
  locationState: z.string().min(1, "Location is required"),
  submissionType: z.string().min(1, "Type is required"),
  subject: z.string().min(5, "Subject must be at least 5 characters"),
  description: z.string().min(50, "Please provide sufficient detail (min 50 chars)"),
  consentGiven: z.boolean().refine(val => val === true, { message: "Consent is required to proceed" })
});

export function SubmitEvidence() {
  useSEO({ path: "/submit-evidence", title: "Submit Evidence", description: "Contribute systemic evidence to the National Lived Experience Commission. Secure submissions inform national governance standards and risk identification." });
  const mutation = useSubmitEvidence();
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof evidenceSchema>>({
    resolver: zodResolver(evidenceSchema),
    defaultValues: {
      fullName: "", email: "", organisation: "", locationState: "", submissionType: "", subject: "", description: "", consentGiven: false
    }
  });

  const onSubmit = async (data: z.infer<typeof evidenceSchema>) => {
    try {
      await mutation.mutateAsync({ data });
      toast({
        title: "Evidence Submitted",
        description: "Your submission has been securely received by the Commission.",
      });
      form.reset();
    } catch (e) {
      toast({
        title: "Submission Failed",
        description: "An error occurred. Please try again later.",
        variant: "destructive"
      });
    }
  };

  return (
    <PublicLayout>
      <div className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">Submit Evidence</h1>
          <p className="text-xl text-white/80 font-light max-w-2xl">
            Contribute to national systems intelligence. Your secure submission helps identify systemic risks and informs structural governance standards.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="md:col-span-1 space-y-8">
            <div className="bg-gray-50 p-6 border-l-4 border-secondary">
              <h3 className="font-serif font-bold text-lg text-primary mb-3 flex items-center">
                <AlertCircle size={18} className="mr-2 text-secondary" /> Confidentiality
              </h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                All submissions are strictly confidential. The Commission uses this data for aggregate systems intelligence. Identifying information is separated from evidence analysis.
              </p>
            </div>
            
            <div>
              <h3 className="font-serif font-bold text-lg text-primary mb-3">What to submit</h3>
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-start"><CheckCircle2 size={16} className="mr-2 mt-0.5 text-accent shrink-0"/> Accounts of systemic or governance failures</li>
                <li className="flex items-start"><CheckCircle2 size={16} className="mr-2 mt-0.5 text-accent shrink-0"/> Examples of successful lived experience integration</li>
                <li className="flex items-start"><CheckCircle2 size={16} className="mr-2 mt-0.5 text-accent shrink-0"/> Research or policy feedback</li>
              </ul>
            </div>
          </div>

          <div className="md:col-span-2">
            {mutation.isSuccess ? (
              <div className="bg-green-50 border border-green-200 p-8 text-center rounded-sm">
                <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 size={32} />
                </div>
                <h3 className="text-2xl font-serif font-bold text-green-900 mb-2">Submission Received</h3>
                <p className="text-green-700 mb-6">Your evidence has been securely lodged with the Commission. A confirmation has been sent to your email.</p>
                <Button variant="outline" onClick={() => mutation.reset()} className="rounded-none">
                  Submit Another
                </Button>
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="fullName" render={({ field }) => (
                      <FormItem><FormLabel>Full Name</FormLabel><FormControl><Input className="rounded-none h-11" placeholder="Alex Smith" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="email" render={({ field }) => (
                      <FormItem><FormLabel>Email Address</FormLabel><FormControl><Input type="email" className="rounded-none h-11" placeholder="alex@example.com.au" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField control={form.control} name="organisation" render={({ field }) => (
                      <FormItem><FormLabel>Organisation (Optional)</FormLabel><FormControl><Input className="rounded-none h-11" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="locationState" render={({ field }) => (
                      <FormItem><FormLabel>Location</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl><SelectTrigger className="rounded-none h-11"><SelectValue placeholder="Select State/Territory" /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value="National">National</SelectItem>
                            <SelectItem value="NSW">New South Wales</SelectItem>
                            <SelectItem value="VIC">Victoria</SelectItem>
                            <SelectItem value="QLD">Queensland</SelectItem>
                            <SelectItem value="WA">Western Australia</SelectItem>
                            <SelectItem value="SA">South Australia</SelectItem>
                            <SelectItem value="TAS">Tasmania</SelectItem>
                            <SelectItem value="ACT">ACT</SelectItem>
                            <SelectItem value="NT">Northern Territory</SelectItem>
                          </SelectContent>
                        </Select><FormMessage />
                      </FormItem>
                    )} />
                  </div>

                  <FormField control={form.control} name="submissionType" render={({ field }) => (
                    <FormItem><FormLabel>Submission Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl><SelectTrigger className="rounded-none h-11"><SelectValue placeholder="Select type of evidence" /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="Governance Concern">Governance Concern</SelectItem>
                          <SelectItem value="Systems Issue">Systems Issue</SelectItem>
                          <SelectItem value="Lived Experience Account">Lived Experience Account</SelectItem>
                          <SelectItem value="Research Contribution">Research Contribution</SelectItem>
                          <SelectItem value="Organisational Evidence">Organisational Evidence</SelectItem>
                        </SelectContent>
                      </Select><FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="subject" render={({ field }) => (
                    <FormItem><FormLabel>Subject</FormLabel><FormControl><Input className="rounded-none h-11" placeholder="Brief summary of the issue" {...field} /></FormControl><FormMessage /></FormItem>
                  )} />

                  <FormField control={form.control} name="description" render={({ field }) => (
                    <FormItem><FormLabel>Detailed Description</FormLabel><FormControl><Textarea className="rounded-none min-h-[200px]" placeholder="Please provide detailed context, impact, and any relevant background..." {...field} /></FormControl><FormMessage /></FormItem>
                  )} />

                  <FormField control={form.control} name="consentGiven" render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border bg-gray-50">
                      <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Privacy & Consent Acknowledgement</FormLabel>
                        <FormDescription>
                          I consent to the NLEC collecting and analysing this information for systems intelligence. I understand my personal details will remain confidential as per the Privacy Policy.
                        </FormDescription>
                      </div>
                    </FormItem>
                  )} />

                  <Button type="submit" disabled={mutation.isPending} className="w-full rounded-none h-14 text-lg bg-primary hover:bg-primary/90 hover-elevate">
                    {mutation.isPending ? "Securely Submitting..." : "Lodge Evidence"}
                  </Button>
                </form>
              </Form>
            )}
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
