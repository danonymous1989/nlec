import { AdminLayout } from "@/components/layout/AdminLayout";
import { useAdminListEvidence, useAdminUpdateEvidenceStatus } from "@workspace/api-client-react";
import { format } from "date-fns";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export function EvidenceAdmin() {
  const { data: evidence, isLoading } = useAdminListEvidence();
  const updateStatus = useAdminUpdateEvidenceStatus();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleStatusChange = async (id: number, newStatus: string) => {
    try {
      await updateStatus.mutateAsync({ id, data: { status: newStatus } });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/evidence"] });
      toast({ title: "Status updated successfully" });
    } catch (e) {
      toast({ title: "Failed to update status", variant: "destructive" });
    }
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-serif font-bold text-primary">Evidence Submissions</h1>
      </div>

      <div className="bg-white border border-gray-200 shadow-sm rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3">ID</th>
                <th className="px-6 py-3">Date</th>
                <th className="px-6 py-3">Submitter</th>
                <th className="px-6 py-3">Type</th>
                <th className="px-6 py-3">Subject</th>
                <th className="px-6 py-3 w-40">Status</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={6} className="px-6 py-8 text-center"><div className="animate-spin h-6 w-6 border-b-2 border-primary mx-auto"></div></td></tr>
              ) : evidence?.map((item) => (
                <tr key={item.id} className="border-b last:border-0 hover:bg-gray-50">
                  <td className="px-6 py-4 text-gray-500">#{item.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{format(new Date(item.createdAt), 'MMM dd, yyyy')}</td>
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900">{item.fullName}</div>
                    <div className="text-gray-500 text-xs">{item.email}</div>
                  </td>
                  <td className="px-6 py-4">{item.submissionType}</td>
                  <td className="px-6 py-4 truncate max-w-xs">{item.subject}</td>
                  <td className="px-6 py-4">
                    <Select defaultValue={item.status} onValueChange={(v) => handleStatusChange(item.id, v)}>
                      <SelectTrigger className={`h-8 text-xs font-semibold rounded-full border-0 ${item.status === 'Pending' ? 'bg-amber-100 text-amber-800' : item.status === 'Under Review' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="Under Review">Under Review</SelectItem>
                        <SelectItem value="Processed">Processed</SelectItem>
                      </SelectContent>
                    </Select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
