import { useState } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import {
  useAdminListPublications,
  useAdminCreatePublication,
  useAdminUpdatePublication,
  useAdminDeletePublication,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Edit, Trash2, X, Save } from "lucide-react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";

type PubForm = {
  title: string;
  type: string;
  topic: string;
  abstract: string;
  body: string;
  authors: string;
  publishedAt: string;
  featured: boolean;
};

const emptyForm: PubForm = {
  title: "",
  type: "Research Paper",
  topic: "",
  abstract: "",
  body: "",
  authors: "National Lived Experience Commission",
  publishedAt: new Date().toISOString().slice(0, 10),
  featured: false,
};

const PUB_TYPES = ["Research Paper", "Policy Brief", "Discussion Paper", "Intelligence Report", "Submission", "Framework"];

export function PublicationsAdmin() {
  const { data: publications, isLoading } = useAdminListPublications();
  const createPub = useAdminCreatePublication();
  const updatePub = useAdminUpdatePublication();
  const deletePub = useAdminDeletePublication();
  const queryClient = useQueryClient();

  const [editing, setEditing] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<PubForm>(emptyForm);

  const handleSave = async () => {
    const payload = { ...form, publishedAt: new Date(form.publishedAt).toISOString() };
    if (editing !== null) {
      await updatePub.mutateAsync({ id: editing, data: payload });
    } else {
      await createPub.mutateAsync({ data: payload });
    }
    queryClient.invalidateQueries({ queryKey: ["/api/admin/publications"] });
    setEditing(null);
    setCreating(false);
    setForm(emptyForm);
  };

  const handleEdit = (pub: any) => {
    setForm({
      title: pub.title,
      type: pub.type,
      topic: pub.topic || "",
      abstract: pub.abstract,
      body: pub.body || "",
      authors: pub.authors || "",
      publishedAt: pub.publishedAt ? pub.publishedAt.slice(0, 10) : "",
      featured: pub.featured,
    });
    setEditing(pub.id);
    setCreating(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this publication?")) return;
    await deletePub.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: ["/api/admin/publications"] });
  };

  const showForm = creating || editing !== null;

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-serif font-bold text-primary">Manage Publications</h1>
          <p className="text-gray-500 mt-1">{publications?.length || 0} publications in repository</p>
        </div>
        {!showForm && (
          <Button onClick={() => { setCreating(true); setEditing(null); setForm(emptyForm); }} className="rounded-none bg-secondary hover:bg-secondary/90">
            <Plus className="h-4 w-4 mr-2" /> New Publication
          </Button>
        )}
      </div>

      {showForm && (
        <div className="bg-white border border-secondary/30 p-8 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-serif font-bold text-primary">{editing !== null ? "Edit Publication" : "New Publication"}</h2>
            <button onClick={() => { setEditing(null); setCreating(false); }}><X className="h-5 w-5 text-gray-400" /></button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Title *</label>
              <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className="rounded-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Type</label>
              <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))} className="w-full h-10 px-3 border border-gray-200 bg-white text-gray-700 rounded-none focus:outline-none focus:ring-1 focus:ring-secondary">
                {PUB_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Topic</label>
              <Input value={form.topic} onChange={e => setForm(f => ({ ...f, topic: e.target.value }))} className="rounded-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Authors</label>
              <Input value={form.authors} onChange={e => setForm(f => ({ ...f, authors: e.target.value }))} className="rounded-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Published Date</label>
              <Input type="date" value={form.publishedAt} onChange={e => setForm(f => ({ ...f, publishedAt: e.target.value }))} className="rounded-none" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Abstract *</label>
              <textarea rows={4} value={form.abstract} onChange={e => setForm(f => ({ ...f, abstract: e.target.value }))} className="w-full px-3 py-2 border border-gray-200 text-gray-700 rounded-none focus:outline-none focus:ring-1 focus:ring-secondary resize-none" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Body / Full Summary</label>
              <textarea rows={8} value={form.body} onChange={e => setForm(f => ({ ...f, body: e.target.value }))} className="w-full px-3 py-2 border border-gray-200 text-gray-700 rounded-none focus:outline-none focus:ring-1 focus:ring-secondary resize-none" />
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="featured" checked={form.featured} onChange={e => setForm(f => ({ ...f, featured: e.target.checked }))} />
              <label htmlFor="featured" className="text-sm text-gray-700">Featured on homepage</label>
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <Button onClick={handleSave} className="rounded-none bg-primary hover:bg-primary/90">
              <Save className="h-4 w-4 mr-2" /> Save Publication
            </Button>
            <Button variant="outline" onClick={() => { setEditing(null); setCreating(false); }} className="rounded-none">Cancel</Button>
          </div>
        </div>
      )}

      <div className="bg-white border border-gray-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left px-6 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider">Title</th>
              <th className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider hidden md:table-cell">Type</th>
              <th className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider hidden lg:table-cell">Published</th>
              <th className="px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {isLoading ? (
              <tr><td colSpan={4} className="text-center py-8 text-gray-400">Loading...</td></tr>
            ) : (publications || []).map(pub => (
              <tr key={pub.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="font-medium text-gray-900">{pub.title}</div>
                  {pub.featured && <span className="text-xs text-accent font-semibold">Featured</span>}
                </td>
                <td className="px-4 py-4 text-gray-600 hidden md:table-cell">{pub.type}</td>
                <td className="px-4 py-4 text-gray-500 hidden lg:table-cell">{pub.publishedAt ? format(new Date(pub.publishedAt), "d MMM yyyy") : "—"}</td>
                <td className="px-4 py-4">
                  <div className="flex gap-2">
                    <button onClick={() => handleEdit(pub)} className="text-secondary hover:text-secondary/80 p-1"><Edit className="h-4 w-4" /></button>
                    <button onClick={() => handleDelete(pub.id)} className="text-red-500 hover:text-red-400 p-1"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
