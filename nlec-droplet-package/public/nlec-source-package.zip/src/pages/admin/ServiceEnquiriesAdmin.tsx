import { useState } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronUp, Building2, Mail, Phone, Calendar } from "lucide-react";

type ServiceEnquiry = {
  id: number; organisationName: string; contactName: string;
  contactEmail: string; contactPhone?: string; serviceType: string;
  organisationSize?: string; description: string; budget?: string;
  status: string; notes?: string; createdAt: string;
};

const statusColors: Record<string, string> = {
  new: "bg-blue-100 text-blue-800",
  contacted: "bg-yellow-100 text-yellow-800",
  proposal_sent: "bg-purple-100 text-purple-800",
  engaged: "bg-green-100 text-green-800",
  closed: "bg-gray-100 text-gray-800",
  declined: "bg-red-100 text-red-800",
};

const SERVICE_LABELS: Record<string, string> = {
  "governance-audit": "Lived Experience Governance Audit",
  "maturity-assessment": "Institutional Maturity Assessment",
  "workforce-review": "Workforce Integration Review",
  "engagement-assessment": "Engagement Integrity Assessment",
  "safeguarding-review": "Safeguarding & Psychological Safety Review",
  "systems-intelligence": "Systems Intelligence Baseline Assessment",
  "multiple": "Multiple Services",
};

export function ServiceEnquiriesAdmin() {
  const [expanded, setExpanded] = useState<number | null>(null);
  const [updating, setUpdating] = useState<number | null>(null);
  const qc = useQueryClient();

  const { data: enquiries = [], isLoading } = useQuery<ServiceEnquiry[]>({
    queryKey: ["admin-service-enquiries"],
    queryFn: async () => {
      const res = await fetch("/api/admin/service-enquiries", { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status, notes }: { id: number; status: string; notes?: string }) => {
      const res = await fetch(`/api/admin/service-enquiries/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ status, notes }),
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-service-enquiries"] }),
  });

  const statusOptions = ["new", "contacted", "proposal_sent", "engaged", "closed", "declined"];

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-serif font-bold text-primary mb-2">Service Enquiries</h1>
        <p className="text-gray-500">Institutional assessment and advisory service enquiries</p>
      </div>

      {isLoading ? (
        <div className="space-y-4">{[1,2,3].map(i => <div key={i} className="h-20 bg-gray-100 animate-pulse rounded" />)}</div>
      ) : enquiries.length === 0 ? (
        <div className="text-center py-16 text-gray-400 border border-dashed border-gray-300">
          <Building2 className="h-10 w-10 mx-auto mb-3 opacity-40" />
          <p>No service enquiries yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {enquiries.map(enq => (
            <div key={enq.id} className="border border-gray-200 bg-white">
              <div
                className="flex flex-col sm:flex-row sm:items-center justify-between p-5 gap-4 cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => setExpanded(expanded === enq.id ? null : enq.id)}
              >
                <div className="flex items-start gap-4">
                  <div>
                    <div className="font-semibold text-primary">{enq.organisationName}</div>
                    <div className="text-sm text-gray-500">{enq.contactName} — {SERVICE_LABELS[enq.serviceType] || enq.serviceType}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-2 py-1 rounded ${statusColors[enq.status] || "bg-gray-100 text-gray-700"}`}>
                    {enq.status.replace("_", " ").toUpperCase()}
                  </span>
                  <span className="text-xs text-gray-400">{new Date(enq.createdAt).toLocaleDateString("en-AU")}</span>
                  {expanded === enq.id ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
                </div>
              </div>

              {expanded === enq.id && (
                <div className="border-t border-gray-100 p-5 space-y-4 bg-gray-50/50">
                  <div className="grid sm:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center gap-2 text-gray-600"><Mail size={14} className="text-secondary" /><a href={`mailto:${enq.contactEmail}`} className="text-secondary hover:underline">{enq.contactEmail}</a></div>
                    {enq.contactPhone && <div className="flex items-center gap-2 text-gray-600"><Phone size={14} className="text-secondary" />{enq.contactPhone}</div>}
                    {enq.budget && <div className="flex items-center gap-2 text-gray-600"><span className="font-medium">Budget:</span> {enq.budget}</div>}
                    {enq.organisationSize && <div className="flex items-center gap-2 text-gray-600"><span className="font-medium">Size:</span> {enq.organisationSize}</div>}
                  </div>
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Description</div>
                    <p className="text-sm text-gray-700 leading-relaxed">{enq.description}</p>
                  </div>
                  <div className="flex flex-wrap gap-3 items-center pt-2">
                    <div className="text-xs font-bold uppercase tracking-wider text-gray-400 mr-2">Update Status:</div>
                    {statusOptions.map(s => (
                      <button
                        key={s}
                        onClick={() => updateStatus.mutate({ id: enq.id, status: s })}
                        className={`text-xs px-3 py-1.5 border transition-colors ${enq.status === s ? "bg-primary text-white border-primary" : "border-gray-300 text-gray-600 hover:border-secondary hover:text-secondary"}`}
                      >
                        {s.replace("_", " ")}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}
