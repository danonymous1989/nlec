import { AdminLayout } from "@/components/layout/AdminLayout";
import { useAdminListStandards, useAdminDeleteStandard, useAdminCreateStandard } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const standardSchema = z.object({
  code: z.string().min(1),
  title: z.string().min(1),
  category: z.string().min(1),
  status: z.string().min(1),
  overview: z.string().min(1),
  publishedAt: z.string().min(1),
});

export function StandardsAdmin() {
  const { data: standards, isLoading } = useAdminListStandards();
  const deleteMutation = useAdminDeleteStandard();
  const createMutation = useAdminCreateStandard();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof standardSchema>>({
    resolver: zodResolver(standardSchema),
    defaultValues: { code: "", title: "", category: "Governance", status: "Active", overview: "", publishedAt: new Date().toISOString().split('T')[0] }
  });

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this standard?")) {
      await deleteMutation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/standards"] });
      toast({ title: "Deleted successfully" });
    }
  };

  const onSubmit = async (data: z.infer<typeof standardSchema>) => {
    await createMutation.mutateAsync({ data: { ...data, featured: false } });
    queryClient.invalidateQueries({ queryKey: ["/api/admin/standards"] });
    toast({ title: "Standard created" });
    setOpen(false);
    form.reset();
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-serif font-bold text-primary">Manage Standards</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-secondary hover:bg-secondary/90 text-white rounded-md hover-elevate"><Plus size={16} className="mr-2"/> New Standard</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Standard</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="code" render={({ field }) => (
                    <FormItem><FormLabel>Code</FormLabel><FormControl><Input placeholder="e.g. NLEC-001" {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="status" render={({ field }) => (
                    <FormItem><FormLabel>Status</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem><FormLabel>Title</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="category" render={({ field }) => (
                    <FormItem><FormLabel>Category</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="publishedAt" render={({ field }) => (
                    <FormItem><FormLabel>Publish Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="overview" render={({ field }) => (
                  <FormItem><FormLabel>Overview</FormLabel><FormControl><Textarea className="h-32" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <div className="flex justify-end pt-4">
                  <Button type="submit" disabled={createMutation.isPending}>{createMutation.isPending ? "Saving..." : "Save Standard"}</Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-white border border-gray-200 shadow-sm rounded-md overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3">Code</th>
              <th className="px-6 py-3">Title</th>
              <th className="px-6 py-3">Category</th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
               <tr><td colSpan={5} className="px-6 py-8 text-center">Loading...</td></tr>
            ) : standards?.map((std) => (
              <tr key={std.id} className="border-b last:border-0 hover:bg-gray-50">
                <td className="px-6 py-4 font-mono text-xs">{std.code}</td>
                <td className="px-6 py-4 font-medium text-primary">{std.title}</td>
                <td className="px-6 py-4">{std.category}</td>
                <td className="px-6 py-4"><span className="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">{std.status}</span></td>
                <td className="px-6 py-4 text-right">
                  <Button variant="ghost" size="icon" className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"><Edit size={16} /></Button>
                  <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-800 hover:bg-red-50 ml-2" onClick={() => handleDelete(std.id)}><Trash2 size={16} /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
