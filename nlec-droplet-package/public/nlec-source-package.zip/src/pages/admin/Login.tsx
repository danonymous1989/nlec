import { useAdminLogin } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { ShieldCheck } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export function AdminLogin() {
  const mutation = useAdminLogin();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "", password: "" }
  });

  const onSubmit = async (data: z.infer<typeof loginSchema>) => {
    try {
      await mutation.mutateAsync({ data });
      setLocation("/admin");
    } catch (e: any) {
      toast({
        title: "Authentication Failed",
        description: e.message || "Invalid credentials",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10 bg-grid-pattern"></div>
      
      <div className="max-w-md w-full bg-white border border-gray-200 shadow-xl p-8 relative z-10">
        <div className="text-center mb-8">
          <ShieldCheck size={48} className="mx-auto text-primary mb-4" />
          <h1 className="text-2xl font-serif font-bold text-primary">NLEC Secure Access</h1>
          <p className="text-sm text-gray-500 mt-2">Authorised Commission Personnel Only</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField control={form.control} name="username" render={({ field }) => (
              <FormItem><FormLabel>Username</FormLabel><FormControl><Input className="rounded-none" {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="password" render={({ field }) => (
              <FormItem><FormLabel>Password</FormLabel><FormControl><Input type="password" className="rounded-none" {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <Button type="submit" disabled={mutation.isPending} className="w-full rounded-none bg-primary hover:bg-primary/90 hover-elevate">
              {mutation.isPending ? "Authenticating..." : "Login to Dashboard"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
