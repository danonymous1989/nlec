import { AdminLayout } from "@/components/layout/AdminLayout";
import { useAdminListContact, useAdminUpdateContactStatus } from "@workspace/api-client-react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Mail, Building, ChevronDown } from "lucide-react";

const STATUS_COLORS: Record<string, string> = {
  new: "bg-blue-50 text-blue-700 border-blue-200",
  "in-progress": "bg-amber-50 text-amber-700 border-amber-200",
  resolved: "bg-green-50 text-green-700 border-green-200",
  closed: "bg-gray-100 text-gray-600 border-gray-200",
};

export function ContactAdmin() {
  const { data: enquiries, isLoading } = useAdminListContact();
  const updateStatus = useAdminUpdateContactStatus();
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState<number | null>(null);

  const handleStatusChange = async (id: number, status: string) => {
    await updateStatus.mutateAsync({ id, data: { status } });
    queryClient.invalidateQueries({ queryKey: ["/api/admin/contact"] });
  };

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-serif font-bold text-primary">Contact Enquiries</h1>
        <p className="text-gray-500 mt-1">{enquiries?.length || 0} enquiries received</p>
      </div>

      <div className="bg-white border border-gray-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left px-6 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider">Name / Organisation</th>
              <th className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider hidden md:table-cell">Type</th>
              <th className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider hidden md:table-cell">Subject</th>
              <th className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider hidden lg:table-cell">Date</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {isLoading ? (
              <tr><td colSpan={6} className="text-center py-8 text-gray-400">Loading...</td></tr>
            ) : (enquiries || []).map(enq => (
              <>
                <tr key={enq.id} className="hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => setExpanded(expanded === enq.id ? null : enq.id)}>
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900 flex items-center gap-2"><Mail className="h-4 w-4 text-gray-400" />{enq.name}</div>
                    {enq.organisation && <div className="text-xs text-gray-500 flex items-center gap-1 mt-1"><Building className="h-3 w-3" />{enq.organisation}</div>}
                    <div className="text-xs text-gray-400">{enq.email}</div>
                  </td>
                  <td className="px-4 py-4 text-gray-600 hidden md:table-cell">{enq.enquiryType}</td>
                  <td className="px-4 py-4 text-gray-700 hidden md:table-cell max-w-xs truncate">{enq.subject}</td>
                  <td className="px-4 py-4">
                    <select
                      value={enq.status}
                      onClick={e => e.stopPropagation()}
                      onChange={e => handleStatusChange(enq.id, e.target.value)}
                      className={`text-xs font-semibold px-2 py-1 border rounded-none focus:outline-none focus:ring-1 focus:ring-secondary ${STATUS_COLORS[enq.status] || "bg-gray-100 text-gray-600 border-gray-200"}`}
                    >
                      <option value="new">New</option>
                      <option value="in-progress">In Progress</option>
                      <option value="resolved">Resolved</option>
                      <option value="closed">Closed</option>
                    </select>
                  </td>
                  <td className="px-4 py-4 text-gray-500 text-xs hidden lg:table-cell">{enq.createdAt ? format(new Date(enq.createdAt), "d MMM yyyy") : "—"}</td>
                  <td className="px-4 py-4"><ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${expanded === enq.id ? "rotate-180" : ""}`} /></td>
                </tr>
                {expanded === enq.id && (
                  <tr key={`${enq.id}-expanded`} className="bg-blue-50/30">
                    <td colSpan={6} className="px-6 py-4">
                      <div className="max-w-2xl">
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Message</p>
                        <p className="text-gray-700 leading-relaxed whitespace-pre-wrap text-sm">{enq.message}</p>
                      </div>
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
