import { AdminLayout } from "@/components/layout/AdminLayout";
import { useAdminListEvidence } from "@workspace/api-client-react";
import { format } from "date-fns";

export function AdminDashboard() {
  const { data: evidence } = useAdminListEvidence();
  const recentEvidence = evidence?.slice(0, 5) || [];

  return (
    <AdminLayout>
      <h1 className="text-3xl font-serif font-bold text-primary mb-8">Commission Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
        <div className="bg-white p-6 border border-gray-200 shadow-sm rounded-md">
          <h3 className="text-sm font-medium text-gray-500 mb-1">Total Evidence</h3>
          <div className="text-3xl font-bold text-primary">{evidence?.length || 0}</div>
        </div>
        <div className="bg-white p-6 border border-gray-200 shadow-sm rounded-md">
          <h3 className="text-sm font-medium text-gray-500 mb-1">Pending Review</h3>
          <div className="text-3xl font-bold text-accent">{evidence?.filter(e => e.status === 'Pending').length || 0}</div>
        </div>
        {/* Mock stats for layout completeness */}
        <div className="bg-white p-6 border border-gray-200 shadow-sm rounded-md">
          <h3 className="text-sm font-medium text-gray-500 mb-1">Active Standards</h3>
          <div className="text-3xl font-bold text-secondary">12</div>
        </div>
        <div className="bg-white p-6 border border-gray-200 shadow-sm rounded-md">
          <h3 className="text-sm font-medium text-gray-500 mb-1">Publications</h3>
          <div className="text-3xl font-bold text-primary">45</div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 shadow-sm rounded-md overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
          <h2 className="font-semibold text-gray-800">Recent Evidence Submissions</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3">Date</th>
                <th className="px-6 py-3">Type</th>
                <th className="px-6 py-3">Subject</th>
                <th className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentEvidence.map((item) => (
                <tr key={item.id} className="border-b last:border-0 hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">{format(new Date(item.createdAt), 'MMM dd, yyyy')}</td>
                  <td className="px-6 py-4">{item.submissionType}</td>
                  <td className="px-6 py-4 font-medium text-gray-900 truncate max-w-xs">{item.subject}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${item.status === 'Pending' ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'}`}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
              {recentEvidence.length === 0 && (
                <tr><td colSpan={4} className="px-6 py-8 text-center text-gray-500">No recent submissions</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
