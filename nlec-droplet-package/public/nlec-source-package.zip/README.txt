NLEC source package

This archive includes the workspace root metadata plus the NLEC app source.
For Droplet scanning, the root package.json is present at the top level.
The app source itself is stored under src/ and public/.
